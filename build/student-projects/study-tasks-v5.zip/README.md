# Phase 1 / Week 5 - React Student Starter (NOT the answer)

## Setup

Extract the entire project into a new folder. Open a terminal in the folder containing package.json. Keep your Week 4 folder intact. Check node --version and npm --version. Use Node 22.12+ or a supported newer Node release for Vite 7. The included lockfile pins the tested dependency versions. Then run:

```bash
npm ci
npm run dev
```

Open the localhost URL printed by Vite. The first screen is a scaffold containing two **demo tasks**. Search, filter and sort work with the demo rows. Add reports that it needs wiring and keeps your draft. Toggle and Delete display the ID received by App until you connect their callbacks. Your job is to make them work.

**Important:** `npm test` works with Node's built-in test runner even before running `npm ci`; `npm run build` requires installed React/Vite packages. Vite normally uses port 5173, which is a different storage origin from the Week 4 local server. Your Week 4 saved tasks will NOT magically appear here. Keep Week 4 intact.

## In order

1. Explain each JSX component and trace props from `App` to `TaskItem`.
2. Implement `addTask()` using the exported helper functions, a stable ID, and `setTasks(previous => ...)`.
3. Implement checkbox toggle and delete, without mutating arrays or objects.
4. Show how search, status filter, and sort affect **visibleTasks** without deleting stored tasks.
5. Replace demo tasks with saved tasks loaded once; add `useEffect` to write state to localStorage, using the same `study-tasks-week2` key.
6. Run `npm test`, inspect DevTools React/Console, test reload + empty/invalid input, and commit changes.
7. Stretch (only if ahead): implement editing. **Do not** restore remote API features yet; those will be revisited in Week 6.

## AI collaboration constraints

First attempt a small code change for 10-15 minutes without generation. Ask AI for a hint before asking for a patch. If you delegate UI polish or tests, inspect `git diff` and explain what the agent changed.

Never paste private keys, passwords, or secrets into a prompt, repository, or source code.
