import { useState } from "react";
import TaskForm from "./components/TaskForm.jsx";
import TaskToolbar from "./components/TaskToolbar.jsx";
import TaskList from "./components/TaskList.jsx";
import { countRemaining, getVisibleTasks } from "./lib/task-logic.js";

const DEMO_TASKS = [
  { id: 1, title: "Review Week 4 promises", completed: true },
  { id: 2, title: "Build a React task form", completed: false }
];

export default function App() {
  const [tasks, setTasks] = useState(DEMO_TASKS);
  const [starterNotice, setStarterNotice] = useState("");
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest");

  // TODO 1: In addTask, validate the title, generate a unique numeric ID,
  // and use a functional setTasks update to append without mutation.
  function addTask(title) {
    console.log("TODO add:", title);
    return { ok: false, error: "The starter form is ready. Connect Add in Lesson 8 to save this task." };
  }

  // TODO 2: Replace the no-op callbacks below with immutable task updates.
  // TODO 3: Explain how `visibleTasks` is derived from state, not stored separately.
  const visibleTasks = getVisibleTasks(tasks, { filter, query, sort });

  // TODO 4: After core interactions work, replace the demo initial state
  // with safe lazy initialization from localStorage and add a save effect.
  // TODO 5 (stretch): Implement edit. Week 6 restores the API inbox.
  return (
    <main className="app">
      <header className="app-header">
        <p className="eyebrow">STUDY TASKS / V5 REACT EDITION</p>
        <h1>Build it. Understand it.</h1>
        <p>One task app, rebuilt using React components and state.</p>
      </header>

      <TaskForm onAdd={addTask} />
      <p role="status">{starterNotice}</p>
      <section className="tasks-section" aria-labelledby="tasks-heading">
        <div className="section-heading">
          <h2 id="tasks-heading">My study tasks</h2>
          <p className="count">{countRemaining(tasks)} remaining</p>
        </div>
        <TaskToolbar
          filter={filter} onFilterChange={setFilter}
          query={query} onQueryChange={setQuery}
          sort={sort} onSortChange={setSort}
        />
        <p className="results-count" aria-live="polite">{visibleTasks.length} shown of {tasks.length}</p>
        <TaskList
          tasks={visibleTasks}
          total={tasks.length}
          onToggle={(id) => setStarterNotice("Toggle reached App for task " + id + ". Connect its state update in Lesson 8.")}
          onDelete={(id) => setStarterNotice("Delete reached App for task " + id + ". Connect its state update in Lesson 5.")}
          onRename={() => ({ ok: false, error: "Edit not implemented yet" })}
        />
      </section>
      <aside className="next-week-note">
        <strong>Coming in Week 6</strong>
        <p>Restore the API Study Idea Inbox, then learn more React hooks and routing.</p>
      </aside>
    </main>
  );
}
