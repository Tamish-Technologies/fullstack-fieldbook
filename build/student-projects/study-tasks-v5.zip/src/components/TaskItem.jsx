export default function TaskItem({ task, onToggle, onDelete }) {
  return (
    <li className={`task-item${task.completed ? " completed" : ""}`}>
      <label className="task-label">
        <input
          type="checkbox"
          checked={task.completed}
          onChange={() => onToggle(task.id)}
        />
        <span>{task.title}</span>
      </label>
      <div className="task-actions">
        <button type="button" className="quiet-button" disabled title="Week 5 stretch">Edit (later)</button>
        <button type="button" className="delete-button" onClick={() => onDelete(task.id)}>Delete</button>
      </div>
    </li>
  );
}
