const FILTERS = [
  { id: "all", label: "All" },
  { id: "active", label: "Active" },
  { id: "completed", label: "Completed" }
];

export default function TaskToolbar({ filter, onFilterChange, query, onQueryChange, sort, onSortChange }) {
  return (
    <div className="toolbar">
      <div className="filters" aria-label="Filter tasks">
        {FILTERS.map((option) => (
          <button
            key={option.id}
            type="button"
            className="filter-button"
            aria-pressed={filter === option.id}
            onClick={() => onFilterChange(option.id)}
          >
            {option.label}
          </button>
        ))}
      </div>
      <div className="tools-row">
        <label className="search-field" htmlFor="task-search">
          Search tasks
          <input
            id="task-search"
            type="search"
            value={query}
            onChange={(event) => onQueryChange(event.target.value)}
            placeholder="Search by title"
          />
        </label>
        <label className="sort-field" htmlFor="task-sort">
          Sort tasks
          <select
            id="task-sort"
            value={sort}
            onChange={(event) => onSortChange(event.target.value)}
          >
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
          </select>
        </label>
      </div>
    </div>
  );
}
