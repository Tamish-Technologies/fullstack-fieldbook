# Study Tasks v7 learner starter

Open the extracted folder with both backend and frontend. Keep your Week 6 project in its own folder. Use Node 24 or a compatible release at least 22.12. Follow Fieldbook Week 7 in order.

## Start the backend first

In backend, run `npm ci` and `npm run dev`. Open http://127.0.0.1:3001/api/health. Expect status ok and storage memory. Leave that terminal open. Open a second terminal in backend for `npm test`; unfinished tests guide the store, validation and routes. See API_REQUESTS.http for requests. You can use curl, curl.exe on Windows PowerShell, or a small Node fetch script. No editor extension is required.

For Lesson 5, stop the normal watcher and run `npm run dev:seed`. This mode starts with two fictional tasks for GET practice. Return to `npm run dev` for a fresh empty store and the restart exercise.

## Add the read-only bridge in Lesson 11

In frontend, run `npm ci` and `npm run dev`. Open the printed Vite address and choose API Lab, or append /server. The placeholder is ready for your two GET requests. Keep both terminals running. The Vite dev server forwards /api to 127.0.0.1:3001. If you change the API port, also change that target and restart Vite.

My Tasks stores browser-local data. API Lab reads a separate server list. The unseeded server starts empty after a restart. Keep all tasks fictional and both services on loopback. Week 7 requires no database, credentials, hosting or paid tools.

Both folders include lockfiles. If you already have the dependencies cached, try `npm ci --offline` when the registry is unavailable. Return to the readings if package installation is temporarily blocked.
