import express from "express";
import { createTaskStore } from "./task-store.js";
import { parseCompletedFilter, parseTaskId, validateCreateBody, validatePatchBody } from "./validation.js";
const errorBody = (code, message) => ({ error: { code, message } });

export function createApp({ store = createTaskStore(), enableLogging = true } = {}) {
  const app = express();
  app.disable("x-powered-by");
  if (enableLogging) {
    app.use((req, res, next) => {
      const started = Date.now();
      res.on("finish", () => console.log(`${req.method} ${req.path} -> ${res.statusCode} (${Date.now() - started}ms)`));
      next();
    });
  }
  app.use(express.json({ limit: "16kb" }));

  app.get("/api/health", (_req, res) => {
    res.status(200).json({ status: "ok", service: "study-tasks-api", storage: "memory" });
  });
  app.get("/api/tasks", (req, res) => {
    // TODO A: apply parseCompletedFilter and send 400 for invalid query.
    const data = store.list();
    return res.json({ data, count: data.length });
  });
  // TODO B: implement GET /api/tasks/:id (200, 400 or 404).
  // TODO C: implement POST /api/tasks (201 + Location, or 400).
  // TODO D: implement PATCH /api/tasks/:id (200, 400 or 404).
  // TODO E: implement DELETE /api/tasks/:id (204, 400 or 404).

  app.use((req, res) => res.status(404).json(errorBody("ROUTE_NOT_FOUND", "Unknown API route.")));
  app.use((err, _req, res, _next) => {
    // TODO F: handle malformed JSON as 400 and oversized JSON as 413.
    console.error("Unexpected server failure.");
    return res.status(500).json(errorBody("INTERNAL_ERROR", "Unexpected server error."));
  });
  return app;
}
