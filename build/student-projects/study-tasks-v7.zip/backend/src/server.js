import { createApp } from "./app.js";
import { createTaskStore } from "./task-store.js";

const port = Number(process.env.PORT ?? 3001);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("PORT must be an integer between 1 and 65535.");
  process.exit(1);
}

const seeded = process.argv.includes("--seed");
const initialTasks = seeded ? [
  { id: 1, title: "Read the API contract", completed: true, createdAt: "2026-01-01T00:00:00.000Z" },
  { id: 2, title: "Try a GET filter", completed: false, createdAt: "2026-01-01T00:00:00.000Z" },
] : [];
const app = createApp({ store: createTaskStore({ initialTasks }) });
app.listen(port, "127.0.0.1", (error) => {
  if (error) {
    console.error(`Could not start on port ${port} (${error.code ?? "listen error"}). Stop the existing server or choose another port.`);
    process.exitCode = 1;
    return;
  }
  console.log(`Study Tasks API: http://127.0.0.1:${port}/api/health`);
  console.log(seeded ? "Practice rows reload on restart." : "The memory store starts empty on restart.");
});
