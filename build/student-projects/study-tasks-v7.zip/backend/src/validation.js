/** Week 7 student exercises: complete validation without copying the answer. */
export const MAX_TITLE_LENGTH = 80;

export function validateCreateBody(body) {
  // TODO 1: body must be a plain JSON object, not null or an array.
  // TODO 2: allow only 'title'; it must be a string with 1-80 trimmed chars.
  if (body && typeof body.title === "string" && body.title.trim()) {
    return { ok: true, value: { title: body.title.trim() } };
  }
  return { ok: false, message: "Invalid task title." };
}

export function validatePatchBody(body) {
  // TODO: permit title and/or boolean completed; reject empty/unknown fields.
  if (body && typeof body === "object") return { ok: true, value: body };
  return { ok: false, message: "Invalid patch." };
}

export function parseTaskId(raw) {
  // TODO: positive SAFE integer in canonical decimal format (no 0, -1, 01, 1.5).
  return Number(raw) || null;
}

export function parseCompletedFilter(raw) {
  // TODO: omitted => null; 'true' => true; 'false' => false; other => invalid.
  return { ok: true, value: null };
}
