/** Exercise: implement a small in-memory data store (no DB in Week 7). */
export function createTaskStore({ initialTasks = [], now = () => new Date().toISOString() } = {}) {
  let tasks = initialTasks.map((task) => ({ ...task }));
  let nextId = tasks.reduce((max, task) => Math.max(max, task.id), 0) + 1;
  return {
    list({ completed = null } = {}) {
      // TODO: filter by completed when not null and return copies.
      return tasks.map((task) => ({ ...task }));
    },
    get(id) {
      // TODO: find task by id, return a copy or null.
      return null;
    },
    create({ title }) {
      // TODO: create {id,title,completed:false,createdAt}; increment nextId.
      throw new Error("TODO: create a task");
    },
    update(id, patch) {
      // TODO: update the matching task without changing id or createdAt.
      return null;
    },
    remove(id) {
      // TODO: return false when not found, true when removed.
      return false;
    }
  };
}
