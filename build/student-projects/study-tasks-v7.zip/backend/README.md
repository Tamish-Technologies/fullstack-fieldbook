# Local Express API

Use Node 24 or a compatible release at least 22.12. Run `npm ci` and `npm run dev` in this folder. Check GET http://127.0.0.1:3001/api/health. Keep that terminal open and use a separate one here for `npm test` and real HTTP requests. The untouched starter reports 5 passing and 17 failing tests. The failing cases guide the unfinished routes and helpers.

The starter provides the health route, request parser, list shell and fallback. Complete the TODOs in Fieldbook lesson order. The normal server begins with an empty memory store. `npm run dev:seed` supplies the two fictional GET practice rows for Lesson 5. Only run one of these modes on port 3001 at a time. `npm test` uses its own temporary ports.

`API_REQUESTS.http` lists the expected requests. Routes become usable as you implement them. For GET you can also use your browser's Network panel. Keep the server bound to 127.0.0.1.
