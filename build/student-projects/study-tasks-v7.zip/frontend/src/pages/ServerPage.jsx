/** Week 7 Lesson 11 exercise: replace this placeholder with two read-only fetches. */
export default function ServerPage() {
  return (
    <section className="page-panel">
      <p className="eyebrow">WEEK 7 / LESSON 11</p>
      <h1 className="page-title">Your Express API lab</h1>
      <p className="muted">This starter screen is ready to connect in Fieldbook Lesson 11. Run both local processes, then add the two read-only requests.</p>
      <p className="server-note">Do not replace the existing browser task list; server tasks are a separate in-memory collection this week.</p>
    </section>
  );
}
