import { useEffect, useState } from "react";
import { Link, NavLink, Route, Routes } from "react-router";
import DashboardPage from "./pages/DashboardPage.jsx";
import TasksPage from "./pages/TasksPage.jsx";
import IdeasPage from "./pages/IdeasPage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";
import ServerPage from "./pages/ServerPage.jsx";
import {
  addTaskToList, deleteTaskFromList, renameTaskInList,
  toggleTaskInList
} from "./lib/task-logic.js";
import { readStoredTasks, STORAGE_KEY, writeStoredTasks } from "./lib/storage.js";

function getStorage() {
  try { return window.localStorage; } catch { return null; }
}
function initialTasks() {
  const storage = getStorage();
  return storage ? readStoredTasks(storage) :
    { ok: false, tasks: [], error: "Browser storage is unavailable." };
}

export default function App() {
  const [initial] = useState(initialTasks);
  const [tasks, setTasks] = useState(initial.tasks);
  const [canPersist, setCanPersist] = useState(initial.ok);
  const [storageWarning, setStorageWarning] = useState(initial.error);

  // Keeps local tasks across navigation and reloads (same origin + storage key).
  useEffect(() => {
    if (!canPersist) return;
    const storage = getStorage();
    const result = storage ? writeStoredTasks(storage, tasks, STORAGE_KEY) :
      { ok: false, error: "Browser storage is unavailable." };
    if (!result.ok) setStorageWarning(result.error);
  }, [tasks, canPersist]);

  function addTask(title) {
    setTasks((previous) => {
      const nextId = previous.reduce((max, task) => Math.max(max, task.id), 0) + 1;
      return addTaskToList(previous, nextId, title).tasks;
    });
  }
  function renameTask(id, title) {
    const result = renameTaskInList(tasks, id, title);
    if (result.ok) {
      setTasks((previous) => renameTaskInList(previous, id, title).tasks);
    }
    return result;
  }
  function resetUnreadableStorage() {
    if (!window.confirm("Replace unreadable saved tasks with an empty list?")) return;
    setTasks([]);
    setCanPersist(true);
    setStorageWarning("");
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-symbol" aria-hidden="true">S</span>
          <span><strong>Study Tasks</strong><small>v7 / First backend</small></span>
        </Link>
        <nav className="site-nav" aria-label="Main navigation">
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/tasks">My tasks</NavLink>
          <NavLink to="/ideas">Idea inbox</NavLink>
          <NavLink to="/server">API lab</NavLink>
        </nav>
      </header>
      <main className="content">
        <Routes>
          <Route path="/" element={<DashboardPage tasks={tasks} />} />
          <Route path="/tasks" element={
            <TasksPage tasks={tasks} onAdd={addTask}
              onToggle={(id) => setTasks((prev) => toggleTaskInList(prev, id))}
              onDelete={(id) => setTasks((prev) => deleteTaskFromList(prev, id))}
              onRename={renameTask} />
          } />
          <Route path="/ideas" element={<IdeasPage onAddIdea={(idea) => addTask(idea.title)} />} />
          <Route path="/server" element={<ServerPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
        {storageWarning && (
          <div className="storage-notice" role="alert">
            <p>{storageWarning}</p>
            {!canPersist && <button type="button" className="quiet-button" onClick={resetUnreadableStorage}>
              Start a fresh list (replaces saved data)
            </button>}
          </div>
        )}
      </main>
      <footer className="site-footer">Phase 1 / Week 7 &middot; Browser tasks stay local &middot; New Express API is separate</footer>
    </div>
  );
}
