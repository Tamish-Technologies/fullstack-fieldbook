# React starter with read-only API Lab

In this folder, use Node 24 or a compatible release at least 22.12 and run `npm ci` and `npm run dev`. Open the printed Vite link. In Lesson 11, connect API Lab (/server) to the backend using two read-only GET requests. Start the backend separately. The Vite development proxy forwards /api to 127.0.0.1:3001.

My Tasks stays browser-local. The API Lab page gets a separate server list. Run `npm test` for helper tests and `npm run build` to check the frontend can compile. Test the proxy with the development server. A deployed static build would need a separate API arrangement.
