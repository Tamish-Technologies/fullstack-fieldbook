# Study Tasks v8 learner starter

Extract the ZIP into a new folder. Keep your Week 7 project and Git checkpoint. Use Node 24, or a compatible version at least 22.12. Open separate terminals in backend and frontend, each beside its package.json. In each, run `npm ci` and then `npm run dev`. Leave both running. If packages are already cached, `npm ci --offline` works without registry access.

Open http://127.0.0.1:3001/api/health to verify Express. Open the address printed by Vite, then /server. The direct API and proxied /api/health should show the same service. Check the port printed by each process. If the API port changes, update frontend/vite.config.js and restart Vite.

The backend is the working Week 7 API. The frontend begins with browser-local tasks and the read-only bridge. Fieldbook Week 8 guides you through the unfinished task API helper, then loads and changes server tasks from React. The Week 7 task list should remain untouched during the migration. Use a separate Vite origin for practice and fictional task titles.

Run `npm test` in each folder. At first, the frontend reports 36 passing and 13 failing tests for the unfinished client. The backend reports 22 passing tests. Run `npm run build` from frontend to check compilation. Use the development server to test the proxy and API together.
