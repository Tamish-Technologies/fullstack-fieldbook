/** Small, dependency-free validation helpers. Never trust request bodies. */
export const MAX_TITLE_LENGTH = 80;

export function validateCreateBody(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return { ok: false, message: "Expected a JSON object." };
  }
  if (Object.keys(body).some((key) => key !== "title")) {
    return { ok: false, message: "Only 'title' is allowed when creating a task." };
  }
  if (typeof body.title !== "string") {
    return { ok: false, message: "title must be a string." };
  }
  const title = body.title.trim();
  if (!title || title.length > MAX_TITLE_LENGTH) {
    return { ok: false, message: `title must have 1-${MAX_TITLE_LENGTH} characters after trimming.` };
  }
  return { ok: true, value: { title } };
}

export function validatePatchBody(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return { ok: false, message: "Expected a JSON object." };
  }
  const keys = Object.keys(body);
  if (!keys.length || keys.some((key) => !["title", "completed"].includes(key))) {
    return { ok: false, message: "Provide title and/or completed; no other fields." };
  }
  const value = {};
  if (Object.hasOwn(body, "title")) {
    if (typeof body.title !== "string") {
      return { ok: false, message: "title must be a string." };
    }
    const title = body.title.trim();
    if (!title || title.length > MAX_TITLE_LENGTH) {
      return { ok: false, message: `title must have 1-${MAX_TITLE_LENGTH} characters after trimming.` };
    }
    value.title = title;
  }
  if (Object.hasOwn(body, "completed")) {
    if (typeof body.completed !== "boolean") {
      return { ok: false, message: "completed must be true or false." };
    }
    value.completed = body.completed;
  }
  return { ok: true, value };
}

export function parseTaskId(raw) {
  if (typeof raw !== "string" || !/^[1-9]\d*$/.test(raw)) return null;
  const id = Number(raw);
  return Number.isSafeInteger(id) ? id : null;
}

export function parseCompletedFilter(raw) {
  if (raw === undefined) return { ok: true, value: null };
  if (raw === "true") return { ok: true, value: true };
  if (raw === "false") return { ok: true, value: false };
  return { ok: false, message: "completed filter must be 'true' or 'false'." };
}
