import { createApp } from "./app.js";

const port = Number(process.env.PORT ?? 3001);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("PORT must be an integer between 1 and 65535.");
  process.exit(1);
}

const app = createApp();
app.listen(port, "127.0.0.1", (error) => {
  if (error) {
    console.error(`Could not start on port ${port} (${error.code ?? "listen error"}). Check the backend terminal and port.`);
    process.exitCode = 1;
    return;
  }
  console.log(`Study Tasks API: http://127.0.0.1:${port}/api/health`);
  console.log("Week 7 memory store resets whenever this process restarts.");
});
