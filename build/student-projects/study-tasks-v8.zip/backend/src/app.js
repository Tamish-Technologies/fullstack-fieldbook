import express from "express";
import { createTaskStore } from "./task-store.js";
import {
  parseCompletedFilter, parseTaskId, validateCreateBody, validatePatchBody
} from "./validation.js";

const errorBody = (code, message) => ({ error: { code, message } });

/** Separating app creation from listen() makes HTTP tests deterministic. */
export function createApp({ store = createTaskStore(), enableLogging = true } = {}) {
  const app = express();
  app.disable("x-powered-by");

  if (enableLogging) {
    app.use((req, res, next) => {
      const started = Date.now();
      res.on("finish", () => {
        console.log(`${req.method} ${req.path} -> ${res.statusCode} (${Date.now() - started}ms)`);
      });
      next();
    });
  }

  app.use(express.json({ limit: "16kb" }));

  app.get("/api/health", (_req, res) => {
    res.status(200).json({ status: "ok", service: "study-tasks-api", storage: "memory" });
  });

  app.get("/api/tasks", (req, res) => {
    const filter = parseCompletedFilter(req.query.completed);
    if (!filter.ok) return res.status(400).json(errorBody("INVALID_FILTER", filter.message));
    const data = store.list({ completed: filter.value });
    return res.json({ data, count: data.length });
  });

  app.get("/api/tasks/:id", (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const task = store.get(id);
    if (!task) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.json({ data: task });
  });

  app.post("/api/tasks", (req, res) => {
    const parsed = validateCreateBody(req.body);
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const task = store.create(parsed.value);
    return res.status(201).location(`/api/tasks/${task.id}`).json({ data: task });
  });

  app.patch("/api/tasks/:id", (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const parsed = validatePatchBody(req.body);
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const task = store.update(id, parsed.value);
    if (!task) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.json({ data: task });
  });

  app.delete("/api/tasks/:id", (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    if (!store.remove(id)) {
      return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    }
    return res.status(204).end();
  });

  // 404 is for unknown endpoints, different from a valid route and unknown task.
  app.use((req, res) => res.status(404).json(errorBody("ROUTE_NOT_FOUND", "Unknown API route.")));

  // Express error middleware requires four arguments (err, req, res, next).
  app.use((err, _req, res, next) => {
    if (res.headersSent) return next(err);
    if (err?.type === "entity.parse.failed") {
      return res.status(400).json(errorBody("INVALID_JSON", "Request body must be valid JSON."));
    }
    if (err?.type === "entity.too.large") {
      return res.status(413).json(errorBody("PAYLOAD_TOO_LARGE", "JSON body exceeds 16kb."));
    }
    console.error("Unexpected server failure.");
    return res.status(500).json(errorBody("INTERNAL_ERROR", "Unexpected server error."));
  });
  return app;
}
