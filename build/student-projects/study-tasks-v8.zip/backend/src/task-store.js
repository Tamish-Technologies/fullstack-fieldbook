/** In-memory task store; intentionally resets when the Node process restarts. */
export function createTaskStore({ initialTasks = [], now = () => new Date().toISOString() } = {}) {
  let tasks = initialTasks.map((task) => ({ ...task }));
  let nextId = tasks.reduce((max, task) => Math.max(max, task.id), 0) + 1;
  const clone = (task) => ({ ...task });

  return {
    list({ completed = null } = {}) {
      const selected = completed === null ? tasks :
        tasks.filter((task) => task.completed === completed);
      return selected.map(clone);
    },
    get(id) {
      const found = tasks.find((task) => task.id === id);
      return found ? clone(found) : null;
    },
    create({ title }) {
      const task = { id: nextId++, title, completed: false, createdAt: now() };
      tasks.push(task);
      return clone(task);
    },
    update(id, patch) {
      const index = tasks.findIndex((task) => task.id === id);
      if (index === -1) return null;
      tasks[index] = { ...tasks[index], ...patch };
      return clone(tasks[index]);
    },
    remove(id) {
      const before = tasks.length;
      tasks = tasks.filter((task) => task.id !== id);
      return tasks.length !== before;
    }
  };
}
