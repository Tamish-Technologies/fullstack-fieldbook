# Week 8 backend

See [Start here](../START_HERE.md) for complete setup instructions. Run npm ci, npm run dev and npm test from this directory.
