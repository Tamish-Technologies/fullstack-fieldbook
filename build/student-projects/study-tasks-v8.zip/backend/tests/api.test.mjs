import test from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";
import { createApp } from "../src/app.js";

async function withApi(run) {
  const app = createApp({ enableLogging: false });
  const server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await run(base); }
  finally { await new Promise((resolve, reject) => server.close((err) => err ? reject(err) : resolve())); }
}
async function request(base, path, options = {}) {
  const response = await fetch(base + path, options);
  const text = await response.text();
  return { response, body: text ? JSON.parse(text) : null };
}
const jsonOptions = (method, body) => ({
  method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
});

test("GET /api/health returns metadata", () => withApi(async(base) => {
  const { response, body } = await request(base, "/api/health");
  assert.equal(response.status, 200); assert.equal(body.status, "ok");
  assert.equal(body.storage, "memory");
  assert.equal(response.headers.get("x-powered-by"), null);
}));
test("GET /api/tasks starts empty", () => withApi(async(base) => {
  const { response, body } = await request(base, "/api/tasks");
  assert.equal(response.status, 200);
  assert.deepEqual(body, { data: [], count: 0 });
}));
test("POST creates a task with 201 and Location; GET finds it", () => withApi(async(base) => {
  const { response, body } = await request(base, "/api/tasks", jsonOptions("POST", { title: "  Read a book  " }));
  assert.equal(response.status, 201);
  assert.equal(response.headers.get("location"), "/api/tasks/1");
  assert.equal(body.data.title, "Read a book");
  assert.equal(body.data.completed, false);
  assert.equal(typeof body.data.createdAt, "string");
  const found = await request(base, "/api/tasks/1");
  assert.deepEqual(found.body.data, body.data);
}));
test("GET list and completed filter reflect updated tasks", () => withApi(async(base) => {
  await request(base, "/api/tasks", jsonOptions("POST", { title: "One" }));
  await request(base, "/api/tasks", jsonOptions("POST", { title: "Two" }));
  await request(base, "/api/tasks/1", jsonOptions("PATCH", { completed: true }));
  assert.equal((await request(base, "/api/tasks")).body.count, 2);
  const completed = await request(base, "/api/tasks?completed=true");
  assert.equal(completed.body.count, 1);
  assert.equal(completed.body.data[0].id, 1);
  const pending = await request(base, "/api/tasks?completed=false");
  assert.equal(pending.body.count, 1);
  assert.equal(pending.body.data[0].id, 2);
}));
test("PATCH updates only provided fields", () => withApi(async(base) => {
  await request(base, "/api/tasks", jsonOptions("POST", { title: "Initial" }));
  const changed = await request(base, "/api/tasks/1", jsonOptions("PATCH", { title: "  Revised " }));
  assert.equal(changed.response.status, 200);
  assert.equal(changed.body.data.title, "Revised");
  assert.equal(changed.body.data.completed, false);
  const toggled = await request(base, "/api/tasks/1", jsonOptions("PATCH", { completed: true }));
  assert.equal(toggled.body.data.completed, true);
}));
test("DELETE returns 204 without a body", () => withApi(async(base) => {
  await request(base, "/api/tasks", jsonOptions("POST", { title: "Remove me" }));
  const deleted = await request(base, "/api/tasks/1", { method: "DELETE" });
  assert.equal(deleted.response.status, 204);
  assert.equal(deleted.body, null);
  assert.equal((await request(base, "/api/tasks")).body.count, 0);
}));
test("invalid POST returns 400 and a consistent error object", () => withApi(async(base) => {
  for (const body of [{}, { title: "  " }, { title: 9 }, { title: "x", admin: true }]) {
    const result = await request(base, "/api/tasks", jsonOptions("POST", body));
    assert.equal(result.response.status, 400);
    assert.equal(result.body.error.code, "VALIDATION_ERROR");
  }
}));
test("PATCH rejects invalid booleans and unknown fields", () => withApi(async(base) => {
  await request(base, "/api/tasks", jsonOptions("POST", { title: "Hello" }));
  for (const body of [{ completed: "true" }, {}, { id: 88 }, { title: "" }]) {
    const result = await request(base, "/api/tasks/1", jsonOptions("PATCH", body));
    assert.equal(result.response.status, 400);
  }
}));
test("invalid ID gives 400 but absent valid ID gives 404", () => withApi(async(base) => {
  assert.equal((await request(base, "/api/tasks/nope")).response.status, 400);
  assert.equal((await request(base, "/api/tasks/999")).response.status, 404);
  assert.equal((await request(base, "/api/tasks/999", { method: "DELETE" })).response.status, 404);
}));
test("bad filter is a 400 and unknown route a 404", () => withApi(async(base) => {
  const bad = await request(base, "/api/tasks?completed=maybe");
  assert.equal(bad.response.status, 400); assert.equal(bad.body.error.code, "INVALID_FILTER");
  const missing = await request(base, "/api/something-else");
  assert.equal(missing.response.status, 404); assert.equal(missing.body.error.code, "ROUTE_NOT_FOUND");
}));
test("malformed JSON returns JSON error rather than HTML", () => withApi(async(base) => {
  const result = await request(base, "/api/tasks", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: '{"title":'
  });
  assert.equal(result.response.status, 400);
  assert.equal(result.body.error.code, "INVALID_JSON");
}));
test("tasks reset for a new process / new app instance", async () => {
  await withApi(async(base) => {
    await request(base, "/api/tasks", jsonOptions("POST", { title: "Temporary" }));
    assert.equal((await request(base, "/api/tasks")).body.count, 1);
  });
  await withApi(async(base) => {
    assert.equal((await request(base, "/api/tasks")).body.count, 0);
  });
});
