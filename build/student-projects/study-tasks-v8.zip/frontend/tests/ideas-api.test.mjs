import test from "node:test";
import assert from "node:assert/strict";
import { fetchIdeas, IDEAS_URL, normalizeIdeas } from "../src/lib/ideas-api.js";
import { SAMPLE_IDEAS } from "../src/lib/sample-ideas.js";

function reply({ ok = true, status = 200, body = [] } = {}) {
  return { ok, status, async json() { return body; } };
}

test("normalizeIdeas requires an array", () => {
  assert.throws(() => normalizeIdeas({}), /list of ideas/);
});
test("normalizeIdeas maps valid remote items to prefixed IDs", () => {
  assert.deepEqual(normalizeIdeas([{ id: 4, title: "  Read React docs  ", completed: false }]),
    [{ id: "api-4", title: "Read React docs", completed: false }]);
});
test("normalizeIdeas removes duplicates and invalid entries", () => {
  const items = [{ id: 1, title: "Read", completed: true },
    { id: 1, title: "Duplicate", completed: false },
    { id: 2, title: " ", completed: false },
    { id: "not-number", title: "Bad ID", completed: false }, null];
  assert.deepEqual(normalizeIdeas(items), [{ id: "api-1", title: "Read", completed: true }]);
});
test("normalizeIdeas returns [] for empty array (empty state)", () => {
  assert.deepEqual(normalizeIdeas([]), []);
});
test("normalizeIdeas enforces task title limits", () => {
  assert.deepEqual(normalizeIdeas([{ id: 7, title: "x".repeat(101) }]), []);
});
test("fetchIdeas passes endpoint and AbortSignal to injected fetch", async () => {
  const controller = new AbortController();
  let url; let options;
  const items = await fetchIdeas({ signal: controller.signal, fetchImpl: async (u, o) => {
    url = u; options = o; return reply({ body: [{ id: 9, title: "Practice", completed: false }] });
  }});
  assert.equal(url, IDEAS_URL);
  assert.equal(options.signal, controller.signal);
  assert.equal(items[0].id, "api-9");
});
test("fetchIdeas fails on HTTP 503 even though fetch resolved", async () => {
  await assert.rejects(() => fetchIdeas({ fetchImpl: async () => reply({ok:false,status:503}) }), /HTTP 503/);
});
test("fetchIdeas rejects malformed JSON structure", async () => {
  await assert.rejects(() => fetchIdeas({ fetchImpl: async () => reply({body:{todos:[]}}) }), /list of ideas/);
});
test("fetchIdeas propagates network failure", async () => {
  await assert.rejects(() => fetchIdeas({ fetchImpl: async () => { throw new TypeError("Network failed"); } }), /Network failed/);
});
test("fetchIdeas propagates AbortError to caller for UI to ignore", async () => {
  const error = new Error("aborted"); error.name = "AbortError";
  await assert.rejects(() => fetchIdeas({ fetchImpl: async () => { throw error; } }),
    (caught) => caught.name === "AbortError");
});
test("offline samples have unique prefixed IDs and usable titles", () => {
  assert.equal(new Set(SAMPLE_IDEAS.map((idea) => idea.id)).size, SAMPLE_IDEAS.length);
  assert.equal(SAMPLE_IDEAS.every((idea) => idea.id.startsWith("offline-") && idea.title.length), true);
});
