import test from "node:test";
import assert from "node:assert/strict";
import { ApiError, createTaskApi } from "../src/lib/task-api.js";

const json = (body, status = 200) => Response.json(body, { status });
const example = { id: 7, title: "Read MDN", completed: false, createdAt: "2026-11-14T00:00:00.000Z" };

function fake(implementation) { return createTaskApi(implementation); }

test("GET list returns server data from the envelope", async () => {
  const calls = [];
  const api = fake(async (path, options) => {
    calls.push({ path, options });
    return json({ data: [example], count: 1 });
  });
  assert.deepEqual(await api.list(), [example]);
  assert.equal(calls[0].path, "/api/tasks");
  assert.equal(calls[0].options.method, "GET");
});

test("POST serializes a JSON body and uses server-assigned ID", async () => {
  let sent;
  const api = fake(async (_, options) => { sent = options; return json({ data: example }, 201); });
  assert.deepEqual(await api.create("Read MDN"), example);
  assert.equal(sent.method, "POST");
  assert.deepEqual(JSON.parse(sent.body), { title: "Read MDN" });
  assert.equal(sent.headers["Content-Type"], "application/json");
});

test("PATCH sends only the requested fields", async () => {
  const requests = [];
  const api = fake(async (path, opts) => { requests.push([path, opts]); return json({ data: { ...example, completed: true } }); });
  assert.equal((await api.update(7, { completed: true })).completed, true);
  assert.equal(requests[0][0], "/api/tasks/7");
  assert.equal(requests[0][1].method, "PATCH");
  assert.deepEqual(JSON.parse(requests[0][1].body), { completed: true });
});

test("DELETE 204 has no JSON body", async () => {
  const api = fake(async () => new Response(null, { status: 204 }));
  assert.equal(await api.remove(7), undefined);
});

test("HTTP 400 rejects with the server's JSON error", async () => {
  const api = fake(async () => json({ error: { code: "VALIDATION_ERROR", message: "Title is too long." } }, 400));
  await assert.rejects(api.create("bad"), (error) => error instanceof ApiError &&
    error.status === 400 && error.code === "VALIDATION_ERROR" && error.message === "Title is too long.");
});

test("HTTP 404 is different from an unreachable server", async () => {
  const api = fake(async () => json({ error: { code: "TASK_NOT_FOUND", message: "Task missing." } }, 404));
  await assert.rejects(api.update(777, { completed: true }), (error) => error.status === 404);
});

test("network failure produces a readable message", async () => {
  const api = fake(async () => { throw new TypeError("Failed to fetch"); });
  await assert.rejects(api.list(), (error) => error.code === "NETWORK_ERROR" && error.status === 0);
});

test("AbortError is not rewritten as a network error", async () => {
  const api = fake(async () => { throw new DOMException("Aborted", "AbortError"); });
  await assert.rejects(api.list(), (error) => error.name === "AbortError");
});

test("non-JSON HTML from incorrect proxy is rejected", async () => {
  const api = fake(async () => new Response("<html>Vite fallback</html>", { headers: { "content-type": "text/html" } }));
  await assert.rejects(api.list(), (error) => error.code === "NON_JSON_RESPONSE");
});

test("malformed JSON is rejected", async () => {
  const api = fake(async () => new Response("{oops", { headers: { "content-type": "application/json" } }));
  await assert.rejects(api.list(), (error) => error.code === "BAD_JSON");
});

test("malformed list and malformed item shapes are rejected", async () => {
  const api1 = fake(async () => json({ data: [example], count: 2 }));
  const api2 = fake(async () => json({ data: { id: "not an integer" } }));
  await assert.rejects(api1.list(), (error) => error.code === "BAD_RESPONSE");
  await assert.rejects(api2.create("Hello"), (error) => error.code === "BAD_RESPONSE");
});

test("health endpoint returns expected status", async () => {
  const api = fake(async () => json({ status: "ok", storage: "memory" }));
  assert.equal((await api.health()).storage, "memory");
});

test("list passes through AbortSignal", async () => {
  const controller = new AbortController();
  const api = fake(async (_path, options) => {
    assert.equal(options.signal, controller.signal);
    return json({ data: [], count: 0 });
  });
  assert.deepEqual(await api.list({ signal: controller.signal }), []);
});
