import TaskForm from "../components/TaskForm.jsx";
import TaskToolbar from "../components/TaskToolbar.jsx";
import TaskList from "../components/TaskList.jsx";
import { countRemaining, getVisibleTasks } from "../lib/task-logic.js";
import { useState } from "react";

export default function TasksPage({ tasks, onAdd, onToggle, onDelete, onRename }) {
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest");
  const visibleTasks = getVisibleTasks(tasks, { filter, query, sort });
  return (
    <section className="page-panel" aria-labelledby="tasks-heading">
      <p className="eyebrow">YOUR LOCAL TASKS</p>
      <h1 className="page-title" id="tasks-heading">Plan your study time.</h1>
      <p className="muted">Create, edit, and finish tasks. Your saved list stays available across routes and reloads.</p>
      <TaskForm onAdd={onAdd} />
      <section className="tasks-section" aria-label="Saved tasks">
        <div className="section-heading">
          <h2>My study tasks</h2>
          <p className="count">{countRemaining(tasks)} remaining</p>
        </div>
        <TaskToolbar
          filter={filter} onFilterChange={setFilter}
          query={query} onQueryChange={setQuery}
          sort={sort} onSortChange={setSort}
        />
        <p className="results-count" aria-live="polite">{visibleTasks.length} shown of {tasks.length}</p>
        <TaskList tasks={visibleTasks} total={tasks.length}
          onToggle={onToggle} onDelete={onDelete} onRename={onRename} />
      </section>
    </section>
  );
}
