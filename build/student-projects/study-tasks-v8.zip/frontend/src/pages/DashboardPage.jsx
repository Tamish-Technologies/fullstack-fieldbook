import { Link } from "react-router";
import { countRemaining } from "../lib/task-logic.js";

export default function DashboardPage({ tasks }) {
  const remaining = countRemaining(tasks);
  const completed = tasks.length - remaining;
  return (
    <section className="page-panel" aria-labelledby="dashboard-title">
      <p className="eyebrow">YOUR LEARNING DASHBOARD</p>
      <h1 id="dashboard-title" className="page-title">A little progress, every day.</h1>
      <p className="muted">This week connects a React interface to read-only API data and meaningful URLs.</p>
      <div className="stat-grid">
        <div className="stat"><strong>{tasks.length}</strong><span>Total tasks</span></div>
        <div className="stat"><strong>{remaining}</strong><span>To do</span></div>
        <div className="stat"><strong>{completed}</strong><span>Completed</span></div>
      </div>
      <div className="quick-links">
        <Link to="/tasks" className="pill-link">Manage tasks</Link>
        <Link to="/ideas" className="pill-link secondary-link">Find study ideas</Link>
      </div>
      <p className="muted small-note">Tasks are stored only in this browser using localStorage, not sent to the public ideas API.</p>
    </section>
  );
}
