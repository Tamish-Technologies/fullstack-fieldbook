import { useEffect, useState } from "react";

/** Read-only Week 7 bridge. Local React tasks are NOT synchronized yet. */
export default function ServerPage() {
  const [state, setState] = useState({ status: "loading", health: null, tasks: [], error: "" });
  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    async function load() {
      try {
        const [healthResponse, tasksResponse] = await Promise.all([
          fetch("/api/health", { signal: controller.signal }),
          fetch("/api/tasks", { signal: controller.signal })
        ]);
        if (!healthResponse.ok || !tasksResponse.ok) throw new Error("Backend returned an HTTP error.");
        const health = await healthResponse.json();
        const tasks = await tasksResponse.json();
        if (!Array.isArray(tasks.data)) throw new Error("Unexpected task response shape.");
        if (active) setState({ status: "success", health, tasks: tasks.data, error: "" });
      } catch (error) {
        if (!controller.signal.aborted && active) {
          setState({ status: "error", health: null, tasks: [], error: error.message });
        }
      }
    }
    load();
    return () => { active = false; controller.abort(); };
  }, []);
  return (
    <section className="page-panel" aria-labelledby="server-heading">
      <p className="eyebrow">WEEK 7 / BACKEND LAB</p>
      <h1 id="server-heading" className="page-title">Your first Express API.</h1>
      <p className="muted">This page makes two read-only requests to your Node.js backend through Vite's development proxy.</p>
      <p className="server-note"><strong>Separate data stores:</strong> My tasks still live in your browser. The backend tasks below live only in server memory and disappear when the server restarts.</p>
      {state.status === "loading" && <p role="status">Checking the API...</p>}
      {state.status === "error" && <div className="status-box status-error" role="alert">{state.error}<p>Start the backend with <code>npm run dev</code> in its own terminal, then reload this page.</p></div>}
      {state.status === "success" && <>
        <div className="server-grid">
          <div className="server-card">Server status<strong>{state.health.status}</strong></div>
          <div className="server-card">Backend tasks<strong>{state.tasks.length}</strong></div>
        </div>
        {state.tasks.length ? <ul className="server-list">{state.tasks.map((task) => <li key={task.id}>{task.title} {task.completed ? "(done)" : "(pending)"}</li>)}</ul> : <p className="muted">The in-memory API has no tasks yet. Use POST /api/tasks in your API tool, then reload this page.</p>}
      </>}
    </section>
  );
}
