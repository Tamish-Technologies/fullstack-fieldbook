import { useEffect, useState } from "react";
import { Link } from "react-router";
import { fetchIdeas } from "../lib/ideas-api.js";
import { SAMPLE_IDEAS } from "../lib/sample-ideas.js";

export default function IdeasPage({ onAddIdea }) {
  const [source, setSource] = useState("remote"); // remote | offline
  const [retryKey, setRetryKey] = useState(0);
  const [remote, setRemote] = useState({ status: "loading", ideas: [], error: "" });
  const state = source === "offline"
    ? { status: "success", ideas: SAMPLE_IDEAS, error: "" }
    : remote;

  useEffect(() => {
    if (source !== "remote") return;
    const controller = new AbortController();
    let active = true;
    setRemote({ status: "loading", ideas: [], error: "" });
    fetchIdeas({ signal: controller.signal })
      .then((ideas) => {
        if (!active) return;
        setRemote({ status: ideas.length ? "success" : "empty", ideas, error: "" });
      })
      .catch((error) => {
        if (!active || error.name === "AbortError") return;
        setRemote({ status: "error", ideas: [], error: error.message });
      });
    return () => {
      active = false;   // ignore any late response
      controller.abort(); // ask the browser to cancel the request
    };
  }, [source, retryKey]);

  function tryAgain() {
    setSource("remote");
    setRetryKey((value) => value + 1);
  }

  return (
    <section className="page-panel" aria-labelledby="ideas-heading">
      <p className="eyebrow">READ-ONLY PUBLIC API</p>
      <h1 id="ideas-heading" className="page-title">Study Idea Inbox</h1>
      <p className="muted">Load example ideas, then copy useful ones into <Link to="/tasks">your own tasks</Link>. The API does not store your tasks.</p>
      <div className="idea-controls">
        <button type="button" onClick={tryAgain}>Fetch ideas</button>
        <button type="button" className="quiet-button" onClick={() => setSource("offline")}>
          Use offline examples
        </button>
      </div>
      <div className="source-line" aria-live="polite">Source: {source === "offline" ? "offline examples" : "JSONPlaceholder test API"}</div>
      {state.status === "loading" && <p className="status-box" role="status">Loading ideas...</p>}
      {state.status === "error" && (
        <div className="status-box status-error" role="alert">
          <strong>Could not load ideas.</strong>
          <p>{state.error}</p>
          <p>Inspect the browser Network tab. You can retry or switch to offline examples.</p>
        </div>
      )}
      {state.status === "empty" && <p className="status-box" role="status">The API returned no usable ideas.</p>}
      {state.status === "success" && (
        <ul className="idea-list" aria-label="Study ideas">
          {state.ideas.map((idea) => (
            <li className="idea-item" key={idea.id}>
              <span>{idea.title}</span>
              <button type="button" onClick={() => onAddIdea(idea)} aria-label={`Add idea: ${idea.title}`}>
                Add to tasks
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="muted small-note">Saving a copied idea assigns a new local task ID. Multiple clicks create separate local tasks by design.</p>
    </section>
  );
}
