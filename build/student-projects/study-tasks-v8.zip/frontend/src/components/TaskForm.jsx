import { useState } from "react";
import { validateTitle } from "../lib/task-logic.js";

export default function TaskForm({ onAdd }) {
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(event) {
    event.preventDefault();
    const result = validateTitle(draft);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onAdd(result.title);
    setDraft("");
    setError("");
  }

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <label htmlFor="task-title">Add a study task</label>
      <div className="form-row">
        <input
          id="task-title"
          type="text"
          value={draft}
          onChange={(event) => {
            setDraft(event.target.value);
            if (error) setError("");
          }}
          placeholder="e.g. Revise JavaScript arrays"
        />
        <button type="submit">Add task</button>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
    </form>
  );
}
