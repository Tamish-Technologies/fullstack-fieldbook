import { useState } from "react";

export default function TaskItem({ task, onToggle, onDelete, onRename }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(task.title);
  const [error, setError] = useState("");

  function saveEdit(event) {
    event.preventDefault();
    const result = onRename(task.id, draft);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setEditing(false);
    setError("");
  }

  if (editing) {
    return (
      <li className="task-item">
        <form className="edit-form" onSubmit={saveEdit}>
          <label className="sr-only" htmlFor={`edit-${task.id}`}>Edit {task.title}</label>
          <input
            id={`edit-${task.id}`}
            type="text"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
          />
          <button type="submit">Save</button>
          <button
            type="button"
            className="quiet-button"
            onClick={() => { setEditing(false); setDraft(task.title); setError(""); }}
          >Cancel</button>
          {error && <p className="error edit-error" role="alert">{error}</p>}
        </form>
      </li>
    );
  }

  return (
    <li className={`task-item${task.completed ? " completed" : ""}`}>
      <label className="task-label">
        <input
          type="checkbox"
          checked={task.completed}
          onChange={() => onToggle(task.id)}
        />
        <span>{task.title}</span>
      </label>
      <div className="task-actions">
        <button
          type="button"
          className="quiet-button"
          onClick={() => { setDraft(task.title); setEditing(true); }}
          aria-label={`Edit task: ${task.title}`}
        >Edit</button>
        <button
          type="button"
          className="delete-button"
          onClick={() => onDelete(task.id)}
          aria-label={`Delete task: ${task.title}`}
        >Delete</button>
      </div>
    </li>
  );
}
