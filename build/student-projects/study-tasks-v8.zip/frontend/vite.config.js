import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Local-development proxy, NOT a production hosting configuration.
export default defineConfig({
  plugins: [react()],
  server: { host: "127.0.0.1", proxy: { "/api": "http://127.0.0.1:3001" } }
});
