# Review log

AI is optional. Record either a bounded AI suggestion or your own review. Write the question, a redacted summary of the proposal, what you accepted or rejected, and the local command or check you used. Do not copy secrets, exact session identifiers, or raw private logs.

| Question | Suggestion or decision | Accepted or rejected and why | Verification |
| --- | --- | --- | --- |
| | | | |
