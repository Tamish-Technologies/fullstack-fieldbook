import { useState } from "react";
export default function AuthPage({ onSubmit, onModeChange, error, busy = false }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [localError, setLocalError] = useState("");
  async function submit(event) {
    event.preventDefault(); setLocalError("");
    if (mode === "register" && (password.length < 12 || password.length > 128)) {
      setLocalError("Choose a practice password with 12–128 characters."); return;
    }
    await onSubmit(mode, email, password);
  }
  function switchMode() { setMode((v) => v === "login" ? "register" : "login"); setPassword(""); setLocalError(""); onModeChange(); }
  return (
    <main className="auth-shell">
      <div className="auth-intro">
        <div className="brand-symbol" aria-hidden="true">S</div>
        <p className="eyebrow">STUDY TASKS / WEEK 12</p>
        <h1>Study Tasks</h1>
        <p>Sign in to open your private practice tasks.</p>
        <div className="auth-safeguard">Use a fictional email address and a password you use only for this project.</div>
      </div>
      <form className="auth-card" onSubmit={submit} aria-labelledby="auth-form-title">
        <h2 id="auth-form-title">{mode === "login" ? "Sign in" : "Register"}</h2>
        <label htmlFor="auth-email">Email address</label>
        <input id="auth-email" type="email" autoComplete="email" required maxLength={254}
          value={email} onChange={(e) => setEmail(e.target.value)} disabled={busy}/>
        <label htmlFor="auth-password">Password</label>
        <input id="auth-password" type="password" required aria-describedby={mode === "register" ? "password-rules" : undefined}
          autoComplete={mode === "login" ? "current-password" : "new-password"}
          value={password} onChange={(e) => setPassword(e.target.value)} disabled={busy} />
        {mode === "register" && <p className="auth-hint" id="password-rules">Use 12–128 characters. Avoid a password you use elsewhere.</p>}
        {(localError || error) && <p className="auth-error" role="alert">{localError || error}</p>}
        <button type="submit" disabled={busy}>{busy ? "Working..." : mode === "login" ? "Sign in" : "Create account"}</button>
        <button type="button" className="auth-switch" onClick={switchMode} disabled={busy}>
          {mode === "login" ? "New here? Create an account" : "Already have an account? Sign in"}
        </button>
      </form>
    </main>
  );
}
