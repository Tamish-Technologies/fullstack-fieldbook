import { Link, NavLink, Route, Routes } from "react-router";
import DashboardPage from "./pages/DashboardPage.jsx";
import TasksPage from "./pages/TasksPage.jsx";
import IdeasPage from "./pages/IdeasPage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";
import ServerPage from "./pages/ServerPage.jsx";
import AuthPage from "./pages/AuthPage.jsx";
import { useServerTasks } from "./hooks/useServerTasks.js";
import { useAuth } from "./hooks/useAuth.js";

function SignedInApp({ user, onLogout, onUnauthorized, authError, signingOut }) {
  // Mount task data only when signed in: prevents cross-account stale React state.
  const data = useServerTasks({ onUnauthorized });
  return (
    <div className="app-shell">
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-symbol" aria-hidden="true">S</span>
          <span><strong>Study Tasks</strong><small>v12 / Task planning</small></span>
        </Link>
        <nav className="site-nav" aria-label="Main navigation">
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/tasks">My tasks</NavLink>
          <NavLink to="/ideas">Idea inbox</NavLink>
          <NavLink to="/server">API lab</NavLink>
        </nav>
        <div className="user-menu"><span title={user.email}>{user.email}</span>
          <button type="button" className="signout-button" disabled={signingOut} onClick={onLogout}>{signingOut ? "Signing out…" : "Sign out"}</button></div>
      </header>
      {authError && <p className="auth-error banner-error" role="alert">{authError}</p>}
      <main className="content">
        <Routes>
          <Route path="/" element={<DashboardPage tasks={data.tasks} status={data.status} error={data.loadError} onRetry={data.retry} />} />
          <Route path="/tasks" element={<TasksPage tasks={data.tasks}
            status={data.status} loadError={data.loadError}
            mutationError={data.mutationError} busy={data.busy} onRetry={data.retry}
            onAdd={data.add} onToggle={data.toggle} onDelete={data.remove} onRename={data.rename} />} />
          <Route path="/ideas" element={<IdeasPage onAddIdea={(idea) => data.add(idea.title)}
            tasksReady={data.status === "ready"} busy={data.busy} />} />
          <Route path="/server" element={<ServerPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <footer className="site-footer">Phase 1 / Week 12 · Task planning capstone</footer>
    </div>
  );
}
export default function App() {
  const auth = useAuth();
  if (auth.status === "loading") return <main className="auth-loading"><p role="status">Checking your session…</p></main>;
  if (auth.status === "error") return <main className="auth-loading">
    <h1>Session check unavailable</h1>
    <p role="alert">{auth.error} Start the local backend and check its health address.</p>
    <button type="button" onClick={auth.retry}>Retry session check</button>
  </main>;
  if (!auth.user) return <AuthPage onSubmit={auth.submit} onModeChange={auth.clearError} error={auth.error} busy={auth.status === "submitting"}/>;
  return <SignedInApp key={auth.user.id} user={auth.user} signingOut={auth.status === "signingout"} onLogout={auth.logout}
    onUnauthorized={auth.markSignedOut} authError={auth.error}/>;
}
