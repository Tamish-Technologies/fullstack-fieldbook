import test from "node:test";
import assert from "node:assert/strict";
import {validDateOnly,validatePlanning,addUtcDays,isOverdue,isDueSoon,planningSummary,todayUTC} from "../src/lib/planning.js";
const task=(props={})=>({id:1,title:"Read",completed:false,priority:"medium",dueDate:null,...props});
test("validDateOnly recognizes leap years and rejects invalid date-only strings",()=>{
  assert.equal(validDateOnly("2028-02-29"),true);
  for(const date of ["2027-02-29","2026-02-30","2026-13-01","2026-1-1","0000-01-01",undefined])
    assert.equal(validDateOnly(date),false);
});
test("planning validates and supports an unset due date",()=>{
  assert.deepEqual(validatePlanning({priority:"high",dueDate:null}),{ok:true,value:{priority:"high",dueDate:null}});
  assert.equal(validatePlanning({priority:"urgent"}).ok,false);
  assert.equal(validatePlanning({dueDate:"2026-02-30"}).ok,false);
});
test("UTC calendar arithmetic crosses month, year and leap-day boundaries",()=>{
  assert.equal(addUtcDays("2026-12-29",7),"2027-01-05");
  assert.equal(addUtcDays("2028-02-28",1),"2028-02-29");
  assert.equal(todayUTC(new Date("2026-11-15T23:59:59.000Z")),"2026-11-15");
});
test("due soon means unfinished tasks due today through day seven",()=>{
  const today="2026-11-15";
  assert.equal(isDueSoon(task({dueDate:"2026-11-15"}),today),true);
  assert.equal(isDueSoon(task({dueDate:"2026-11-22"}),today),true);
  assert.equal(isDueSoon(task({dueDate:"2026-11-23"}),today),false);
  assert.equal(isDueSoon(task({dueDate:"2026-11-14"}),today),false);
  assert.equal(isDueSoon(task({dueDate:"2026-11-17",completed:true}),today),false);
});
test("overdue excludes completed tasks and absent dates",()=>{
  assert.equal(isOverdue(task({dueDate:"2026-11-14"}),"2026-11-15"),true);
  assert.equal(isOverdue(task({dueDate:"2026-11-14",completed:true}),"2026-11-15"),false);
  assert.equal(isOverdue(task(),"2026-11-15"),false);
});
test("dashboard summary is a pure, stable counting function",()=>{
  const tasks=[task({dueDate:"2026-11-14",priority:"high"}),
    task({id:2,dueDate:"2026-11-20"}),task({id:3,dueDate:null,priority:"high",completed:true}),
    task({id:4,dueDate:"2026-12-01"})];
  const before=JSON.stringify(tasks);
  assert.deepEqual(planningSummary(tasks,"2026-11-15"),{overdue:1,dueSoon:1,high:1});
  assert.equal(JSON.stringify(tasks),before);
});
