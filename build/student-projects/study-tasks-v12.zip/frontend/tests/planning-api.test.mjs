import test from "node:test";
import assert from "node:assert/strict";
import { createTaskApi } from "../src/lib/task-api.js";

const example = {
  id: 7, title: "Read MDN", completed: false, createdAt: "2026-11-14T00:00:00.000Z",
  priority: "high", dueDate: "2026-12-01",
};

test("POST sends selected planning fields when supplied", async () => {
  let body;
  const api = createTaskApi(async (_path, options) => {
    body = JSON.parse(options.body);
    return Response.json({ data: example }, { status: 201 });
  });
  assert.deepEqual(await api.create("Read MDN", { priority: "high", dueDate: "2026-12-01" }), example);
  assert.deepEqual(body, { title: "Read MDN", priority: "high", dueDate: "2026-12-01" });
});

test("API client rejects a returned impossible date", async () => {
  const api = createTaskApi(async () => Response.json({ data: { ...example, dueDate: "2026-02-30" } }));
  await assert.rejects(api.update(7, { priority: "high" }), (error) => error.code === "BAD_RESPONSE");
});
