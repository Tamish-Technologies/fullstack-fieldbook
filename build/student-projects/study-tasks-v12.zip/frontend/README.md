# Week 12 frontend

Use [START_HERE.md](../START_HERE.md) for lockfile setup, baseline commands, migration and the built preview. [STUDENT_EXERCISES.md](../STUDENT_EXERCISES.md) lists the planning implementation and evidence tasks. The archived project is a learner starter with unfinished planning fields.
