# Task Planning v12 brief

Add priority (low, medium, high) and a nullable calendar due date to the existing private task manager. Preserve the old title-only request, saved tasks, and ownership. Keep the dashboard and hosting optional.

## Fill in before changing code

- Who needs the feature and what problem does it solve?
- Two user stories with observable outcomes
- One deferred task
- The baseline commit and the new branch
- The planned schema, validation, response fields and owner source
- The date-only policy and how the browser clears a date
- Reviewable implementation steps and which A01–A10 evidence goes with each
- Backup or rollback plan for the isolated learner environment

See EVIDENCE_LOG.md for the acceptance contract.
