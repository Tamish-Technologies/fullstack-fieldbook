import { readFile } from "node:fs/promises";
import { createDbPool } from "../src/db.js";

const pool = createDbPool();
let client;
let step = "connect";
try {
  client = await pool.connect();
  const { rows: [{ database }] } = await client.query("SELECT current_database() AS database");
  if (database.endsWith("_test")) throw new Error("test target");
  const migrations = ["001_create_tasks.sql", "002_create_users_sessions_and_user_tasks.sql"];
  if (process.argv.includes("--planning")) migrations.push("003_add_planning_fields.sql");
  console.log("Development database:", JSON.stringify(database));
  await client.query("BEGIN");
  for (const filename of migrations) {
    step = filename;
    await client.query(await readFile(new URL(`../migrations/${filename}`, import.meta.url), "utf8"));
  }
  if (process.argv.includes("--planning")) {
    step = "verify planning columns";
    const columns = await client.query(`
      SELECT column_name FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'user_tasks'
        AND column_name IN ('priority', 'due_date')
    `);
    if (columns.rowCount !== 2) throw new Error("incomplete migration");
  }
  await client.query("COMMIT");
  console.log("Applied:", migrations.join(", "));
} catch {
  if (client) await client.query("ROLLBACK").catch(() => {});
  const advice = step === "verify planning columns"
    ? "Complete migration 003 before running npm run migrate:planning."
    : "Check the isolated development target, permissions and migration file.";
  console.error("Migration did not complete.", advice);
  process.exitCode = 1;
} finally {
  client?.release();
  await pool.end();
}
