import session from "express-session";
import connectPgSimple from "connect-pg-simple";
const PgStore = connectPgSimple(session);
export const sessionCookieName = "study.w12.sid";
/** A persistent server-side session store; NEVER use MemoryStore in production. */
export function createSessionMiddleware(pool, { secret, isProduction = false, schemaName } = {}) {
  if (!secret || secret.includes("REPLACE_WITH") || Buffer.byteLength(secret, "utf8") < 32) {
    throw new Error("SESSION_SECRET needs at least 32 random bytes; see .env.example.");
  }
  return session({
    name: sessionCookieName,
    secret,
    store: new PgStore({ pool, tableName: "user_sessions", createTableIfMissing: false, schemaName,
      errorLog: () => console.error(JSON.stringify({ event: "session_store_error" })) }),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { httpOnly: true, sameSite: "lax", secure: isProduction, maxAge: 30 * 60 * 1000 }
  });
}
