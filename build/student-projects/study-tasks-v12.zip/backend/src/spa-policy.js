/** Pure, testable policy: HTML SPA navigation must never swallow API requests. */
export function wantsHtmlNavigation(req) {
  return req.method === "GET" && (req.get("accept") || "").includes("text/html") &&
    !/^\/api(?:\/|$)/i.test(req.path);
}
