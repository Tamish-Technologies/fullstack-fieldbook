import { randomUUID } from "node:crypto";
/** Structured request IDs: never log request bodies, cookies, tokens or raw query strings. */
export function createRequestLog({ logger = console.info, makeId = randomUUID, clock = Date.now } = {}) {
  return (req, res, next) => {
    const started = clock();
    const requestId = makeId(); // never trust a client-supplied request ID as an authorization token
    req.requestId = requestId;
    res.setHeader("X-Request-ID", requestId);
    res.on("finish", () => {
      if (typeof logger !== "function") return;
      const route = req.route?.path ?? (req.path === "/api/health" || req.path === "/api/live" ? req.path : "unmatched");
      logger(JSON.stringify({ event: "http_request", requestId, method: req.method,
        route, status: res.statusCode, elapsedMs: Math.max(0, clock() - started) }));
    });
    next();
  };
}
