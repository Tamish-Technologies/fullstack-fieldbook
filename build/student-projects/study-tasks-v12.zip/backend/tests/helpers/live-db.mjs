import test from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { once } from "node:events";
import { readFile } from "node:fs/promises";
import { createApp } from "../../src/app.js";
import { createDbPool } from "../../src/db.js";
import { createSessionMiddleware } from "../../src/session.js";
import { createUserRepository } from "../../src/auth-repository.js";
import { createTaskRepository } from "../../src/task-repository.js";

function targetName(value) {
  try {
    const url = new URL(value);
    if (["postgres:", "postgresql:"].includes(url.protocol)) {
      return decodeURIComponent(url.pathname.slice(1));
    }
  } catch {
    // Never print connection URLs, including malformed values.
  }
  return "";
}

const testURL = process.env.TEST_DATABASE_URL;
const testName = targetName(testURL);
const devName = targetName(process.env.DATABASE_URL);
if (!devName || !testName.endsWith("_test") || devName === testName) {
  throw Error("Use a separate TEST_DATABASE_URL whose database name ends in _test.");
}

const origin = "http://127.0.0.1:5173";
const practicePassword = "One fictional passphrase";

function browserSession(base) {
  let cookie = "";
  return {
    async request(path, { method = "GET", body, site = origin } = {}) {
      const headers = {};
      if (method !== "GET") headers.Origin = site;
      if (cookie) headers.Cookie = cookie;
      if (body !== undefined) headers["Content-Type"] = "application/json";
      const res = await fetch(base + path, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      const header = res.headers.get("set-cookie");
      if (header) cookie = header.split(";", 1)[0];
      const raw = await res.text();
      return {
        status: res.status,
        body: raw ? JSON.parse(raw) : null,
        httpOnly: /;\s*httponly\b/i.test(header ?? ""),
        sameSite: /;\s*samesite=lax\b/i.test(header ?? ""),
      };
    },
  };
}

export function verifyLiveDatabase({ planning = false } = {}) {
  test(planning ? "Capstone migration, planning fields and owner scope" : "PostgreSQL sessions, own CRUD, and denied access preserve both accounts", async () => {
  const pool = createDbPool(testURL);
  const schema = "week12_check_" + randomBytes(10).toString("hex");
  let client;
  let server;
  let ownsSchema = false;
  try {
    client = await pool.connect();
    const current = await client.query("SELECT current_database() AS name");
    if (current.rows[0]?.name !== testName || current.rows[0]?.name === devName) {
      throw Error("The connected database did not match the separate _test target.");
    }
    await client.query(`CREATE SCHEMA "${schema}"`);
    ownsSchema = true;
    await client.query(`SET search_path TO "${schema}"`);
    for (const filename of ["001_create_tasks.sql", "002_create_users_sessions_and_user_tasks.sql"]) {
      await client.query(await readFile(new URL(`../../migrations/${filename}`, import.meta.url), "utf8"));
    }
    if (planning) {
      const { rows: [owner] } = await client.query(
        "INSERT INTO users(email, password_hash) VALUES ($1, $2) RETURNING id",
        ["legacy@example.test", "synthetic-fixture"],
      );
      const title = "Existing privately owned task";
      const { rows: [legacy] } = await client.query(
        "INSERT INTO user_tasks(owner_id, title) VALUES ($1, $2) RETURNING id, owner_id, title",
        [owner.id, title],
      );
      const sql = await readFile(new URL("../../migrations/003_add_planning_fields.sql", import.meta.url), "utf8");
      await client.query(sql);
      const { rows: [retained] } = await client.query(
        "SELECT id, owner_id, title, priority, due_date FROM user_tasks WHERE id = $1", [legacy.id],
      );
      assert.deepEqual(retained, { ...legacy, priority: "medium", due_date: null });
    }
    const app = createApp({
      repository: createTaskRepository(client),
      users: createUserRepository(client),
      sessionMiddleware: createSessionMiddleware(pool, {
        secret: randomBytes(48).toString("hex"), schemaName: schema,
      }),
      expectedOrigin: origin, enableLogging: false, enableRateLimit: false,
    });
    server = app.listen(0, "127.0.0.1");
    await once(server, "listening");
    const base = `http://127.0.0.1:${server.address().port}`;
    const owner = browserSession(base);
    const other = browserSession(base);
    assert.equal((await owner.request("/api/tasks")).status, 401);

    const register = (browser, email) => browser.request("/api/auth/register", {
      method: "POST", body: { email, password: practicePassword },
    });
    const a = await register(owner, "  ALICE@Example.Test ");
    const b = await register(other, "bob@example.test");
    assert.equal(a.status, 201, "The real signup should complete.");
    assert.equal(b.status, 201);
    assert.deepEqual(Object.keys(a.body.user).sort(), ["email", "id"]);
    assert.equal(a.body.user.email, "alice@example.test");
    assert.ok(a.httpOnly && a.sameSite);
    assert.equal((await register(other, "alice@example.test")).status, 409);
    assert.equal((await owner.request("/api/auth/me")).body.user.id, a.body.user.id);
    const verified = await client.query(
      "SELECT password_hash LIKE '$argon2id$%' AS hashed FROM users WHERE id = $1",
      [a.body.user.id],
    );
    assert.equal(verified.rows[0].hashed, true);

    const create = (browser, title) => browser.request("/api/tasks", { method: "POST", body: { title } });
    const mine = await create(owner, "Owner's practice task");
    assert.equal(mine.status, 201);
    const yours = await create(other, "Other practice task");
    assert.equal(yours.status, 201);
    const original = mine.body.data;
    if (planning) {
      assert.equal(original.priority, "medium");
      assert.equal(original.dueDate, null);
      const save = await owner.request("/api/tasks", {
        method: "POST", body: { title: "Review leap day", priority: "high", dueDate: "2028-02-29" },
      });
      assert.equal(save.status, 201);
      const itemPath = "/api/tasks/" + save.body.data.id;
      assert.equal(save.body.data.priority, "high");
      assert.equal(save.body.data.dueDate, "2028-02-29");
      const patch = (browser, body) => browser.request(itemPath, { method: "PATCH", body });
      const changed = await patch(owner, { priority: "low" });
      assert.equal(changed.status, 200);
      assert.equal(changed.body.data.priority, "low");
      assert.equal(changed.body.data.dueDate, "2028-02-29");
      for (const body of [{ dueDate: "2026-02-30" }, { priority: "urgent" }]) {
        assert.equal((await patch(owner, body)).status, 400);
      }
      assert.equal((await patch(other, { priority: "high", dueDate: null })).status, 404);
      assert.equal((await other.request(itemPath)).status, 404);
      assert.equal((await other.request(itemPath, { method: "DELETE" })).status, 404);
      assert.deepEqual((await owner.request(itemPath)).body.data, changed.body.data);
      const cleared = await patch(owner, { dueDate: null });
      assert.equal(cleared.status, 200);
      assert.equal(cleared.body.data.dueDate, null);
      assert.equal(cleared.body.data.priority, "low");
      assert.equal((await owner.request(itemPath, { method: "DELETE" })).status, 204);
    }
    const path = "/api/tasks/" + original.id;
    assert.deepEqual((await owner.request("/api/tasks")).body.data, [original]);
    assert.deepEqual((await other.request("/api/tasks")).body.data, [yours.body.data]);
    const denied = await other.request(path);
    assert.equal(denied.status, 404);
    assert.deepEqual(denied.body, (await other.request("/api/tasks/2147483647")).body);
    assert.equal((await other.request(path, { method: "PATCH", body: { completed: true } })).status, 404);
    assert.equal((await other.request(path, { method: "DELETE" })).status, 404);
    assert.equal((await owner.request(path, {
      method: "PATCH", body: { completed: true }, site: "https://different.example.test",
    })).status, 403);
    assert.deepEqual((await owner.request(path)).body.data, original);
    assert.equal((await owner.request(path, { method: "PATCH", body: { completed: true } })).body.data.completed, true);
    assert.equal((await owner.request(path, { method: "PATCH", body: { completed: false } })).body.data.completed, false);
    assert.equal((await owner.request(path, { method: "DELETE" })).status, 204);
    assert.equal((await owner.request(path)).status, 404);
    assert.equal((await other.request("/api/tasks")).body.count, 1);

    const out = await owner.request("/api/auth/logout", { method: "POST" });
    assert.equal(out.status, 204);
    assert.equal(out.body, null);
    assert.equal((await owner.request("/api/auth/me")).status, 401);
    const sessionRows = await client.query("SELECT count(*)::int AS count FROM user_sessions");
    assert.equal(sessionRows.rows[0].count, 1, "Only the other account should retain a session.");
    const login = await owner.request("/api/auth/login", {
      method: "POST", body: { email: "alice@example.test", password: practicePassword },
    });
    assert.equal(login.status, 200);
    assert.equal((await owner.request("/api/auth/me")).body.user.id, a.body.user.id);
  } finally {
    try {
      if (server?.listening) await new Promise((resolve, reject) =>
        server.close((error) => error ? reject(error) : resolve()));
      if (ownsSchema) {
        for (const table of ["user_sessions", "user_tasks", "users", "tasks"]) {
          await client.query(`DROP TABLE IF EXISTS "${schema}".${table}`);
        }
        await client.query(`DROP SCHEMA "${schema}"`);
      }
    } finally {
      client?.release();
      await pool.end();
    }
  }
});
}
