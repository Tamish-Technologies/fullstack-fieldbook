import test from "node:test";
import assert from "node:assert/strict";
import { createTaskRepository } from "../src/task-repository.js";
const row = { id: 2, title: "My private task", completed: false, created_at: new Date("2026-01-01Z") };
function fakePool(rows=[row],rowCount=1) {
  const queries=[];
  return { queries, async query(sql,values=[]) { queries.push({sql,values}); return {rows,rowCount}; } };
}
test("LIST always filters by owner ID (including completed filter)",async () => {
  const pool=fakePool();const repo=createTaskRepository(pool);
  await repo.list("alice");await repo.list("bob",{completed:false});
  assert.match(pool.queries[0].sql,/FROM user_tasks WHERE owner_id = \$1/);
  assert.deepEqual(pool.queries[0].values,["alice"]);
  assert.match(pool.queries[1].sql,/owner_id = \$1 AND completed = \$2/);
  assert.deepEqual(pool.queries[1].values.slice(0, 4),["bob",false]);
});
test("GET, PATCH, DELETE target both owner and task ID", async () => {
  const pool=fakePool();const repo=createTaskRepository(pool);
  await repo.get("alice",2);await repo.update("alice",2,{completed:false});await repo.remove("alice",2);
  for(const call of pool.queries) {
    assert.match(call.sql,/owner_id = \$1 AND id = \$2/);
    assert.deepEqual(call.values.slice(0,2),["alice",2]);
  }
  assert.deepEqual(pool.queries[1].values.slice(0, 4),["alice",2,null,false]);
});
test("CREATE inserts the owner ID as a parameter, not client-provided data",async () => {
  const pool=fakePool();const repo=createTaskRepository(pool);
  await repo.create("verified-user",{title:"Test"});
  assert.match(pool.queries[0].sql,/INSERT INTO user_tasks \(owner_id, title(?:, priority, due_date)?\)/);
  assert.deepEqual(pool.queries[0].values.slice(0, 2),["verified-user","Test"]);
});
test("missing rows return null or false",async () => {
  const repo=createTaskRepository(fakePool([],0));
  assert.equal(await repo.get("a",888),null);
  assert.equal(await repo.update("a",888,{completed:true}),null);
  assert.equal(await repo.remove("a",888),false);
});
