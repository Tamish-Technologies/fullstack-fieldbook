import { verifyLiveDatabase } from "./helpers/live-db.mjs";
verifyLiveDatabase({ planning: true });
