import test from "node:test";
import assert from "node:assert/strict";
import {validateCreateBody,validatePatchBody} from "../src/validation.js";
import {createTaskRepository,toApiTask} from "../src/task-repository.js";
const row={id:21,title:"Prepare for exam",completed:false,priority:"high",due_date:"2026-12-01",created_at:new Date("2026-11-01Z")};
function pool(rows=[row]) {const calls=[];return {calls,async query(sql,params){calls.push({sql,params});return {rows,rowCount:rows.length};}};}
test("create accepts priority and exact calendar dueDate",()=>{
  assert.deepEqual(validateCreateBody({title:"  Read lesson ",priority:"high",dueDate:"2028-02-29"}),
    {ok:true,value:{title:"Read lesson",priority:"high",dueDate:"2028-02-29"}});
});
test("old title-only create is still supported",()=>{
  assert.deepEqual(validateCreateBody({title:" Read MDN "}),{ok:true,value:{title:"Read MDN"}});
});
test("reject impossible dates and unknown priorities",()=>{
  for (const dueDate of ["2026-02-30","2027-02-29","2026-13-01","11/14/2026","2026-2-5","0000-01-01",42])
    assert.equal(validateCreateBody({title:"X",dueDate}).ok,false,`not a valid date: ${dueDate}`);
  assert.equal(validateCreateBody({title:"X",priority:"urgent"}).ok,false);
});
test("patch permits explicit null to remove due date",()=>{
  assert.deepEqual(validatePatchBody({dueDate:null}),{ok:true,value:{dueDate:null}});
  assert.deepEqual(validatePatchBody({completed:false,priority:"low"}),{ok:true,value:{completed:false,priority:"low"}});
});
test("patch rejects unauthorized fields and bad types",()=>{
  for (const patch of [{ownerId:"another"},{dueDate:false},{priority:null},{priority:"HIGH"},{dueDate:""}])
    assert.equal(validatePatchBody(patch).ok,false);
});
test("SQL creation remains owner-scoped and parameterized",async()=>{
  const p=pool();const repository=createTaskRepository(p);
  const task=await repository.create("alice",{title:"Plan",priority:"high",dueDate:"2026-12-01"});
  assert.equal(task.priority,"high");assert.equal(task.dueDate,"2026-12-01");
  assert.match(p.calls[0].sql,/owner_id, title, priority, due_date/);
  assert.deepEqual(p.calls[0].params,["alice","Plan","high","2026-12-01"]);
});
test("omitted dueDate in update preserves row; null clears row",async()=>{
  const p=pool();const repository=createTaskRepository(p);
  await repository.update("alice",21,{priority:"low"});
  await repository.update("alice",21,{dueDate:null});
  assert.deepEqual(p.calls[0].params,["alice",21,null,null,"low",false,null]);
  assert.deepEqual(p.calls[1].params,["alice",21,null,null,null,true,null]);
  for(const call of p.calls)assert.match(call.sql,/WHERE owner_id = \$1 AND id = \$2/);
});
test("date-only API response is not shifted by local time zones",()=>{
  assert.equal(toApiTask(row).dueDate,"2026-12-01");
  assert.equal(toApiTask({...row,due_date:null}).dueDate,null);
});
