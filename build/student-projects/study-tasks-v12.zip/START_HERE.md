# Study Tasks v12 capstone

You inherit the working Week 11 study app. Add priority and an optional calendar due date across the database, API, and interface. Use fictional local accounts. Open CAPSTONE_BRIEF.md and STUDENT_EXERCISES.md alongside the Fieldbook lessons.

## 1. Establish the baseline

Use Node 22.12+ or Node 24, npm, Git and PostgreSQL 17. Extract both folders together. From this project root run:

```sh
npm --prefix backend ci
npm --prefix frontend ci
npm --prefix backend run test:baseline
npm --prefix frontend run test:baseline
```

The baseline suites check inherited behavior. Run `npm --prefix backend test` and `npm --prefix frontend test` as well. Expect the new planning checks to fail until you build the feature. The failing names explain what still needs work.

If the ZIP has no Git history, use `git init` here. Verify any local environment files are ignored, inspect the staged files and commit your baseline. Create your local branch with `git switch -c week12/task-planning`. If you already have Git history, start from the baseline commit you intend to extend.

## 2. Prepare isolated local databases

Use your existing learning role or create one from your local PostgreSQL administrator connection with `CREATE ROLE study_tasks LOGIN;`. Set the private local password via the psql prompt `\password study_tasks` or pgAdmin's role dialog. Create new databases in separate statements outside a transaction.

```sql
CREATE DATABASE study_tasks_week12 OWNER study_tasks;
CREATE DATABASE study_tasks_week12_test OWNER study_tasks;
```

If either name exists, inspect its owner and contents before use. Connect to both and run `SELECT current_database(), current_user;`. Copy backend/.env.example to backend/.env, set URLs and a freshly generated session secret as shown by the example, and leave that file ignored. Percent-encode reserved characters in database passwords in the URLs. The test targets must differ.

From the project root run `npm --prefix backend run migrate` for the baseline tables. Run `npm --prefix frontend run build` then `npm --prefix backend run preview:local` for the built, same-origin app. Open the printed loopback address, normally http://127.0.0.1:3001. Verify create, reload, sign out, and account isolation. Keep that task for the migration comparison.

For development, start `npm run dev` separately in backend and frontend. Open the exact Vite address configured as WEB_ORIGIN. If the backend port is taken, change PORT in backend/.env and set the same number as STUDY_TASKS_API_PORT in frontend/.env.local. If the Vite port changes, match WEB_ORIGIN to the printed address. The built preview command sets the local origin for itself. Stop the earlier API before using that port for the preview.

## 3. Build the planning slice

Follow STUDENT_EXERCISES.md. Implement migration 003, then run `npm --prefix backend run migrate:planning`. Before extension the baseline migration still works and the planning command reports what is missing. Preserve the existing task and owner when adding fields. Finish the server validators and storage, then the React client and form.

Run the pure and HTTP tests again. When complete, use `npm --prefix backend run test:planning-db` on the verified disposable _test database. It tests the migration and API in its own temporary schema and includes the session and ownership checks from the baseline suite. Its two-account checks use fictional data. Use `test:db` only for the pre-planning baseline.

Build and start the built preview again. Demonstrate both accounts, refresh and restart of the API, and a controlled save failure. Record actual results in EVIDENCE_LOG.md and make a Ready for local demo or Hold decision in RELEASE_REPORT.md. No public host or AI service is required.
