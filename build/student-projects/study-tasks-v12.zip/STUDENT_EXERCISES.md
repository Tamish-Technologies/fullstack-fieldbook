# Independent capstone exercises

## 1. Start green on the inherited baseline

Follow START_HERE.md. Record a feasible scope in CAPSTONE_BRIEF.md. Run the baseline commands, create and reload a title-only task, and keep a fictional owner row to compare before and after migration.

## 2. Implement the migration and API contract

In backend/migrations/003_add_planning_fields.sql, add a constrained non-null priority defaulting to medium, and a nullable DATE. Preserve data. Make repeat execution safe and verify the same row ID and owner. Apply with `npm --prefix backend run migrate:planning`.

In backend/src/validation.js, extend create and patch inputs. Keep omitted create fields valid. Check calendar shape, month length, and leap-year rules. Preserve the difference between a missing field and explicit null. Reject extra fields. Keep title and completed checks unchanged.

Change backend/src/task-repository.js so every operation stays scoped to the verified owner. Select or return priority and date-only text. Bind the date-presence flag independently of its value in update. A CASE expression can keep the stored date on omission and assign SQL NULL on explicit clear. Use the parameter order expected in the planning tests. Preserve explicit false for completed.

## 3. Add the form and the pure helpers

Keep the inherited API call sites working, including adding an inbox idea by title. Extend the client response validation. In the task form and edit view give priority and optional date visible labels. Keep the draft until a save succeeds. Send null when clearing an existing date. A priority-only edit omits the unchanged date. Render the new values from the confirmed response.

Implement frontend/src/lib/planning.js. Use an explicit today value for pure comparisons. The optional dashboard may compute counts from confirmed tasks. The built preview can use the bundled idea examples with no network service.

## 4. Gather evidence and decide

Use the safe test database verification described in START_HERE.md. Complete EVIDENCE_LOG.md, review Git status and diff, and make a Ready or Hold decision in RELEASE_REPORT.md. Include the before-and-after migration evidence, tests, refresh and restart, both accounts, and failed-save behavior.

### Debug three cases

Record symptom, evidence, hypothesis, smallest safe experiment, fix, and regression check. Include the missing-versus-null case or the ownership case. Use the incomplete starter or a disposable local fixture for experiments.

1. A priority looks saved and resets on refresh. Trace the body, projection and row.
2. A deadline shifts a day. Compare the calendar string and any timezone conversion.
3. February 30 gets through. Compare format validation with actual month length.
4. A priority-only edit clears the date. Inspect the presence flag.
5. A second account can change a known task. Review server-derived identity and the write predicate, then rerun the safe denial check.
6. Clear date shows an error. Inspect whether the body includes blank text or null.
7. HTTP 400 still looks saved. Trace response checking to the state update.
8. A query fails after a schema change. Verify the migration target and columns.
9. A completed task counts as overdue. Inspect the pure helper inputs.
10. A review suggests replacing the table. Reject the destructive change and show a safe preservation test.

### Rehearse ten of these twenty prompts independently

Answer across React, HTTP, SQL, authorization, testing, and review. Do the rehearsal without an AI tool. A mentor may observe it if available.

1. Where is the create draft stored?
2. What keeps the form editable after a failed save?
3. How does a cleared date differ from an unchanged blank input?
4. What makes the date control usable from a keyboard?
5. Trace a save from the form to the confirmed card.
6. Why is response.ok needed with fetch?
7. Define the title-only POST response.
8. What differs between 400, 404 and 503?
9. Why is the due date a DATE?
10. How did your migration preserve IDs and owners?
11. How did you pass the presence flag to the database?
12. Where does the repository get the verified owner?
13. Why are both owner and task ID required in a mutation?
14. How did you prove the owner row remained unchanged?
15. Which test checks a century leap-year case?
16. What evidence shows real persistence after restart?
17. What can a fake pool test prove?
18. How did you verify a reviewed suggestion or your own hypothesis?
19. Which private values stay out of the work log?
20. Which failure would make your decision Hold?
