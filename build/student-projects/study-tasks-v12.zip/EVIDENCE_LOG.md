# Capstone evidence

Fill each row with pass, fail, or not run, the actual action or command, and the observed result. Use only fictional data. Keep passwords, environment URLs, cookie values, and raw logs out of this file.

| ID | Required result | Status | Actual action and observed result |
| --- | --- | --- | --- |
| A01 | Title-only POST gives 201, medium priority and null date | | |
| A02 | High priority and real date round-trip through the API and PostgreSQL | | |
| A03 | Priority-only PATCH preserves a saved date | | |
| A04 | Explicit null in PATCH clears it | | |
| A05 | Impossible date is 400 and the row stays unchanged | | |
| A06 | Invalid priority is 400 and the row stays unchanged | | |
| A07 | Same row and planning fields survive refresh and a new API process | | |
| A08 | Second account gets 404 for known foreign GET, PATCH and DELETE, and the owner row is unchanged | | |
| A09 | A failed save retains the draft, shows an error and leaves confirmed data unchanged | | |
| A10 | Reviewed commit, actual test results, demo evidence and independent explanation | | |

Baseline commit and results:
Migration before and after, including retained owner:
Three debugging records:
