import { useEffect, useRef, useState } from "react";
import { taskApi } from "../lib/task-api.js";
import { validateTitle } from "../lib/task-logic.js";

/** Server owns the source of truth. This hook owns the React copy of server data. */
export function useServerTasks({ onUnauthorized } = {}) {
  const [tasks, setTasks] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [loadError, setLoadError] = useState("");
  const [mutationError, setMutationError] = useState("");
  const [busy, setBusy] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const mutation = useRef(null);
  useEffect(() => () => mutation.current?.abort(), []);

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setStatus("loading");
    setLoadError("");
    setMutationError("");
    setTasks([]);

    taskApi.list({ signal: controller.signal })
      .then((serverTasks) => {
        if (!active) return;
        setTasks(serverTasks);
        setStatus("ready");
      })
      .catch((error) => {
        if (!active || error.name === "AbortError") return;
        if (error.status === 401) { onUnauthorized?.(); return; }
        setLoadError(error.message);
        setStatus("error");
      });
    return () => { active = false; controller.abort(); };
  }, [reloadKey, onUnauthorized]);

  function retry() {
    if (!mutation.current) setReloadKey((value) => value + 1);
  }

  async function mutate(action, applyResult) {
    if (mutation.current || status !== "ready") {
      return { ok: false, error: "Finish the current request before trying again." };
    }
    const controller = new AbortController();
    mutation.current = controller;
    setBusy(true);
    setMutationError("");
    try {
      const result = await action({ signal: controller.signal });
      if (controller.signal.aborted) return { ok: false };
      setTasks((previous) => applyResult(previous, result));
      return { ok: true, data: result };
    } catch (error) {
      if (controller.signal.aborted) return { ok: false };
      if (error.status === 401) onUnauthorized?.();
      setMutationError(error.message);
      return { ok: false, error: error.message };
    } finally {
      mutation.current = null;
      if (!controller.signal.aborted) setBusy(false);
    }
  }

  function add(title) {
    const check = validateTitle(title);
    if (!check.ok) return Promise.resolve(check);
    return mutate((options) => taskApi.create(check.title, options), (old, created) => [...old, created]);
  }

  function rename(id, title) {
    const check = validateTitle(title);
    if (!check.ok) return Promise.resolve(check);
    return mutate((options) => taskApi.update(id, { title: check.title }, options),
      (old, updated) => old.map((task) => task.id === id ? updated : task));
  }

  function toggle(task) {
    return mutate((options) => taskApi.update(task.id, { completed: !task.completed }, options),
      (old, updated) => old.map((row) => row.id === updated.id ? updated : row));
  }

  function remove(id) {
    return mutate((options) => taskApi.remove(id, options), (old) => old.filter((task) => task.id !== id));
  }

  return { tasks, status, loadError, mutationError, busy, retry, add, rename, toggle, remove };
}
