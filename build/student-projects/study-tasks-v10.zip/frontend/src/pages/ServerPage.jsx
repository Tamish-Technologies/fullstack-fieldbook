import { useEffect, useState } from "react";
import { taskApi } from "../lib/task-api.js";

/** The API lab uses the SAME service as the task manager. */
export default function ServerPage() {
  const [retryKey, setRetryKey] = useState(0);
  const [state, setState] = useState({ status: "loading", health: null, error: "" });
  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setState({ status: "loading", health: null, error: "" });
    taskApi.health({ signal: controller.signal })
      .then((health) => { if (active) setState({ status: "ready", health, error: "" }); })
      .catch((error) => { if (active && error.name !== "AbortError") {
        setState({ status: "error", health: null, error: error.message });
      }});
    return () => { active = false; controller.abort(); };
  }, [retryKey]);
  return (
    <section className="page-panel" aria-labelledby="server-heading">
      <p className="eyebrow">API DIAGNOSTICS</p>
      <h1 id="server-heading" className="page-title">API health</h1>
      <p className="muted">Check the health endpoint that powers the full-stack task manager.</p>
      <p className="server-note"><strong>Single source of truth:</strong> all task changes are sent to Express.
        The backend stores private tasks in PostgreSQL and requires a session for every task endpoint.</p>
      {state.status === "loading" && <p role="status">Checking the API...</p>}
      {state.status === "error" && <div className="status-box status-error" role="alert">
        {state.error}<p>Check the backend health address printed in its terminal, then retry.</p>
        <button type="button" onClick={() => setRetryKey(v => v + 1)}>Retry</button>
      </div>}
      {state.status === "ready" && <div className="server-grid">
        <div className="server-card">Server status<strong>{state.health.status}</strong></div>
        <div className="server-card">Storage engine<strong>{state.health.storage}</strong></div>
      </div>}
    </section>
  );
}
