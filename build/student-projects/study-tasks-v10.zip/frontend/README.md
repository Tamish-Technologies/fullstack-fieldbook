# Week 10 Study Tasks frontend

Follow [START_HERE.md](../START_HERE.md) to prepare PostgreSQL, migrate, and start the API. In this folder run `npm ci` and `npm run dev`. Open the exact loopback address named in the backend's WEB_ORIGIN. Use fictional accounts.

Run `npm test` for client request and state helper tests. Run `npm run build` to verify the frontend compiles. To try the signed-in flow, use the local development server and complete the backend repository steps. This project keeps authentication state server-side and waits for the session check before mounting private pages.
