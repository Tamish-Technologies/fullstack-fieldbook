import { hashPassword, verifyPassword } from "../src/passwords.js";

const practice = "Fictional study session";
const first = await hashPassword(practice);
const second = await hashPassword(practice);
console.log({
  independentSalts: first !== second,
  bothVerify: await verifyPassword(first, practice) && await verifyPassword(second, practice),
  wrongCandidateRejected: !(await verifyPassword(first, "Different practice phrase")),
});
