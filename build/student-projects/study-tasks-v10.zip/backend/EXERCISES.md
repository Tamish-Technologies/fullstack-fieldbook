# Week 10 guided exercises

## 1. User accounts

In `src/auth-repository.js`, implement the three methods with parameterized queries. `getByEmail` looks up normalized email and returns the internal record needed for verification. `getById` and `create` return only the id and email columns. Return null for a missing lookup. Let database uniqueness report a duplicate to the route.

In the local browser, register with a fictional email and unique practice phrase, then sign out and sign back in. Check 201 for creation, 409 for a duplicate, 200 for /me, and 401 for an invalid login. Record statuses and public response field names only.

## 2. Task ownership

In `src/task-repository.js`, all operations use `user_tasks`. The first value is the server-verified owner. For an ID operation bind the owner and the task ID together in the SELECT, UPDATE, or DELETE statement. Insert the owner with the title. Use a separate parameter for an optional completion filter, and order listed tasks by ascending ID. Use the supplied mapper for rows returned to the route.

For patching, bind `[ownerId, id, patch.title ?? null, patch.completed ?? null]` in that order. Use COALESCE in SQL so an omitted value keeps the current column while explicit false is preserved. Return the updated row or null. Return whether DELETE affected a row.

Run `npm test` to see the repository contract. In local practice, verify that each account sees its own list and that the original row is unchanged after another account is denied.

## 3. Session and local acceptance

Use different profiles for the two accounts. Observe login, /me, refresh, and sign-out. Check cookie attributes using browser tools and record only attribute names and statuses. The next /me after sign-out should be 401. Run `npm run test:db` after both repositories are complete. The suite verifies the access outcomes through real Express, PostgreSQL, and the session store, and cleans up its temporary schema.

Review any generated diff for verified identity, scoped SQL, public user response fields, and the negative assertions. Record a failing-then-passing test from your local work. Keep credentials and session values private.
