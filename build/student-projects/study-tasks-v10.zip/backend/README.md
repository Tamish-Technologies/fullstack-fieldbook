# Week 10 local backend

Use [the project setup](../START_HERE.md) to install, prepare separate PostgreSQL databases, and run the development service. [EXERCISES.md](EXERCISES.md) details the repository implementation sequence.

| Command | Expected use |
| --- | --- |
| `npm ci` | Install from the lockfile |
| `npm run demo:hash` | Compare synthetic Argon2id verification outcomes |
| `npm run migrate -- --legacy-only` | Prepare the old tasks table in the isolated development database |
| `npm run migrate` | Add users, private tasks and sessions while preserving legacy tasks |
| `npm run dev` | Run the loopback API and see its health address |
| `npm test` | Check validation, origin policy, the HTTP harness and the owner query contract |
| `npm run test:db` | Verify real sessions and two-account isolation in a separate test schema |

A successful health request confirms the database is reachable. If signup reports that the starter repository still needs work, complete the user methods first. A 403 on a normal browser form usually means the exact Vite address and WEB_ORIGIN differ. The starter is configured for loopback study use.
