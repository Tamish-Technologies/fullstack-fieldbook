-- Inspect the isolated Week 10 development database after migration.
SELECT current_database(), current_user;
SELECT to_regclass('public.tasks') AS legacy_tasks,
       to_regclass('public.users') AS users,
       to_regclass('public.user_tasks') AS user_tasks,
       to_regclass('public.user_sessions') AS user_sessions;
SELECT id, title, completed FROM tasks ORDER BY id;
SELECT count(*) AS private_tasks FROM user_tasks;
-- Check ownership after creating fictional tasks. Never select session values or password hashes.
SELECT id, owner_id, title, completed FROM user_tasks ORDER BY id;
