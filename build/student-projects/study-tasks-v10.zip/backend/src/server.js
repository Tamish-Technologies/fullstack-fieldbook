import { once } from "node:events";
import { createApp } from "./app.js";
import { createDbPool } from "./db.js";
import { createTaskRepository } from "./task-repository.js";
import { createUserRepository } from "./auth-repository.js";
import { createSessionMiddleware } from "./session.js";

const port = Number(process.env.PORT ?? 3001);
const expectedOrigin = process.env.WEB_ORIGIN ?? "";
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("PORT must be an integer between 1 and 65535.");
  process.exit(1);
}
if (process.env.NODE_ENV === "production" || !/^http:\/\/127\.0\.0\.1:[1-9]\d{0,4}$/.test(expectedOrigin)) {
  console.error("This starter runs on loopback only. Set WEB_ORIGIN to the exact local Vite URL.");
  process.exit(1);
}
if (!process.env.DATABASE_URL) {
  console.error("Set DATABASE_URL in the private backend/.env.");
  process.exit(1);
}

const pool = createDbPool();
try {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.includes("REPLACE_WITH") || Buffer.byteLength(secret) < 32) {
    console.error("Set a unique SESSION_SECRET using the command in .env.example.");
    process.exitCode = 1;
  } else {
    await pool.query("SELECT 1 FROM user_sessions LIMIT 0");
    const app = createApp({
      repository: createTaskRepository(pool),
      users: createUserRepository(pool),
      sessionMiddleware: createSessionMiddleware(pool, { secret }),
      expectedOrigin,
    });
    const server = app.listen(port, "127.0.0.1");
    await once(server, "listening");
    console.log(`Week 10 API: http://127.0.0.1:${port}/api/health`);
    function shutdown() {
      server.close(async () => {
        await pool.end();
        process.exit(0);
      });
    }
    process.once("SIGINT", shutdown);
    process.once("SIGTERM", shutdown);
  }
} catch (error) {
  const message = error?.code === "EADDRINUSE"
    ? `API port ${port} is already in use. Stop the other local API or follow the port instructions.`
    : error?.code === "42P01"
      ? "The session table is missing. Run npm run migrate in the backend first."
      : "Could not start the API. Check PostgreSQL and the private backend/.env.";
  console.error(message);
  process.exitCode = 1;
}
if (process.exitCode === 1) await pool.end();
