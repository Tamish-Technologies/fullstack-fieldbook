/** WEEK 10 EXERCISE: implement owner-scoped SQL for EVERY operation. */
export function toApiTask(row) {
  if (!row) return null;
  return { id:row.id, title:row.title, completed:row.completed,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString():
      new Date(row.created_at).toISOString() };
}
export function createTaskRepository(pool) {
  return {
    async ping() { await pool.query("SELECT 1"); return true; },
    async list(ownerId, { completed = null } = {}) {
      // TODO 4. SELECT ... FROM user_tasks WHERE owner_id = $1.
      // Optional completed filter uses an additional parameter $2.
      void ownerId;void completed; return []; // fail closed; no other user's data
    },
    async get(ownerId, id) {
      // TODO 5. SELECT ... WHERE owner_id = $1 AND id = $2.
      void ownerId;void id;return null;
    },
    async create(ownerId, { title }) {
      // TODO 6. INSERT INTO user_tasks (owner_id,title) VALUES ($1,$2).
      void ownerId;void title;
      throw Object.assign(new Error("Task insert is unfinished."), { code: "TASK_REPOSITORY_EXERCISE" });
    },
    async update(ownerId, id, patch) {
      // TODO 7. UPDATE ... WHERE owner_id = $1 AND id = $2 RETURNING ...
      void ownerId;void id;void patch;return null;
    },
    async remove(ownerId, id) {
      // TODO 8. DELETE ... WHERE owner_id = $1 AND id = $2.
      void ownerId;void id;return false;
    }
  };
}
