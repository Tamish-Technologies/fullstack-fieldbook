import session from "express-session";
import connectPgSimple from "connect-pg-simple";
const PgStore = connectPgSimple(session);
export const sessionCookieName = "study.w10.sid";
/** A persistent server-side session store; NEVER use MemoryStore in production. */
export function createSessionMiddleware(pool, { secret, schemaName } = {}) {
  if (!secret || secret.includes("REPLACE_WITH") || Buffer.byteLength(secret, "utf8") < 32) {
    throw new Error("SESSION_SECRET needs at least 32 random bytes; see .env.example.");
  }
  return session({
    name: sessionCookieName,
    secret,
    store: new PgStore({ pool, tableName: "user_sessions", createTableIfMissing: false, schemaName }),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 30 * 60 * 1000 }
  });
}
