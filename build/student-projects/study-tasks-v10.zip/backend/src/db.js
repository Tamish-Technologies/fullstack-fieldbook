import pg from "pg";
const { Pool } = pg;

export function createDbPool(connectionString = process.env.DATABASE_URL) {
  if (!connectionString) {
    throw new Error("DATABASE_URL is missing. Copy backend/.env.example to backend/.env and edit it.");
  }
  const pool = new Pool({
    connectionString,
    max: 5,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 10000,
  });
  pool.on("error", () => console.error("PostgreSQL lost an idle connection."));
  return pool;
}

export function isConnectionError(error) {
  return [
    "ECONNREFUSED", "ECONNRESET", "EPIPE", "ENOTFOUND", "ETIMEDOUT",
    "57P01", "57P02", "57P03", "53300",
  ].includes(error?.code) ||
    (typeof error?.code === "string" && error.code.startsWith("08")) ||
    /^(?:Connection terminated(?: unexpectedly| due to connection timeout)?|timeout exceeded when trying to connect)$/i.test(error?.message ?? "");
}
