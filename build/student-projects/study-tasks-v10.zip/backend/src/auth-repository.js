/** WEEK 10 EXERCISE: add parameterized PostgreSQL queries. */
export function createUserRepository(pool) {
  return {
    async getByEmail(email) {
      // TODO 1. SELECT id, email, password_hash FROM users WHERE email = $1
      // IMPORTANT: fail closed until implemented. Never invent a user object.
      void pool; void email;
      return null;
    },
    async getById(id) {
      // TODO 2. SELECT id, email FROM users WHERE id = $1
      void id;
      return null;
    },
    async create({ email, passwordHash }) {
      // TODO 3. INSERT INTO users (email,password_hash) VALUES ($1,$2)
      // RETURNING id,email. Database UNIQUE conflicts are handled in app.js.
      void email; void passwordHash;
      throw Object.assign(new Error("User insert is unfinished."), { code: "USER_REPOSITORY_EXERCISE" });
    }
  };
}
