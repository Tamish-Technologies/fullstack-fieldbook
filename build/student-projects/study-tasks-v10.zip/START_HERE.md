# Study Tasks v10

This is the separate, local Week 10 practice project. Use fictional accounts and titles. Keep the Week 9 project and its database available as a separate checkpoint.

## 1. Install and verify password hashing

Use Node 22.12+ or Node 24 and PostgreSQL 17. Follow [PostgreSQL's platform instructions](https://www.postgresql.org/download/) if you need a server. Extract both project folders together. Run `npm ci` in each folder. From `backend`, run `npm run demo:hash`. Expect three true results. The script prints only booleans. If a native binary is unavailable, see the [node-argon2 installation instructions](https://github.com/ranisalt/node-argon2#usage) for your platform, or use a supported Node 24 installation.

## 2. Prepare two separate databases

Reuse your Week 9 learning role if you have it. Otherwise, connect as your local database administrator, create the role with `CREATE ROLE study_tasks LOGIN;`, then use the psql prompt `\password study_tasks` to set its private local password. In pgAdmin, set the password through the role's Definition tab.

Run the following as separate statements outside a transaction. If the names already exist, inspect them and their owners before proceeding.

```sql
CREATE DATABASE study_tasks_week10 OWNER study_tasks;
CREATE DATABASE study_tasks_week10_test OWNER study_tasks;
```

Connect as the learning role and run `SELECT current_database(), current_user;` in both connections. Copy `backend/.env.example` to `backend/.env` and fill in both URLs. Percent-encode reserved characters in your database password in the URLs. Generate a random session secret using the example's command in a private terminal. Keep the secret and URLs inside the ignored environment file. Leave the test database separate.

## 3. Preserve a legacy row

In the **backend** terminal, run `npm run migrate -- --legacy-only` against the development database to prepare the Week 9 table. In the database client connected to that same isolated database, add a fictional row and record the returned ID.

```sql
INSERT INTO tasks (title) VALUES ('Legacy study plan') RETURNING id;
```

Run `npm run migrate` from the backend. Execute the read-only queries in `backend/sql/sql-lab.sql` to locate both task tables and the session schema. Verify the old ID is still present and the new private table starts empty. You can rerun the migrations and verify the same row again. Do not assign old shared rows to anyone.

## 4. Run the project in two terminals

- In `backend`, run `npm run dev`. Check the printed health URL. It should report postgres after the migration is in place.
- In `frontend`, run `npm run dev` and open exactly `http://127.0.0.1:5173`. The frontend proxies /api to the backend. The numeric hostname and port must match the backend's WEB_ORIGIN.
- If the API port is taken, change PORT in backend/.env and create a private frontend/.env.local with `STUDY_TASKS_API_PORT=` followed by the same port. If the web port is taken, use `npm run dev -- --port 5180` in the frontend and change WEB_ORIGIN to `http://127.0.0.1:5180`. Restart both processes after changing their settings.

## 5. Complete the two repositories

The UI, routes, and hashing utility are provided. User registration will show a starter message until you implement the user repository. The task methods intentionally start incomplete. Follow `backend/EXERCISES.md` for the validation, registration, and ownership steps in Lessons 5–8. Use the actual task ID returned by the API or database, since generated IDs can differ.

Run `npm test` in each folder. The untouched backend reports 20 passing tests and 3 expected owner-query failures. The frontend build and test suite can already run. After completion, run `npm run test:db` from the backend. It verifies the live database name before writing to a temporary schema inside the dedicated _test database. For manual checks, open Alice and Bob in different browser profiles. Record outcomes and statuses without copying any password, hash, connection URL, or session identifier.
