// TODO: Mount this page in /ideas after the request UI is ready.
// 1. Model source, retry attempts and the four request states.
// 2. Connect fetchIdeas in an Effect with abort and late-result protection.
// 3. Render Retry, offline examples and Copy. Follow Fieldbook Lessons 3–8.
export default function IdeasPage({ onAddIdea }) {
  return (
    <section aria-labelledby="ideas-heading">
      <h1 id="ideas-heading">Study Idea Inbox</h1>
      <p>This page is ready for your request UI. Start in Fieldbook Lesson 3.</p>
    </section>
  );
}
