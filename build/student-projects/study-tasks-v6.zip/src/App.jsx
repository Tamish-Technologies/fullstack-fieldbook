import { useEffect, useState } from "react";
import TaskForm from "./components/TaskForm.jsx";
import TaskToolbar from "./components/TaskToolbar.jsx";
import TaskList from "./components/TaskList.jsx";
import {
  addTaskToList, countRemaining, deleteTaskFromList,
  getVisibleTasks, renameTaskInList, toggleTaskInList
} from "./lib/task-logic.js";
import { readStoredTasks, STORAGE_KEY, writeStoredTasks } from "./lib/storage.js";

function getBrowserStorage() {
  try { return window.localStorage; } catch { return null; }
}

function initialTasks() {
  const storage = getBrowserStorage();
  return storage
    ? readStoredTasks(storage)
    : { ok: false, tasks: [], error: "Browser storage is unavailable." };
}

export default function App() {
  // Lazy initializer reads storage on mount, not on every re-render.
  const [initial] = useState(initialTasks);
  const [tasks, setTasks] = useState(initial.tasks);
  const [canPersist, setCanPersist] = useState(initial.ok);
  const [storageWarning, setStorageWarning] = useState(initial.error);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest");

  useEffect(() => {
    if (!canPersist) return; // malformed existing data is not overwritten automatically
    const storage = getBrowserStorage();
    const result = storage
      ? writeStoredTasks(storage, tasks, STORAGE_KEY)
      : { ok: false, error: "Browser storage is unavailable." };
    if (!result.ok) setStorageWarning(result.error);
  }, [tasks, canPersist]);

  function addTask(title) {
    setTasks((previous) => {
      const id = previous.reduce((max, task) => Math.max(max, task.id), 0) + 1;
      return addTaskToList(previous, id, title).tasks;
    });
  }

  function renameTask(id, title) {
    // Validation is independent of state; the updater only returns new state.
    const existing = tasks.find((task) => task.id === id);
    if (!existing) return { ok: false, error: "Task not found." };
    const result = renameTaskInList(tasks, id, title);
    if (result.ok) {
      setTasks((previous) => renameTaskInList(previous, id, title).tasks);
    }
    return result;
  }

  function resetUnreadableStorage() {
    if (!window.confirm("Replace unreadable saved task data with an empty list?")) return;
    setTasks([]);
    setCanPersist(true);
    setStorageWarning("");
  }

  // Derived view: don't store another copy of filtered tasks in state.
  const visibleTasks = getVisibleTasks(tasks, { filter, query, sort });
  const remaining = countRemaining(tasks);

  return (
    <main className="app">
      <header className="app-header">
        <p className="eyebrow">STUDY TASKS / V5 REACT EDITION</p>
        <h1>Build it. Understand it.</h1>
        <p>One task app, rebuilt using React components and state.</p>
      </header>

      <TaskForm onAdd={addTask} />

      <section className="tasks-section" aria-labelledby="tasks-heading">
        <div className="section-heading">
          <h2 id="tasks-heading">My study tasks</h2>
          <p className="count">{remaining} remaining</p>
        </div>
        <TaskToolbar
          filter={filter} onFilterChange={setFilter}
          query={query} onQueryChange={setQuery}
          sort={sort} onSortChange={setSort}
        />
        <p className="results-count" aria-live="polite">
          {visibleTasks.length} shown of {tasks.length}
        </p>
        <TaskList
          tasks={visibleTasks} total={tasks.length}
          onToggle={(id) => setTasks((previous) => toggleTaskInList(previous, id))}
          onDelete={(id) => setTasks((previous) => deleteTaskFromList(previous, id))}
          onRename={renameTask}
        />
      </section>

      {storageWarning && (
        <div className="storage-notice" role="alert">
          <p>{storageWarning}</p>
          {!canPersist && (
            <button type="button" className="quiet-button" onClick={resetUnreadableStorage}>
              Start a fresh list (replaces saved data)
            </button>
          )}
        </div>
      )}

      <aside className="next-week-note">
        <strong>Week 6 starting point</strong>
        <p>Reconnect the API-powered Study Idea Inbox, then learn more React hooks and routing.</p>
      </aside>
      <footer>React renders the UI from state. Git and tests verify the work.</footer>
    </main>
  );
}
