# Study Tasks v6 learner starter

Extract this ZIP into a new folder. Work from the directory containing this README and package.json. On Node 24, run:

```sh
npm ci
npm run dev
```

Open the address Vite prints. You should see the working Week 5 task list. Keep the terminal running while you work and open a second terminal here for `npm test` and `npm run build`. Some API helper tests deliberately fail until you implement the two functions. The initial build should succeed.

Start in Fieldbook Week 6 Lesson 1 for the API helpers. The lesson reader leads you through effects, recoverable request states, routing, shared task state and persistence. You can create a local Git baseline with `git init`, `git add .` and `git commit -m "Start Week 6"`. The included .gitignore excludes dependencies and build output.

Use only fictional tasks. Keep the storage key `study-tasks-week2`. Vite addresses with different ports hold different storage. Keep a separate Week 5 project copy and use an unused port to practice damaged storage.

## Practice without the live API

Import `practiceFetch` from `src/lib/practice-fetch.js` and pass it to your client as `fetchIdeas({ signal, fetchImpl: practiceFetch("success") })`. Try `success`, `empty`, `http` (503), `json` (invalid JSON), `network`, `slow`, and `late` (does not cancel after starting). These fixtures exercise request handling in your real React UI without traffic. To inspect real request status in DevTools, use the optional read-only sample endpoint or block that request using DevTools. Keep the required project demo repeatable with fixtures and bundled offline examples. Copy ideas into the local task list with new numeric IDs.
