// TEST ONLY. Fake in-memory session service must NEVER be used by the real server.
import { randomUUID } from "node:crypto";
export function createSessionHarness() {
  const sessions = new Map();
  const middleware = (req, res, next) => {
    const cookie = (req.headers.cookie || "").match(/study\.sid=([\w-]+)/);
    let sid = cookie?.[1];
    const snapshot = sid ? sessions.get(sid) : undefined;
    req.session = {
      ...(snapshot || {}),
      regenerate(cb) { sid=randomUUID(); delete this.userId; cb(); },
      save(cb) { sessions.set(sid,{userId:this.userId});res.setHeader("Set-Cookie",`study.sid=${sid}; Path=/; HttpOnly`);cb(); },
      destroy(cb) { if(sid)sessions.delete(sid);cb(); }
    };
    next();
  };
  return { middleware };
}
export function createTestRepositories() {
  let id=0,uid=0;
  const users=new Map();const tasks=[];
  const userRepo={
    async create({email,passwordHash}) {
      if(users.has(email)) {const e=new Error("duplicate");e.code="23505";throw e;}
      const user={id:`user-${++uid}`,email,password_hash:passwordHash};users.set(email,user);
      return {id:user.id,email};
    },
    async getByEmail(email) {return users.get(email)||null;},
    async getById(requestedId) {const user=[...users.values()].find(u=>u.id===requestedId);return user ? {id:user.id,email:user.email}:null;}
  };
  const row=(t)=> t ? ({id:t.id,title:t.title,completed:t.completed,createdAt:t.createdAt}) : null;
  const find=(ownerId,requestedId)=>tasks.find(t=>t.ownerId===ownerId && t.id===requestedId);
  const taskRepo={
    async ping(){return true;},
    async list(ownerId,{completed=null}={}){return tasks.filter(t=>t.ownerId===ownerId && (completed===null||t.completed===completed)).map(row);},
    async get(ownerId,requestedId){return row(find(ownerId,requestedId))||null;},
    async create(ownerId,{title}){const t={id:++id,title,completed:false,ownerId,createdAt:new Date().toISOString()};tasks.push(t);return row(t);},
    async update(ownerId,requestedId,patch){const t=find(ownerId,requestedId);if(!t)return null;Object.assign(t,patch);return row(t);},
    async remove(ownerId,requestedId){const index=tasks.findIndex(t=>t.ownerId===ownerId && t.id===requestedId);if(index<0)return false;tasks.splice(index,1);return true;}
  };
  return {userRepo,taskRepo};
}
