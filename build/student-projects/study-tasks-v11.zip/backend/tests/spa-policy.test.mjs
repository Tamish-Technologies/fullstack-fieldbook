import test from "node:test";
import assert from "node:assert/strict";
import { wantsHtmlNavigation } from "../src/spa-policy.js";
const req=(path,method="GET",accept="text/html")=>({path,method,get:()=>accept});
test("React page navigation receives index.html only for HTML GET",()=>{
 assert.equal(wantsHtmlNavigation(req("/tasks")),true);
 assert.equal(wantsHtmlNavigation(req("/ideas")),true);
 assert.equal(wantsHtmlNavigation(req("/tasks","POST")),false);
 assert.equal(wantsHtmlNavigation(req("/tasks","GET","application/json")),false);
});
test("never treat unknown API routes as React page navigation",()=>{
 assert.equal(wantsHtmlNavigation(req("/api/missing")),false);
 assert.equal(wantsHtmlNavigation(req("/api")),false);
});
