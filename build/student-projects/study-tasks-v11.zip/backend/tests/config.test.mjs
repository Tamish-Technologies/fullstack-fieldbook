import test from "node:test";
import assert from "node:assert/strict";
import { loadConfig } from "../src/config.js";
const valid = { NODE_ENV: "development", WEB_ORIGIN: "http://127.0.0.1:5173",
 DATABASE_URL: "postgresql://dev:example@127.0.0.1:5432/study_tasks_week11",
 SESSION_SECRET: "a".repeat(48), PORT: "3001", TRUST_PROXY_HOPS: "0" };
test("accepts a correctly configured local environment", () => {
 const c=loadConfig(valid);assert.equal(c.isProduction,false);assert.equal(c.port,3001);assert.equal(c.trustProxyHops,0);
});
test("rejects invalid ports, URLs and placeholder session secrets", () => {
 for(const change of [{PORT:"not-a-port"},{PORT:"0"},{WEB_ORIGIN:"http://127.0.0.1:5173/path"},
   {DATABASE_URL:"not-a-url"},{SESSION_SECRET:"REPLACE_WITH_EXAMPLE"},{TRUST_PROXY_HOPS:"99"}]) {
   assert.throws(()=>loadConfig({...valid,...change}));
 }
});
test("production requires https origin and verified proxy hops", () => {
 assert.throws(()=>loadConfig({...valid,NODE_ENV:"production"}),/HTTPS/);
 assert.throws(()=>loadConfig({...valid,NODE_ENV:"production",WEB_ORIGIN:"https://example.test"}),/TRUST_PROXY/);
 const c=loadConfig({...valid,NODE_ENV:"production", WEB_ORIGIN:"https://preview.example.test", TRUST_PROXY_HOPS:"1"});
 assert.equal(c.isProduction,true);assert.equal(c.webOrigin,"https://preview.example.test");
});
test("invalid config errors do not include connection strings",()=>{
 const testUrl="postgresql://secret:never-log-this@127.0.0.1/test";
 try {loadConfig({...valid,DATABASE_URL:testUrl,WEB_ORIGIN:"not-an-origin"});assert.fail("must throw");}
 catch(error){assert.doesNotMatch(error.message,/never-log-this/);}
});
