import test from "node:test";
import assert from "node:assert/strict";
import {
  parseCompletedFilter, parseTaskId, validateCreateBody, validatePatchBody
} from "../src/validation.js";

test("create body accepts and trims a valid title", () => {
  assert.deepEqual(validateCreateBody({ title: "  Learn APIs  " }),
    { ok: true, value: { title: "Learn APIs" } });
});
test("create body rejects non-objects, arrays and missing titles", () => {
  for (const body of [undefined, null, [], "abc", {}]) assert.equal(validateCreateBody(body).ok, false);
});
test("create body rejects whitespace and long titles", () => {
  assert.equal(validateCreateBody({ title: " \t " }).ok, false);
  assert.equal(validateCreateBody({ title: "x".repeat(81) }).ok, false);
  assert.equal(validateCreateBody({ title: "x".repeat(80) }).ok, true);
});
test("create body blocks unexpected fields", () => {
  assert.equal(validateCreateBody({ title: "OK", isAdmin: true }).ok, false);
});
test("patch accepts valid completion and title together", () => {
  assert.deepEqual(validatePatchBody({ title: "  A  ", completed: true }),
    { ok: true, value: { title: "A", completed: true } });
});
test("patch accepts false without treating it as absent", () => {
  assert.deepEqual(validatePatchBody({ completed: false }),
    { ok: true, value: { completed: false } });
});
test("patch rejects empty, unexpected, invalid values", () => {
  for (const body of [null, {}, [], { completed: "true" }, { title: " " }, { id: 3 }]) {
    assert.equal(validatePatchBody(body).ok, false);
  }
});
test("task IDs are positive safe integers", () => {
  for (const id of ["1", "19", "2147483647"]) assert.equal(typeof parseTaskId(id), "number");
  for (const id of ["0", "-1", "abc", "1.5", "01", "2147483648", "9007199254740992"]) assert.equal(parseTaskId(id), null);
});
test("completed query filter validates exact string values", () => {
  assert.deepEqual(parseCompletedFilter(undefined), { ok: true, value: null });
  assert.deepEqual(parseCompletedFilter("true"), { ok: true, value: true });
  assert.deepEqual(parseCompletedFilter("false"), { ok: true, value: false });
  assert.equal(parseCompletedFilter("TRUE").ok, false);
});
