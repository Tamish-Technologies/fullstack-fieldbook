import test from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { createRequestLog } from "../src/request-log.js";
test("every request gets a correlation ID without leaking credentials",()=>{
 const logged=[];const req={method:"POST",path:"/api/auth/login?token=secret",headers:{cookie:"study.sid=secret"}};
 const res=new EventEmitter();res.statusCode=401;res.headers={};res.setHeader=(k,v)=>res.headers[k]=v;
 let nextCalled=false;
 createRequestLog({logger:x=>logged.push(x),makeId:()=>"test-req-123",clock:(()=>{let i=0;return ()=>++i;})()})(req,res,()=>nextCalled=true);
 assert.equal(nextCalled,true);assert.equal(res.headers["X-Request-ID"],"test-req-123");
 res.emit("finish");assert.equal(logged.length,1);
 assert.equal(JSON.parse(logged[0]).route,"unmatched");
 assert.doesNotMatch(logged[0],/secret|token|study.sid|cookie/);
});
