import test from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";
import { createApp } from "../src/app.js";
import { createSessionHarness, createTestRepositories } from "./helpers/fake-auth-state.mjs";
const ORIGIN="http://127.0.0.1:5173";
async function withApi(run) {
  const {userRepo,taskRepo}=createTestRepositories();
  const app=createApp({users:userRepo,repository:taskRepo,sessionMiddleware:createSessionHarness().middleware,
    expectedOrigin:ORIGIN,enableLogging:false,enableRateLimit:false,
    passwordHasher:async(password)=>`hashed:${password}`,
    passwordVerifier:async(hash,password)=>hash===`hashed:${password}`});
  const server=app.listen(0,"127.0.0.1");await once(server,"listening");
  try {await run(`http://127.0.0.1:${server.address().port}`);}
  finally {await new Promise((resolve,reject)=>server.close(e=>e?reject(e):resolve()));}
}
function createClient(base){
  let cookie="";
  return {async send(path,{method="GET",body,origin=ORIGIN}={}){
    const options={method,headers:{}};
    if(method!=="GET") options.headers.Origin=origin;
    if(body!==undefined){options.headers["Content-Type"]="application/json";options.body=JSON.stringify(body);}
    if(cookie) options.headers.Cookie=cookie;
    const response=await fetch(base+path,options);
    if(response.headers.get("set-cookie"))cookie=response.headers.get("set-cookie").split(";")[0];
    const raw=await response.text();return {status:response.status,body:raw?JSON.parse(raw):null,headers:response.headers};
  }};
}
test("unauthenticated users cannot list or create tasks",()=>withApi(async base=>{
  const client=createClient(base);
  assert.equal((await client.send("/api/tasks")).status,401);
  assert.equal((await client.send("/api/tasks",{method:"POST",body:{title:"X"}})).status,401);
}));
test("register, login, me, logout lifecycle; never reveal hashes",()=>withApi(async base=>{
  const c=createClient(base);
  const account={email:"  ALICE@EXAMPLE.TEST  ",password:"unique-strong-passphrase"};
  const created=await c.send("/api/auth/register",{method:"POST",body:account});
  assert.equal(created.status,201);assert.equal(created.body.user.email,"alice@example.test");
  assert.equal(JSON.stringify(created.body).includes("hashed:"),false);
  assert.equal((await c.send("/api/auth/me")).status,200);
  assert.equal((await c.send("/api/auth/logout",{method:"POST",body:{}})).status,204);
  assert.equal((await c.send("/api/auth/me")).status,401);
  assert.equal((await c.send("/api/auth/login",{method:"POST",body:{email:"alice@example.test",password:"wrong-password"}})).status,401);
  assert.equal((await c.send("/api/auth/login",{method:"POST",body:{email:"alice@example.test",password:account.password}})).status,200);
  assert.equal((await c.send("/api/auth/me")).status,200);
}));
test("two users cannot list, edit, get, or delete each other's tasks",()=>withApi(async base=>{
  const a=createClient(base),b=createClient(base);
  const register=async(c,email)=>c.send("/api/auth/register",{method:"POST",body:{email,password:"another-long-practice-pass"}});
  assert.equal((await register(a,"a@example.test")).status,201);
  assert.equal((await register(b,"b@example.test")).status,201);
  const made=await a.send("/api/tasks",{method:"POST",body:{title:"Private Alice"}});
  assert.equal(made.status,201);const id=made.body.data.id;
  assert.equal((await b.send("/api/tasks")).body.count,0);
  assert.equal((await b.send(`/api/tasks/${id}`)).status,404);
  assert.equal((await b.send(`/api/tasks/${id}`,{method:"PATCH",body:{completed:true}})).status,404);
  assert.equal((await b.send(`/api/tasks/${id}`,{method:"DELETE"})).status,404);
  assert.equal((await a.send(`/api/tasks/${id}`)).body.data.completed,false);
  assert.equal((await a.send("/api/tasks")).body.count,1);
  assert.equal((await a.send(`/api/tasks/${id}`,{method:"DELETE"})).status,204);
}));
test("cross-origin mutation rejected regardless of cookie",()=>withApi(async base=>{
  const a=createClient(base);
  const res=await a.send("/api/auth/register",{method:"POST",origin:"https://evil.test",body:{email:"x@example.test",password:"password-long-enough"}});
  assert.equal(res.status,403);assert.equal(res.body.error.code,"UNTRUSTED_ORIGIN");
}));
