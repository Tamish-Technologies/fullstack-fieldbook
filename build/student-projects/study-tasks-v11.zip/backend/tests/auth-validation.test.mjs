import test from "node:test";
import assert from "node:assert/strict";
import { normalizeEmail, validateCredentials, publicUser } from "../src/auth-validation.js";
test("registration normalizes valid email and accepts passphrase", () => {
  const result = validateCredentials({ email:"  Student@Example.Test  ", password:"twelve-chars-or-more" }, { registering: true });
  assert.equal(result.ok,true); assert.equal(result.value.email,"student@example.test");
});
test("rejects malformed emails, short registration passwords, and extra keys", () => {
  for (const body of [null, {}, {email:"not-email",password:"aaaaaaaaaaaa"},
    {email:"a@example.test",password:"short"},
    {email:"a@example.test",password:"longsecure123",role:"admin"}]) {
    assert.equal(validateCredentials(body,{ registering:true }).ok,false);
  }
});
test("publicUser never discloses a password hash", () => {
  assert.deepEqual(publicUser({ id:"u1", email:"a@example.test", password_hash:"secret" }), { id:"u1", email:"a@example.test" });
  assert.equal(normalizeEmail(7),"");
});
