import test from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";
import { mkdtemp, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "../src/app.js";
import { createSessionHarness, createTestRepositories } from "./helpers/fake-auth-state.mjs";
async function withPreview(run,{brokenDatabase=false, staticDir=null}={}){
 const {userRepo,taskRepo}=createTestRepositories();
 if(brokenDatabase){taskRepo.ping=async()=>{const err=new Error("database-url password=private");err.code="ECONNREFUSED";throw err;};}
 const app=createApp({repository:taskRepo,users:userRepo,sessionMiddleware:createSessionHarness().middleware,
  expectedOrigin:"http://127.0.0.1:5173",enableRateLimit:false,enableLogging:false,staticDir});
 const server=app.listen(0,"127.0.0.1");await once(server,"listening");
 try {await run(`http://127.0.0.1:${server.address().port}`);} finally {await new Promise(r=>server.close(r));}
}
test("API liveness is distinct from database readiness; no-cache API",()=>withPreview(async base=>{
 const live=await fetch(base+"/api/live"); assert.equal(live.status,200);
 assert.equal(live.headers.get("cache-control"),"no-store");
 assert.ok(live.headers.get("x-request-id"));
 const ready=await fetch(base+"/api/health"); assert.equal(ready.status,200);
 assert.equal(ready.headers.get("x-content-type-options"),"nosniff");
}));
test("database outage returns 503 without leaking connection details",()=>withPreview(async base=>{
 assert.equal((await fetch(base+"/api/live")).status,200);
 const response=await fetch(base+"/api/health");assert.equal(response.status,503);
 const text=await response.text();assert.match(text,/DB_UNAVAILABLE/);
 assert.doesNotMatch(text,/password|private|database-url/);
},{brokenDatabase:true}));
test("unknown API paths stay JSON 404 while SPA serves valid navigation",async()=>{
 const staticDir=await mkdtemp(join(tmpdir(),"week11-build-"));
 try {
  await writeFile(join(staticDir,"index.html"),"<!doctype html><title>Week 11 SPA</title>");
  await withPreview(async base=>{
   const missing=await fetch(base+"/api/missing",{headers:{Accept:"text/html"}});
   assert.equal(missing.status,404);assert.match(missing.headers.get("content-type"),/json/);
   const page=await fetch(base+"/tasks",{headers:{Accept:"text/html"}});
   assert.equal(page.status,200);assert.match(await page.text(),/Week 11 SPA/);
  },{staticDir});
 } finally {await rm(staticDir,{recursive:true,force:true});}
});

test("HTTP failures stay JSON and exclude request and driver details", () => withPreview(async (base) => {
  const headers = { Origin: "http://127.0.0.1:5173", "Content-Type": "application/json" };
  for (const [payload, status, code] of [
    ['{"password":"private-demo"', 400, "INVALID_JSON"],
    [JSON.stringify({ padding: "a".repeat(17_000) }), 413, "PAYLOAD_TOO_LARGE"],
  ]) {
    const response = await fetch(base + "/api/auth/login", { method: "POST", headers, body: payload });
    assert.equal(response.status, status);
    assert.match(response.headers.get("content-type"), /application\/json/);
    const body = await response.text();
    assert.match(body, new RegExp(code));
    assert.doesNotMatch(body, /private-demo|SyntaxError|stack/);
  }
}));

test("liveness bypasses session storage when it is unavailable", async () => {
  const { userRepo, taskRepo } = createTestRepositories();
  const app = createApp({
    repository: taskRepo, users: userRepo, expectedOrigin: "http://127.0.0.1:5173",
    enableRateLimit: false, enableLogging: false,
    sessionMiddleware(_req, _res, next) { next(new Error("session store offline")); },
  });
  const server = app.listen(0, "127.0.0.1");
  await once(server, "listening");
  try {
    const base = "http://127.0.0.1:" + server.address().port;
    assert.equal((await fetch(base + "/api/live")).status, 200);
    assert.equal((await fetch(base + "/api/health")).status, 200);
    const protectedRead = await fetch(base + "/api/tasks");
    assert.equal(protectedRead.status, 500);
    assert.doesNotMatch(await protectedRead.text(), /session store offline/);
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
