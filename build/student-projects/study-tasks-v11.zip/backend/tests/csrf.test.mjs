import test from "node:test";
import assert from "node:assert/strict";
import { isTrustedRequest } from "../src/csrf.js";
const allowed="http://127.0.0.1:5173";
test("same-origin POST allowed; alternate origin rejected",() => {
  assert.equal(isTrustedRequest({method:"POST",origin:allowed},allowed),true);
  assert.equal(isTrustedRequest({method:"POST",origin:"https://evil.test"},allowed),false);
  assert.equal(isTrustedRequest({method:"PATCH",origin:"null"},allowed),false);
});
test("unsafe requests reject if origin and referer absent",() => {
  assert.equal(isTrustedRequest({method:"POST"},allowed),false);
  assert.equal(isTrustedRequest({method:"DELETE",referer:"https://evil.test/x"},allowed),false);
  assert.equal(isTrustedRequest({method:"POST",referer:allowed+"/tasks"},allowed),true);
});
test("GET is safe; only exact origin matches",() => {
  assert.equal(isTrustedRequest({method:"GET"},allowed),true);
  assert.equal(isTrustedRequest({method:"POST",origin:allowed+".evil.test"},allowed),false);
});
