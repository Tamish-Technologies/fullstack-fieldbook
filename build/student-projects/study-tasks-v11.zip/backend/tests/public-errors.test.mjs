import test from "node:test";
import assert from "node:assert/strict";
import { classifyPublicError, logPublicError } from "../src/public-errors.js";
test("JSON failures have safe client codes",()=>{
 assert.deepEqual(classifyPublicError({type:"entity.parse.failed"}),
  {status:400,code:"INVALID_JSON",message:"Request body must be valid JSON."});
 assert.equal(classifyPublicError({type:"entity.too.large"}).status,413);
});
test("database down returns safe 503, other bugs a safe 500",()=>{
 assert.equal(classifyPublicError({code:"ECONNREFUSED"}).status,503);
 assert.equal(classifyPublicError({code:"08006"}).code,"DB_UNAVAILABLE");
 assert.equal(classifyPublicError(new Error("password=secret debug SQL SELECT ...")).code,"INTERNAL_ERROR");
});
test("structured errors do not log exception messages or secrets",()=>{
 const logs=[];
 logPublicError({error: new Error("private password=secret"),requestId:"req-1",status:500},s=>logs.push(s));
 assert.equal(logs.length,1);assert.match(logs[0],/req-1/);assert.doesNotMatch(logs[0],/private|secret|password/);
});
