-- Run against your LOCAL development database only, never production.
-- Nothing in this lab persists, because ROLLBACK undoes all writes.
BEGIN;
INSERT INTO tasks (title) VALUES ('SQL practice: read a chapter') RETURNING *;
INSERT INTO tasks (title) VALUES ('SQL practice: solve exercises') RETURNING *;
SELECT id, title, completed, created_at FROM tasks ORDER BY id;
SELECT id, title FROM tasks WHERE completed = FALSE ORDER BY id;
UPDATE tasks SET completed = TRUE WHERE title = 'SQL practice: read a chapter';
SELECT id, title, completed FROM tasks WHERE title LIKE 'SQL practice:%';
DELETE FROM tasks WHERE title = 'SQL practice: solve exercises' RETURNING id;
ROLLBACK;
-- Verify: the lab records were NOT saved to the database.
SELECT id, title FROM tasks WHERE title LIKE 'SQL practice:%';
