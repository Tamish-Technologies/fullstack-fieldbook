const port = process.env.PORT ?? "3001";
process.env.NODE_ENV = "development";
process.env.TRUST_PROXY_HOPS = "0";
process.env.SERVE_BUILT_FRONTEND = "1";
process.env.WEB_ORIGIN = `http://127.0.0.1:${port}`;
await import("../src/server.js");
