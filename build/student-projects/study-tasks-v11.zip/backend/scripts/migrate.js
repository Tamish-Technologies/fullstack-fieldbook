import { readFile } from "node:fs/promises";
import { createDbPool } from "../src/db.js";

const pool = createDbPool();
let step = "connect to the local database";
try {
  const { rows: [{ database }] } = await pool.query("SELECT current_database() AS database");
  if (database.endsWith("_test")) throw new Error("test target");
  const filenames = ["001_create_tasks.sql"];
  if (!process.argv.includes("--legacy-only")) filenames.push("002_create_users_sessions_and_user_tasks.sql");
  console.log("Development database:", JSON.stringify(database));
  for (const filename of filenames) {
    step = filename;
    const sql = await readFile(new URL(`../migrations/${filename}`, import.meta.url), "utf8");
    await pool.query(sql);
    console.log(`Migration applied: ${filename}`);
  }
} catch {
  console.error(`Could not ${step === "connect to the local database" ? step : "apply " + step}. Check the configured development target and permissions.`);
  process.exitCode = 1;
} finally {
  await pool.end();
}
