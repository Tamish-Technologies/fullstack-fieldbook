-- Week 10: separate owner-bound table. Keep Week 9's public "tasks" table
-- untouched to avoid silently assigning shared legacy rows to an arbitrary user.
-- Existing Week 9 tasks will not appear in Week 10 until explicitly migrated
-- with a verified owner. This script is idempotent for the teaching environment.
-- PostgreSQL 17 provides gen_random_uuid() without an extension.
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT users_email_is_normalized CHECK (email = lower(btrim(email)))
);

CREATE TABLE IF NOT EXISTS user_tasks (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(80) NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT user_tasks_title_not_blank CHECK (char_length(btrim(title)) BETWEEN 1 AND 80)
);
CREATE INDEX IF NOT EXISTS user_tasks_owner_id_idx ON user_tasks(owner_id, id);

-- Session table format used by connect-pg-simple 10.x; managed by a migration.
CREATE TABLE IF NOT EXISTS user_sessions (
  sid VARCHAR NOT NULL COLLATE "default" PRIMARY KEY,
  sess JSON NOT NULL,
  expire TIMESTAMP(6) NOT NULL
);
CREATE INDEX IF NOT EXISTS user_sessions_expire_idx ON user_sessions(expire);
