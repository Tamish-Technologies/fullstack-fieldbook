-- Week 9. One idempotent teaching migration; production applications need
-- tracked, versioned migrations once the schema evolves.
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title VARCHAR(80) NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT tasks_title_not_blank CHECK (char_length(btrim(title)) BETWEEN 1 AND 80)
);
