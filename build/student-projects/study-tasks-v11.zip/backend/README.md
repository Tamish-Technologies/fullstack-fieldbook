# Study Tasks v11 backend

Use [START_HERE.md](../START_HERE.md) for the lockfile installs, private environment, migration, and two ways to launch. [STUDENT_EXERCISES.md](../STUDENT_EXERCISES.md) explains the four intentional defects.

- `npm run test:unit` runs pure Node tests.
- `npm test` also runs real Express with controlled dependencies.
- `npm run test:db` uses actual PostgreSQL in a fresh schema after verifying the separate database name.
- `npm run preview:local` serves built files and API from the same loopback HTTP origin.

Health and liveness are intentionally different. Only the health endpoint checks PostgreSQL. Keep captured log entries limited to the generated ID, method, route label, status and timing.
