/** Every user task query is scoped to a SERVER-VERIFIED ownerId. */
export function toApiTask(row) {
  if (!row) return null;
  return {
    id: row.id, title: row.title, completed: row.completed,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() :
      new Date(row.created_at).toISOString()
  };
}
const FIELDS = "id, title, completed, created_at";
export function createTaskRepository(pool) {
  return {
    async ping() { await pool.query("SELECT 1"); return true; },
    async list(ownerId, { completed = null } = {}) {
      const result = completed === null
        ? await pool.query(`SELECT ${FIELDS} FROM user_tasks WHERE owner_id = $1 ORDER BY id`, [ownerId])
        : await pool.query(`SELECT ${FIELDS} FROM user_tasks WHERE owner_id = $1 AND completed = $2 ORDER BY id`, [ownerId, completed]);
      return result.rows.map(toApiTask);
    },
    async get(ownerId, id) {
      const { rows } = await pool.query(`SELECT ${FIELDS} FROM user_tasks WHERE owner_id = $1 AND id = $2`, [ownerId, id]);
      return toApiTask(rows[0]);
    },
    async create(ownerId, { title }) {
      const { rows } = await pool.query(
        `INSERT INTO user_tasks (owner_id, title) VALUES ($1, $2) RETURNING ${FIELDS}`, [ownerId, title]);
      return toApiTask(rows[0]);
    },
    async update(ownerId, id, patch) {
      const { rows } = await pool.query(
        `UPDATE user_tasks SET title = COALESCE($3, title), completed = COALESCE($4, completed)
         WHERE owner_id = $1 AND id = $2 RETURNING ${FIELDS}`,
        [ownerId, id, patch.title ?? null, patch.completed ?? null]);
      return toApiTask(rows[0]);
    },
    async remove(ownerId, id) {
      const { rowCount } = await pool.query(
        "DELETE FROM user_tasks WHERE owner_id = $1 AND id = $2", [ownerId, id]);
      return rowCount > 0;
    }
  };
}
