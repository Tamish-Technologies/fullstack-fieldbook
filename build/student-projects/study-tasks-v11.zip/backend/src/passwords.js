import argon2 from "argon2";
// Argon2id is a dedicated, slow password-hashing algorithm; never use SHA-256.
export async function hashPassword(password) {
  return argon2.hash(password, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
}
export async function verifyPassword(hash, password) {
  return argon2.verify(hash, password);
}
