import pg from "pg";
const { Pool } = pg;

/** Use one bounded pool per running backend process. Never log credentials. */
export function createDbPool(connectionString = process.env.DATABASE_URL) {
  if (!connectionString) {
    throw new Error("DATABASE_URL is missing. Copy backend/.env.example to backend/.env and edit it.");
  }
  const pool = new Pool({
    connectionString,
    max: 5,
    connectionTimeoutMillis: 5000,
    idleTimeoutMillis: 10000
  });
  pool.on("error", () => {
    console.error(JSON.stringify({ event: "postgres_idle_error" }));
  });
  return pool;
}
