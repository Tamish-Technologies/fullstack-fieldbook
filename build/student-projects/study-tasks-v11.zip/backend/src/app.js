import express from "express";
import { sessionCookieName } from "./session.js";
import helmet from "helmet";
import { createRequestLog } from "./request-log.js";
import { classifyPublicError, logPublicError } from "./public-errors.js";
import { mountReactBuild } from "./static-web.js";
import { rateLimit } from "express-rate-limit";
import { parseCompletedFilter, parseTaskId, validateCreateBody, validatePatchBody } from "./validation.js";
import { validateCredentials, publicUser } from "./auth-validation.js";
import { hashPassword, verifyPassword } from "./passwords.js";
import { requireTrustedOrigin } from "./csrf.js";
const errorBody = (code, message) => ({ error: { code, message } });

function newSession(req, user) {
  // Regenerating the ID on login/register reduces session fixation risk.
  return new Promise((resolve, reject) => req.session.regenerate((error) => {
    if (error) return reject(error);
    req.session.userId = user.id;
    req.session.save((saveError) => saveError ? reject(saveError) : resolve());
  }));
}
function requireAuth(req, res, next) {
  if (!req.session?.userId) return res.status(401).json(errorBody("AUTH_REQUIRED", "Sign in to continue."));
  next();
}
export function createApp({ repository, users, sessionMiddleware, expectedOrigin,
  enableLogging = true, enableRateLimit = true, passwordHasher = hashPassword,
  passwordVerifier = verifyPassword, isProduction = false, staticDir = null, logger = console.info } = {}) {
  if (!repository || !users || !sessionMiddleware || !expectedOrigin) {
    throw new Error("createApp requires tasks, users, session middleware and WEB_ORIGIN.");
  }
  const app = express();
  app.disable("x-powered-by");
  app.use(createRequestLog({ logger: enableLogging ? logger : null }));
  app.use(helmet({
    contentSecurityPolicy: isProduction
      ? undefined
      : { directives: { "upgrade-insecure-requests": null, "img-src": ["'self'", "data:"] } },
    strictTransportSecurity: isProduction,
  }));
  app.use("/api", (_req, res, next) => { res.setHeader("Cache-Control", "no-store"); next(); });
  // Same-origin cookie demo: reject unsafe requests from outside the configured web origin.
  app.use(requireTrustedOrigin(expectedOrigin));

  const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20,
    standardHeaders: "draft-8", legacyHeaders: false, skipSuccessfulRequests: true,
    message: errorBody("TOO_MANY_ATTEMPTS", "Try again later.") });

  // Liveness tests only the HTTP process. Readiness tests the database too.
  app.get("/api/live", (_req, res) => res.json({ status: "ok", service: "study-tasks-api" }));
  app.get("/api/health", async (_req, res) => {
    await repository.ping();
    return res.json({ status: "ok", service: "study-tasks-api", storage: "postgres" });
  });

  app.use("/api", express.json({ limit: "16kb" }));
  // Only protected API work needs the session store. Liveness, readiness and
  // built assets must stay available independently of that per-request load.
  app.use(["/api/auth", "/api/tasks"], sessionMiddleware);

  app.post("/api/auth/register", ...(enableRateLimit ? [authLimit] : []), async (req, res) => {
    const parsed = validateCredentials(req.body, { registering: true });
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const { email, password } = parsed.value;
    const passwordHash = await passwordHasher(password);
    let user;
    try { user = await users.create({ email, passwordHash }); }
    catch (error) {
      if (error?.code === "23505") {
        return res.status(409).json(errorBody("CANNOT_REGISTER", "Could not register with these details."));
      }
      throw error;
    }
    await newSession(req, user);
    return res.status(201).json({ user: publicUser(user) });
  });

  app.post("/api/auth/login", ...(enableRateLimit ? [authLimit] : []), async (req, res) => {
    const parsed = validateCredentials(req.body);
    if (!parsed.ok) return res.status(401).json(errorBody("INVALID_CREDENTIALS", "Invalid email or password."));
    const record = await users.getByEmail(parsed.value.email);
    const valid = record ? await passwordVerifier(record.password_hash, parsed.value.password) : false;
    if (!valid) return res.status(401).json(errorBody("INVALID_CREDENTIALS", "Invalid email or password."));
    const user = publicUser(record);
    await newSession(req, user);
    return res.json({ user });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session?.userId) return res.status(401).json(errorBody("AUTH_REQUIRED", "Sign in to continue."));
    const user = await users.getById(req.session.userId);
    if (!user) return res.status(401).json(errorBody("AUTH_REQUIRED", "Sign in to continue."));
    return res.json({ user });
  });

  app.post("/api/auth/logout", async (req, res) => {
    if (!req.session) return res.status(204).end();
    await new Promise((resolve, reject) => req.session.destroy((error) => error ? reject(error) : resolve()));
    res.clearCookie(sessionCookieName, { path: "/", httpOnly: true, sameSite: "lax", secure: isProduction });
    return res.status(204).end();
  });

  // Every task route requires a session. Trust userId from the server session,
  // NEVER ownerId/userId supplied by the browser in request bodies/queries.
  app.use("/api/tasks", requireAuth);
  app.get("/api/tasks", async (req, res) => {
    const filter = parseCompletedFilter(req.query.completed);
    if (!filter.ok) return res.status(400).json(errorBody("INVALID_FILTER", filter.message));
    const data = await repository.list(req.session.userId, { completed: filter.value });
    return res.json({ data, count: data.length });
  });
  app.get("/api/tasks/:id", async (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const task = await repository.get(req.session.userId, id);
    if (!task) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.json({ data: task });
  });
  app.post("/api/tasks", async (req, res) => {
    const parsed = validateCreateBody(req.body);
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const task = await repository.create(req.session.userId, parsed.value);
    return res.status(201).location(`/api/tasks/${task.id}`).json({ data: task });
  });
  app.patch("/api/tasks/:id", async (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const parsed = validatePatchBody(req.body);
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const task = await repository.update(req.session.userId, id, parsed.value);
    if (!task) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.json({ data: task });
  });
  app.delete("/api/tasks/:id", async (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const removed = await repository.remove(req.session.userId, id);
    if (!removed) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.status(204).end();
  });

  // Unknown /api paths must stay JSON 404s and must NOT render the React SPA.
  app.use("/api", (_req, res) => res.status(404).json(errorBody("ROUTE_NOT_FOUND", "Unknown API route.")));
  if (staticDir) mountReactBuild(app, staticDir);
  app.use((_req, res) => res.status(404).json(errorBody("ROUTE_NOT_FOUND", "Unknown route.")));
  app.use((error, req, res, _next) => {
    const result = classifyPublicError(error);
    logPublicError({ error, requestId: req.requestId, status: result.status }, enableLogging ? logger : null);
    return res.status(result.status).json(errorBody(result.code, result.message));
  });
  return app;
}
