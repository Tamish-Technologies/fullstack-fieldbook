import express from "express";
import { wantsHtmlNavigation } from "./spa-policy.js";
import { existsSync } from "node:fs";
import { join } from "node:path";
/** One public origin for the React build and session-cookie API. */
export function mountReactBuild(app, directory) {
  const indexFile = join(directory, "index.html");
  if (!existsSync(indexFile)) throw new Error("React build missing: run npm --prefix frontend run build.");
  app.use(express.static(directory, { index: false, maxAge: 0, dotfiles: "deny" }));
  app.use((req, res, next) => {
    if (req.path.startsWith("/assets/") || /\.[^/]+$/.test(req.path) || !wantsHtmlNavigation(req)) return next();
    res.setHeader("Cache-Control", "no-cache");
    return res.sendFile(indexFile);
  });
}
