import { once } from "node:events";
import { fileURLToPath } from "node:url";
import { createApp } from "./app.js";
import { loadConfig } from "./config.js";
import { createDbPool } from "./db.js";
import { createTaskRepository } from "./task-repository.js";
import { createUserRepository } from "./auth-repository.js";
import { createSessionMiddleware } from "./session.js";

let config;
try {
  config = loadConfig();
} catch (error) {
  // loadConfig throws fixed, redacted configuration messages.
  console.error(error.message);
  process.exit(1);
}
if (config.isProduction || !/^http:\/\/127\.0\.0\.1(?::[1-9]\d{0,4})?$/.test(config.webOrigin) ||
    config.trustProxyHops !== 0) {
  console.error("This learner starter runs on loopback HTTP with TRUST_PROXY_HOPS=0. Use npm run preview:local for the built app.");
  process.exit(1);
}
const serveBuiltFrontend = process.env.SERVE_BUILT_FRONTEND === "1";
const staticDir = serveBuiltFrontend
  ? fileURLToPath(new URL("../../frontend/dist/", import.meta.url)) : null;
const pool = createDbPool();
try {
  await pool.query("SELECT 1 FROM user_sessions LIMIT 0");
  const app = createApp({
    repository: createTaskRepository(pool),
    users: createUserRepository(pool),
    sessionMiddleware: createSessionMiddleware(pool, { secret: process.env.SESSION_SECRET }),
    expectedOrigin: config.webOrigin,
    staticDir,
  });
  const server = app.listen(config.port, "127.0.0.1");
  await once(server, "listening");
  console.info(JSON.stringify({
    event: "server_started",
    mode: staticDir ? "built_preview" : "local_api",
    address: `http://127.0.0.1:${config.port}`,
  }));
  let stopping = false;
  function shutdown() {
    if (stopping) return;
    stopping = true;
    server.close(async () => {
      await pool.end();
      process.exit(0);
    });
  }
  process.once("SIGINT", shutdown);
  process.once("SIGTERM", shutdown);
} catch (error) {
  const message = error?.code === "EADDRINUSE"
    ? "The local API port is already in use. Stop the other learner process or change PORT."
    : error?.code === "42P01"
      ? "The session table is missing. Run npm run migrate in backend."
      : error?.message?.startsWith("React build missing:")
        ? "React build missing. Run npm --prefix frontend run build from the project root."
        : "Could not start the local API. Check PostgreSQL and the private backend/.env.";
  console.error(message);
  await pool.end();
  process.exitCode = 1;
}
