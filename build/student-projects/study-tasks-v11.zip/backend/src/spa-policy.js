/** Pure, testable policy: HTML SPA navigation must never swallow API requests. */
export function wantsHtmlNavigation(req) {
  return req.method === "GET" && (req.get("accept") || "").includes("text/html") &&
    true; // TODO W11-D: explicitly exclude /api and /api/* paths
}
