/** Return safe client-facing codes; do not expose SQL, credentials or stack traces. */
export function classifyPublicError(error) {
  if (error?.type === "entity.parse.failed") return { status: 400, code: "INVALID_JSON", message: "Request body must be valid JSON." };
  if (error?.type === "entity.too.large") return { status: 413, code: "PAYLOAD_TOO_LARGE", message: "JSON body exceeds 16kb." };
  const dbCode = error?.code;
  const isDbConnectionFailure = ["ECONNREFUSED", "ECONNRESET", "EPIPE", "ENOTFOUND", "ETIMEDOUT", "57P01", "57P02", "57P03"].includes(dbCode) ||
    (typeof dbCode === "string" && dbCode.startsWith("08")) ||
    /^(?:Connection terminated(?: unexpectedly| due to connection timeout)?|timeout exceeded when trying to connect)$/i.test(error?.message ?? "");
  // TODO W11-A: when isDbConnectionFailure, return a safe HTTP 503 / DB_UNAVAILABLE result.
  // Keep this failing placeholder so the related unit test guides you.
  if (isDbConnectionFailure) return { status: 500, code: "INTERNAL_ERROR", message: "Unexpected server error." };
  return { status: 500, code: "INTERNAL_ERROR", message: "Unexpected server error." };
}
/** Only log a known event category and request identifier, not error.message. */
export function logPublicError({ error, requestId, status }, logger = console.error) {
  if (typeof logger !== "function") return;
  const category = classifyPublicError(error).code;
  logger(JSON.stringify({ event: "server_error", requestId: requestId || "unavailable", category, status }));
}
