const UNSAFE = new Set(["POST", "PUT", "PATCH", "DELETE"]);
/**
 * Cookie-based login requires CSRF defenses. With this same-origin teaching app,
 * a strict allowlisted Origin/Referer check protects unsafe requests. In a
 * different deployment architecture, re-evaluate this with CSRF tokens.
 */
export function isTrustedRequest({ method, origin, referer }, expectedOrigin) {
  if (!UNSAFE.has(method.toUpperCase())) return true;
  if (typeof expectedOrigin !== "string" || !expectedOrigin) return false;
  if (origin) return origin === expectedOrigin; // Origin: null must fail.
  if (!referer) return false;
  try { return new URL(referer).origin === expectedOrigin; }
  catch { return false; }
}
export function requireTrustedOrigin(expectedOrigin) {
  return (req, res, next) => {
    if (isTrustedRequest({ method: req.method, origin: req.get("origin"), referer: req.get("referer") }, expectedOrigin)) {
      return next();
    }
    return res.status(403).json({ error: { code: "UNTRUSTED_ORIGIN", message: "Request origin not allowed." } });
  };
}
