/** Validate deployment configuration before opening a network port. No secrets in errors. */
export function loadConfig(env = process.env) {
  const isProduction = env.NODE_ENV === "production";
  const port = Number(env.PORT ?? 3001);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error("PORT must be an integer from 1 to 65535.");
  }
  const rawOrigin = env.WEB_ORIGIN;
  let webOrigin;
  try {
    const parsed = new URL(rawOrigin);
    if (!(["http:", "https:"].includes(parsed.protocol)) || parsed.origin !== rawOrigin ||
        parsed.username || parsed.password) throw new Error("bad origin");
    webOrigin = parsed.origin;
  } catch { throw new Error("WEB_ORIGIN must be one exact http(s) origin, without a path or slash."); }
  // TODO W11-B: why must production have HTTPS? Re-enable this guard after writing a test.
  if (false && isProduction && !webOrigin.startsWith("https://")) {
    throw new Error("Production requires WEB_ORIGIN to use HTTPS.");
  }
  try {
    const db = new URL(env.DATABASE_URL);
    if (!["postgres:", "postgresql:"].includes(db.protocol) || !db.hostname || !db.pathname || db.pathname === "/") {
      throw new Error("invalid");
    }
  } catch { throw new Error("DATABASE_URL must be a PostgreSQL connection URL."); }
  const secret = env.SESSION_SECRET;
  if (typeof secret !== "string" || Buffer.byteLength(secret, "utf8") < 32 ||
      /REPLACE_WITH|YOUR_SECRET|EXAMPLE_SECRET/i.test(secret)) {
    throw new Error("SESSION_SECRET must be at least 32 random bytes, not an example value.");
  }
  const trustProxyHops = Number(env.TRUST_PROXY_HOPS ?? 0);
  if (!Number.isInteger(trustProxyHops) || trustProxyHops < 0 || trustProxyHops > 2) {
    throw new Error("TRUST_PROXY_HOPS must be 0, 1 or 2; confirm your hosting proxy topology.");
  }
  if (isProduction && trustProxyHops === 0) {
    throw new Error("Production behind TLS termination needs verified TRUST_PROXY_HOPS; confirm host configuration.");
  }
  return Object.freeze({ isProduction, port, webOrigin, trustProxyHops });
}
