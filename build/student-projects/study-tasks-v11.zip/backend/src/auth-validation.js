/** Validate untrusted input on the server; UI validation is only for UX. */
export function normalizeEmail(email) {
  return typeof email === "string" ? email.trim().toLowerCase() : "";
}
export function validateCredentials(body, { registering = false } = {}) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return { ok: false, message: "Expected a JSON object." };
  }
  if (Object.keys(body).some((key) => !["email", "password"].includes(key))) {
    return { ok: false, message: "Only email and password are accepted." };
  }
  const email = normalizeEmail(body.email);
  if (!email || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { ok: false, message: "Enter a valid email address." };
  }
  if (typeof body.password !== "string") {
    return { ok: false, message: "Password must be a string." };
  }
  // This is a teaching policy, not a complete password-risk evaluation.
  if (registering && (body.password.length < 12 || body.password.length > 128)) {
    return { ok: false, message: "Use a password between 12 and 128 characters." };
  }
  // Limit extreme input sizes on login too; a huge password wastes hash work.
  if (body.password.length > 128 || body.password.length === 0) {
    return { ok: false, message: "Invalid email or password." };
  }
  return { ok: true, value: { email, password: body.password } };
}
export function publicUser(row) { return { id: row.id, email: row.email }; }
