import { publicUser } from "./auth-validation.js";
/** Only the database holds password_hash. Never return it in the public API. */
export function createUserRepository(pool) {
  return {
    async getByEmail(email) {
      const { rows } = await pool.query(
        "SELECT id, email, password_hash FROM users WHERE email = $1", [email]
      );
      return rows[0] ?? null;
    },
    async getById(id) {
      const { rows } = await pool.query(
        "SELECT id, email FROM users WHERE id = $1", [id]
      );
      return rows[0] ? publicUser(rows[0]) : null;
    },
    async create({ email, passwordHash }) {
      const { rows } = await pool.query(
        "INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email",
        [email, passwordHash]
      );
      return publicUser(rows[0]);
    }
  };
}
