# Week 11 reliability exercises

Work on one intentional defect at a time. Reproduce its failure, make the smallest correction, and rerun the same assertion. Commands below run from backend unless noted.

| Practice defect | Focused test | Observed behavior to verify |
| --- | --- | --- |
| Public error classification | `node --test tests/public-errors.test.mjs` | Connection failures return a safe 503 and unknown exceptions stay generic |
| Production configuration rule | `node --test tests/config.test.mjs` | The pure validator rejects an HTTP production origin with an HTTPS configuration message |
| Request correlation | `node --test tests/request-log.test.mjs` | Response ID matches the server-generated ID in the sanitized log |
| Built navigation fallback | `node --test tests/spa-policy.test.mjs` | The fallback policy declines API paths and handles an HTML page navigation |

Use the TODOs in the matching files as starting points. Improve a test by adding an invalid proxy-hop value or another synthetic database connection error. Keep the existing assertions. The server has a separate loopback limit so the config exercise can run without exposing a teaching service publicly.

After the focused checks, use `npm test` to exercise the HTTP contracts. Try the two-account test against the verified local practice databases. Run the built preview instructions from START_HERE.md. Use the browser's Network panel to correlate a safe request and observe a controlled failure. Check that a failed task save keeps the draft and old confirmed list. Once readiness recovers, refresh or check the server's confirmed list before resubmitting a write with an uncertain outcome.

Complete the release report. Work without an assistant or ask for one hint at a time. Inspect any proposed commands and avoid sharing secrets or private logs.
