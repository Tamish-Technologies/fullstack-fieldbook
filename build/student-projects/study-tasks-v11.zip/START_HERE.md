# Study Tasks v11

Use this separate learner project for Week 11. It carries forward the completed Week 10 account and task behavior. Four intentional reliability defects give you a focused test-and-fix exercise. Use fictional accounts and separate local practice databases.

## 1. Run the initial checks

Use Node 22.12+ or Node 24, npm, and PostgreSQL 17. Extract the backend and frontend folders together. From the project root run:

```sh
npm --prefix backend run test:unit
npm --prefix backend ci
npm --prefix frontend ci
npm --prefix backend test
npm --prefix frontend test
```

The first command runs the pure tests without installing Express. Expect failures for the four exercise topics: connection-error classification, the production HTTPS check, the response request ID, and the SPA fallback policy. The full suite has additional HTTP assertions for those same defects. The reviewed download starts at 25 of 29 passing pure checks and 32 of 38 passing full backend checks. See [STUDENT_EXERCISES.md](STUDENT_EXERCISES.md) to work through them.

## 2. Configure PostgreSQL for local study

Create two new databases on your local PostgreSQL server. Use your Week 10 learning role, or create `study_tasks` from an administrator connection with `CREATE ROLE study_tasks LOGIN;` and set its local password in the psql `\password study_tasks` prompt or pgAdmin's role dialog. Run these statements separately outside a transaction. Check existing names and owners before creating them.

```sql
CREATE DATABASE study_tasks_week11 OWNER study_tasks;
CREATE DATABASE study_tasks_week11_test OWNER study_tasks;
```

Connect as the learning role to each database and run `SELECT current_database(), current_user;`. Copy `backend/.env.example` to `backend/.env` and fill in the development and test URLs. Percent-encode reserved characters in the URL password. Generate a random session secret using the command in the example. Keep values in the ignored file. Run `npm --prefix backend run migrate` from the project root to prepare the development database. The live tests prepare and clean up their own schema inside the separate test database.

## 3. Start development or the built preview

**Development** uses two terminals. Run `npm run dev` in backend and in frontend. Open exactly `http://127.0.0.1:5173` and leave WEB_ORIGIN set to that address. If you change the web port, match WEB_ORIGIN to the address Vite prints. If the backend port changes, set PORT in backend/.env and set the same number as STUDY_TASKS_API_PORT in frontend/.env.local.

**Built preview** uses Express and the frontend build. Stop the dev API in its terminal so it releases the port. From the project root run:

```sh
npm --prefix frontend run build
npm --prefix backend run preview:local
```

Open the exact loopback address printed by Express, usually `http://127.0.0.1:3001`. The preview command automatically sets WEB_ORIGIN to the API address for this run. No Vite server is needed. Development uses the Vite address again when you return to the two-terminal workflow. The preview uses local HTTP and the tests validate the production configuration rule with synthetic inputs. Real HTTPS checks belong to a separate, reviewed hosting setup.

Check /api/live and /api/health. After fixing the exercises, create fictional accounts in two separate profiles. Refresh /tasks and /ideas. Verify an unknown /api path responds with JSON 404 even when the browser asks for HTML. A missing asset should produce 404 too.

## 4. Record the rehearsal

Run `npm --prefix backend run test:db` only after verifying the disposable test connection. Complete the local checks and fill [RELEASE_REPORT.md](RELEASE_REPORT.md). State which checks ran, what recovered, and how you would roll back. Keep connection strings, credentials, cookie values and private logs out of the report. Hosting is optional.
