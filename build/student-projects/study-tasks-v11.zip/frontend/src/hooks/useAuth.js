import { useCallback, useEffect, useRef, useState } from "react";
import { authApi } from "../lib/auth-api.js";

export function useAuth() {
  const [user, setUser] = useState(null);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState("");
  const [check, setCheck] = useState(0);
  const pending = useRef(false);

  useEffect(() => {
    const controller = new AbortController();
    authApi.me({ signal: controller.signal })
      .then((current) => {
        if (controller.signal.aborted) return;
        setUser(current);
        setStatus("signedin");
      })
      .catch((e) => {
        if (controller.signal.aborted) return;
        setStatus(e.status === 401 ? "anonymous" : "error");
        setError(e.status === 401 ? "" : e.message);
      });
    return () => controller.abort();
  }, [check]);

  function retry() {
    setError("");
    setStatus("loading");
    setCheck((value) => value + 1);
  }

  async function submit(mode, email, password) {
    if (pending.current) return;
    pending.current = true;
    setStatus("submitting");
    setError("");
    try {
      const current = mode === "register"
        ? await authApi.register(email, password) : await authApi.login(email, password);
      setUser(current);
      setStatus("signedin");
    } catch (e) {
      setError(e.message);
      setStatus("anonymous");
    } finally {
      pending.current = false;
    }
  }

  async function logout() {
    if (pending.current) return;
    pending.current = true;
    setStatus("signingout");
    setError("");
    try {
      await authApi.logout();
      setUser(null);
      setStatus("anonymous");
    } catch (e) {
      if (e.status === 401) {
        setUser(null);
        setStatus("anonymous");
      } else {
        setError(`Could not sign out: ${e.message}`);
        setStatus("signedin");
      }
    } finally {
      pending.current = false;
    }
  }

  const markSignedOut = useCallback(() => {
    if (pending.current) return;
    setUser(null);
    setStatus("anonymous");
    setError("Session ended. Please sign in again.");
  }, []);
  return { user, status, error, retry, submit, logout, markSignedOut, clearError: () => setError("") };
}
