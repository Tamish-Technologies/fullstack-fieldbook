import { useState } from "react";
import { validateTitle } from "../lib/task-logic.js";

export default function TaskForm({ onAdd, disabled = false }) {
  const [draft, setDraft] = useState("");
  const [error, setError] = useState("");

  async function handleSubmit(event) {
    event.preventDefault();
    const check = validateTitle(draft);
    if (!check.ok) { setError(check.error); return; }
    const result = await onAdd(check.title);
    if (result.ok) {
      setDraft(""); // Clear ONLY after the backend confirms creation.
      setError("");
    } else {
      setError(result.error);
    }
  }
  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <label htmlFor="task-title">Add a study task</label>
      <div className="form-row">
        <input id="task-title" type="text" value={draft} disabled={disabled}
          onChange={(event) => { setDraft(event.target.value); setError(""); }}
          placeholder="e.g. Practice Express routes" />
        <button type="submit" disabled={disabled}>{disabled ? "Saving..." : "Add task"}</button>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
    </form>
  );
}
