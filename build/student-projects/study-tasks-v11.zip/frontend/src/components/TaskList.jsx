import TaskItem from "./TaskItem.jsx";

export default function TaskList({ tasks, total, onToggle, onDelete, onRename, disabled = false }) {
  if (tasks.length === 0) {
    return <p className="empty-state">{total === 0 ?
      "No server tasks yet. Add your first one." : "No tasks match this view."}</p>;
  }
  return (
    <ul className="task-list">
      {tasks.map((task) => <TaskItem key={task.id} task={task} disabled={disabled}
        onToggle={onToggle} onDelete={onDelete} onRename={onRename} />)}
    </ul>
  );
}
