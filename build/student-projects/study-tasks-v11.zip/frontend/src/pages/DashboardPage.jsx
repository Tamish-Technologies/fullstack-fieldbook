import { Link } from "react-router";
import { countRemaining } from "../lib/task-logic.js";

export default function DashboardPage({ tasks, status, error, onRetry }) {
  const remaining = countRemaining(tasks);
  const completed = tasks.length - remaining;
  return (
    <section className="page-panel" aria-labelledby="dashboard-title">
      <p className="eyebrow">YOUR FULL-STACK DASHBOARD</p>
      <h1 id="dashboard-title" className="page-title">Dashboard</h1>
      <p className="muted">Your private task counters come from PostgreSQL through the authenticated Express API.</p>
      {status === "loading" && <p className="status-box" role="status">Loading server statistics...</p>}
      {status === "error" && <div className="status-box status-error" role="alert">
        <strong>Server is unavailable.</strong><p>{error}</p>
        <button type="button" onClick={onRetry}>Try again</button>
      </div>}
      {status === "ready" && <div className="stat-grid">
        <div className="stat"><strong>{tasks.length}</strong><span>Total tasks</span></div>
        <div className="stat"><strong>{remaining}</strong><span>To do</span></div>
        <div className="stat"><strong>{completed}</strong><span>Completed</span></div>
      </div>}
      <div className="quick-links">
        <Link to="/tasks" className="pill-link">Manage tasks</Link>
        <Link to="/ideas" className="pill-link secondary-link">Find study ideas</Link>
      </div>
      <p className="muted small-note">A second registered account should see a separate, private task list.</p>
    </section>
  );
}
