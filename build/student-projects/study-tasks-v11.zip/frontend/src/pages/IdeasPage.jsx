import { useState } from "react";
import { Link } from "react-router";
import { SAMPLE_IDEAS } from "../lib/sample-ideas.js";

export default function IdeasPage({ onAddIdea, tasksReady, busy }) {
  const [notice, setNotice] = useState("");
  async function addIdea(idea) {
    setNotice("");
    const result = await onAddIdea(idea);
    setNotice(result.ok ? "Saved to your study tasks." : `Could not save: ${result.error}`);
  }
  return (
    <section className="page-panel" aria-labelledby="ideas-heading">
      <h1 id="ideas-heading" className="page-title">Study Idea Inbox</h1>
      <p className="muted">Use these bundled examples to practise adding to <Link to="/tasks">your tasks</Link>.</p>
      {!tasksReady && <p className="status-box" role="status">Connect to the task API before saving an idea.</p>}
      {notice && <p className="status-box" role="status">{notice}</p>}
      <ul className="idea-list" aria-label="Study ideas">
        {SAMPLE_IDEAS.map((idea) => <li className="idea-item" key={idea.id}>
          <span>{idea.title}</span>
          <button type="button" disabled={!tasksReady || busy} onClick={() => addIdea(idea)}
            aria-label={`Add to tasks: ${idea.title}`}>Add to tasks</button>
        </li>)}
      </ul>
    </section>
  );
}
