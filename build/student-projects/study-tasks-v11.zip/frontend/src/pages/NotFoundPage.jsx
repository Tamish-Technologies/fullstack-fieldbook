import { Link } from "react-router";

export default function NotFoundPage() {
  return (
    <section className="page-panel" aria-labelledby="missing-title">
      <p className="eyebrow">404 / PAGE NOT FOUND</p>
      <h2 className="page-title" id="missing-title">This route does not exist.</h2>
      <p className="muted">Check the URL or return to the dashboard.</p>
      <Link className="pill-link" to="/">Go to dashboard</Link>
    </section>
  );
}
