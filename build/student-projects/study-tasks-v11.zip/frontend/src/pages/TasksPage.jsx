import { useState } from "react";
import TaskForm from "../components/TaskForm.jsx";
import TaskToolbar from "../components/TaskToolbar.jsx";
import TaskList from "../components/TaskList.jsx";
import { countRemaining, getVisibleTasks } from "../lib/task-logic.js";

export default function TasksPage({ tasks, status, loadError, mutationError, busy, onRetry,
  onAdd, onToggle, onDelete, onRename }) {
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest");
  const visibleTasks = getVisibleTasks(tasks, { filter, query, sort });

  return (
    <section className="page-panel" aria-labelledby="tasks-heading">
      <p className="eyebrow">SERVER-OWNED TASKS</p>
      <h1 className="page-title" id="tasks-heading">My tasks</h1>
      <p className="muted">Only tasks belonging to your signed-in account appear here. Every backend SQL query verifies ownership.</p>
      {status === "loading" && <p role="status" className="status-box">Loading tasks from the server...</p>}
      {status === "error" && <div className="status-box status-error" role="alert">
        <strong>Tasks could not load.</strong><p>{loadError}</p>
        <button type="button" onClick={onRetry}>Retry connection</button>
      </div>}
      {status === "ready" && <>
        <TaskForm onAdd={onAdd} disabled={busy} />
        {mutationError && <div className="status-box status-error" role="alert">
          <strong>Change not saved.</strong> {mutationError}
        </div>}
        <section className="tasks-section" aria-label="Server tasks">
          <div className="section-heading">
            <h2>Study list</h2><p className="count">{countRemaining(tasks)} remaining</p>
          </div>
          <TaskToolbar filter={filter} onFilterChange={setFilter} query={query}
            onQueryChange={setQuery} sort={sort} onSortChange={setSort} />
          <p className="results-count" aria-live="polite">{visibleTasks.length} shown of {tasks.length}</p>
          <TaskList tasks={visibleTasks} total={tasks.length} disabled={busy}
            onToggle={onToggle} onDelete={(id) => {
              if (window.confirm("Permanently delete this task?")) return onDelete(id);
            }} onRename={onRename} />
        </section>
      </>}
    </section>
  );
}
