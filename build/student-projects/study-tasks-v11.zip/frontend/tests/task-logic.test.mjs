import test from "node:test";
import assert from "node:assert/strict";
import {
  normalizeTitle, validateTitle, isValidTask, parseStoredTasks,
  addTaskToList, renameTaskInList, toggleTaskInList,
  deleteTaskFromList, getVisibleTasks, countRemaining
} from "../src/lib/task-logic.js";
import { readStoredTasks, writeStoredTasks, STORAGE_KEY } from "../src/lib/storage.js";

const A = Object.freeze({ id: 1, title: "Read chapter", completed: false });
const B = Object.freeze({ id: 2, title: "Revise arrays", completed: true });
const C = Object.freeze({ id: 3, title: "Practice React", completed: false });
const FIXTURE = Object.freeze([A, B, C]);

function fakeStorage(initial = {}) {
  const values = new Map(Object.entries(initial));
  return {
    getItem(key) { return values.has(key) ? values.get(key) : null; },
    setItem(key, value) { values.set(key, String(value)); },
    snapshot() { return Object.fromEntries(values); }
  };
}

test("normalization trims strings", () => {
  assert.equal(normalizeTitle("  Practice  "), "Practice");
  assert.equal(normalizeTitle(null), "");
});
test("rejects blank title", () => {
  assert.equal(validateTitle("   ").ok, false);
});
test("rejects title longer than 80 characters", () => {
  assert.equal(validateTitle("x".repeat(81)).ok, false);
});
test("accepts 80-character title", () => {
  assert.equal(validateTitle("x".repeat(80)).ok, true);
});
test("task schema requires positive numeric ID and boolean completed", () => {
  assert.equal(isValidTask(A), true);
  assert.equal(isValidTask({ ...A, id: "1" }), false);
  assert.equal(isValidTask({ ...A, completed: "yes" }), false);
});
test("add creates a new array without modifying the source", () => {
  const result = addTaskToList(FIXTURE, 4, "  Finish project  ");
  assert.equal(result.ok, true);
  assert.equal(result.tasks[3].title, "Finish project");
  assert.equal(FIXTURE.length, 3);
});
test("add rejects duplicate IDs", () => {
  assert.equal(addTaskToList(FIXTURE, 2, "Another task").ok, false);
});
test("add rejects blank input without changing existing reference", () => {
  const result = addTaskToList(FIXTURE, 4, " ");
  assert.equal(result.ok, false);
  assert.equal(result.tasks, FIXTURE);
});
test("rename changes only selected task without mutation", () => {
  const result = renameTaskInList(FIXTURE, 2, "  Revise objects  ");
  assert.equal(result.ok, true);
  assert.equal(result.tasks[1].title, "Revise objects");
  assert.equal(B.title, "Revise arrays");
  assert.equal(result.tasks[0], A);
});
test("rename rejects missing task ID", () => {
  assert.equal(renameTaskInList(FIXTURE, 50, "Hello").ok, false);
});
test("rename rejects whitespace-only title", () => {
  assert.equal(renameTaskInList(FIXTURE, 1, " ").ok, false);
});
test("toggle flips selected task only", () => {
  const result = toggleTaskInList(FIXTURE, 1);
  assert.equal(result[0].completed, true);
  assert.equal(result[1], B);
  assert.equal(A.completed, false);
});
test("delete removes matching ID without mutating input", () => {
  assert.deepEqual(deleteTaskFromList(FIXTURE, 2).map((t) => t.id), [1, 3]);
  assert.equal(FIXTURE.length, 3);
});
test("countRemaining counts incomplete tasks", () => {
  assert.equal(countRemaining(FIXTURE), 2);
});
test("filter shows active tasks only", () => {
  assert.deepEqual(getVisibleTasks(FIXTURE, { filter: "active" }).map((t) => t.id), [3, 1]);
});
test("filter shows completed tasks only", () => {
  assert.deepEqual(getVisibleTasks(FIXTURE, { filter: "completed" }).map((t) => t.id), [2]);
});
test("search ignores case and surrounding spaces", () => {
  assert.deepEqual(getVisibleTasks(FIXTURE, { query: "  REACT " }).map((t) => t.id), [3]);
});
test("sort oldest does not mutate source order", () => {
  assert.deepEqual(getVisibleTasks(FIXTURE, { sort: "oldest" }).map((t) => t.id), [1, 2, 3]);
  assert.deepEqual(FIXTURE.map((t) => t.id), [1, 2, 3]);
});
test("stored tasks filter out malformed items and repeated IDs", () => {
  const input = JSON.stringify([A, A, { id: 77, title: "", completed: false }, B]);
  assert.deepEqual(parseStoredTasks(input), [A, B]);
});
test("malformed JSON throws in pure parser", () => {
  assert.throws(() => parseStoredTasks("{broken"));
});
test("storage read returns an empty list for missing key", () => {
  assert.deepEqual(readStoredTasks(fakeStorage()).tasks, []);
});
test("storage read catches malformed JSON without overwriting", () => {
  const store = fakeStorage({ [STORAGE_KEY]: "{broken" });
  const result = readStoredTasks(store);
  assert.equal(result.ok, false);
  assert.deepEqual(result.tasks, []);
  assert.equal(store.getItem(STORAGE_KEY), "{broken");
});
test("storage round-trip preserves valid tasks", () => {
  const store = fakeStorage();
  assert.equal(writeStoredTasks(store, FIXTURE).ok, true);
  assert.deepEqual(readStoredTasks(store).tasks, FIXTURE);
});
test("storage failures return errors without throwing", () => {
  const broken = { getItem() { throw new Error("blocked"); }, setItem() { throw new Error("blocked"); } };
  assert.equal(readStoredTasks(broken).ok, false);
  assert.equal(writeStoredTasks(broken, FIXTURE).ok, false);
});
test("saved key remains compatible with Weeks 2-4", () => {
  assert.equal(STORAGE_KEY, "study-tasks-week2");
});
