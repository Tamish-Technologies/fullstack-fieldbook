import test from "node:test";
import assert from "node:assert/strict";
import { friendlyError } from "../src/lib/friendly-error.js";
test("offline and DB errors have actionable nontechnical messages",()=>{
 assert.match(friendlyError({code:"NETWORK_ERROR"}),/connection/i);
 assert.match(friendlyError({code:"DB_UNAVAILABLE"}),/temporarily/i);
});
test("unknown backend details never show to users",()=>{
 assert.doesNotMatch(friendlyError({code:"UNEXPECTED",message:"password=private"}),/private|password/);
});
