import test from "node:test";
import assert from "node:assert/strict";
import { createAuthApi } from "../src/lib/auth-api.js";
const user={id:"u1",email:"student@example.test"};
test("login sends JSON and uses same-origin cookie credentials",async()=>{
  let seen;const api=createAuthApi(async(path,options)=>{seen={path,options};return Response.json({user});});
  assert.deepEqual(await api.login("student@example.test","testpassword"),user);
  assert.equal(seen.path,"/api/auth/login");
  assert.equal(seen.options.credentials,"same-origin");
  assert.equal(seen.options.method,"POST");
  assert.equal(JSON.parse(seen.options.body).password,"testpassword");
});
test("me reports unsigned-in state as API error 401",async()=>{
  const api=createAuthApi(async()=>Response.json({error:{code:"AUTH_REQUIRED",message:"Sign in to continue."}},{status:401}));
  await assert.rejects(api.me(),e=>e.status===401&&e.code==="AUTH_REQUIRED");
});
test("logout consumes 204 without JSON parsing",async()=>{
  const api=createAuthApi(async()=>new Response(null,{status:204}));
  assert.equal(await api.logout(),null);
});
test("bad user shape is rejected",async()=>{
  const api=createAuthApi(async()=>Response.json({user:{email:"oops"}}));
  await assert.rejects(api.register("a@b.test","hello"),e=>e.code==="BAD_RESPONSE");
});
