import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const config = loadEnv(mode, process.cwd(), "STUDY_TASKS_");
  const apiPort = Number(config.STUDY_TASKS_API_PORT ?? 3001);
  if (!Number.isInteger(apiPort) || apiPort < 1 || apiPort > 65535) {
    throw new Error("STUDY_TASKS_API_PORT must be an integer between 1 and 65535.");
  }
  return {
    plugins: [react()],
    server: {
      host: "127.0.0.1", port: 5173, strictPort: true,
      proxy: { "/api": `http://127.0.0.1:${apiPort}` },
    },
  };
});
