# Study Tasks v11 frontend

Run `npm ci`, `npm test` and `npm run build`. In development run `npm run dev` alongside the backend. For the release rehearsal, launch the built preview from the backend, then open its printed address. Follow [START_HERE.md](../START_HERE.md) for database and port setup.

Use fictional accounts in distinct browser profiles. Verify refresh on My tasks and Idea inbox. A failed save keeps the draft and the last confirmed list.
