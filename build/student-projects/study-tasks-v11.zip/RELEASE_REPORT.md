# Local release rehearsal

- Candidate version or commit:
- Reviewed files and migration decision:
- Unit and HTTP results:
- Verified test database outcome:
- Built-preview command and deep-link results:
- Two-account permission matrix:
- One redacted request ID and matching status:
- Reproduced defect, correction and verification:
- Readiness failure and recovery results:
- Backup/restore or prior-build rollback rehearsal:
- Environment variable names and remaining verification:
- Release decision and reason:

Use fictional data. Record skipped checks with their reasons. Leave passwords, hashes, session values, connection strings and raw request bodies out.
