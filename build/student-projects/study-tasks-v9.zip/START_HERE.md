# Study Tasks v9 learner starter

Use Node 24 or a compatible release at least 22.12. Keep your Week 8 project and Git checkpoint. Extract both folders together. This starter retains the Week 8 React and HTTP contract, adds the database wiring and migration, and leaves the five SQL repository methods for you to implement.

## Local PostgreSQL first

Install PostgreSQL and psql or pgAdmin from https://www.postgresql.org/download/. Start its service. In a local administrator session, create a dedicated login named study_tasks with a local password. In psql use CREATE ROLE study_tasks LOGIN; then the separate interactive command \password study_tasks. In pgAdmin create the role with login enabled and set the password in its Definition tab. Use separate executions for each CREATE DATABASE statement and stay outside a transaction:

```sql
CREATE DATABASE study_tasks_week9 OWNER study_tasks;
CREATE DATABASE study_tasks_week9_test OWNER study_tasks;
```

Connect as study_tasks to each database and run SELECT current_database(), current_user;. Verify the names differ. Preserve any existing databases. Only use fictional data in these two dedicated local databases.

## Backend (first terminal)

In backend run npm ci. Copy .env.example to .env (PowerShell: Copy-Item .env.example .env). Set DATABASE_URL for development and TEST_DATABASE_URL for the separate _test database. The example values contain placeholders. Percent-encode special characters in the URL password. Keep the real .env out of Git and only in backend. Run npm run migrate, check the printed development database name, then npm run dev.

GET http://127.0.0.1:3001/api/health should report postgres. This proves a database connection. The five task methods become usable when you finish the repository in Lessons 9–10. Before that, a tasks request can return 500 even when health is 200.

## Frontend (second terminal)

In frontend run npm ci and npm run dev. Use the Vite address it prints. The relative /api requests go through the local dev proxy to port 3001. If you changed the backend port, update that proxy target and restart Vite. Try /server to see health and /tasks for actual task CRUD after finishing the repository.

## Tests

Run npm test in backend and frontend. The backend standard suite needs no PostgreSQL process, and the untouched starter reports 17 passes and 4 failures until the repository TODOs are implemented. In backend, npm run test:db connects to the separate _test database. The suite checks the connected database name, creates a unique private schema, applies its migration there and cleans up its own table and schema. Read tests/db.test.mjs first. Keep your development data in the other database. Run npm run build in frontend to verify compilation.

The SQL lab file is for psql. In pgAdmin run its SQL statements one at a time within one transaction and replace :id with the ID you just received. Omit psql meta-commands. Leave both programs on loopback and use the project only for local learning.
