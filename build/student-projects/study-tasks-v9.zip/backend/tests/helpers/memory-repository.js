/** In-memory fake for HTTP contract tests ONLY; production uses PostgreSQL. */
export function createFakeRepository() {
  let tasks = [], nextId = 1;
  const copy = t => ({...t});
  return {
    async ping() { return true; },
    async list({ completed = null } = {}) {
      return (completed === null ? tasks : tasks.filter(t => t.completed === completed)).map(copy);
    },
    async get(id) { const task = tasks.find(t => t.id === id); return task ? copy(task) : null; },
    async create({ title }) {
      const task = { id: nextId++, title, completed: false, createdAt: new Date().toISOString() };
      tasks.push(task); return copy(task);
    },
    async update(id, patch) {
      const index = tasks.findIndex(t => t.id === id);
      if (index === -1) return null;
      tasks[index] = { ...tasks[index], ...patch };
      return copy(tasks[index]);
    },
    async remove(id) {
      const before = tasks.length;
      tasks = tasks.filter(t => t.id !== id);
      return tasks.length !== before;
    }
  };
}
