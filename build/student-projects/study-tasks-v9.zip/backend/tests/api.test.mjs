import test from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";
import { createApp } from "../src/app.js";
import { createFakeRepository } from "./helpers/memory-repository.js";

async function withApi(run, repository = createFakeRepository()) {
  const server = createApp({ repository, enableLogging: false }).listen(0, "127.0.0.1");
  await once(server, "listening");
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await run(base); }
  finally { await new Promise((resolve, reject) => server.close(err => err ? reject(err) : resolve())); }
}
async function request(base, path, options = {}) {
  const response = await fetch(base + path, options);
  const text = await response.text();
  return { response, body: text ? JSON.parse(text) : null };
}
const jsonOptions = (method, body) => ({
  method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
});

test("GET /api/health says storage postgres", () => withApi(async base => {
  const { response, body } = await request(base, "/api/health");
  assert.equal(response.status, 200);
  assert.equal(body.storage, "postgres");
  assert.equal(response.headers.get("x-powered-by"), null);
}));
test("GET starts empty; POST 201, GET by ID, and list", () => withApi(async base => {
  assert.deepEqual((await request(base, "/api/tasks")).body, { data:[], count:0 });
  const added = await request(base, "/api/tasks", jsonOptions("POST", { title: "  Finish SQL lab " }));
  assert.equal(added.response.status, 201);
  assert.equal(added.response.headers.get("location"), "/api/tasks/1");
  assert.equal(added.body.data.title, "Finish SQL lab");
  assert.equal(added.body.data.completed, false);
  assert.equal(typeof added.body.data.createdAt, "string");
  assert.deepEqual((await request(base, "/api/tasks/1")).body.data, added.body.data);
}));
test("PATCH and completed filter preserve API contract", () => withApi(async base => {
  await request(base, "/api/tasks", jsonOptions("POST", { title: "One" }));
  await request(base, "/api/tasks", jsonOptions("POST", { title: "Two" }));
  const updated = await request(base, "/api/tasks/1", jsonOptions("PATCH", { completed:true }));
  assert.equal(updated.body.data.completed, true);
  assert.equal((await request(base,"/api/tasks?completed=true")).body.count, 1);
  assert.equal((await request(base,"/api/tasks?completed=false")).body.count, 1);
  const renamed = await request(base,"/api/tasks/1",jsonOptions("PATCH",{title:"Revised"}));
  assert.equal(renamed.body.data.title,"Revised");
  assert.equal(renamed.body.data.completed,true);
}));
test("DELETE returns 204 with no body; absent task returns 404", () => withApi(async base => {
  await request(base,"/api/tasks", jsonOptions("POST",{ title:"Remove me" }));
  const deleted=await request(base,"/api/tasks/1",{ method:"DELETE" });
  assert.equal(deleted.response.status,204);
  assert.equal(deleted.body,null);
  assert.equal((await request(base,"/api/tasks/1")).response.status,404);
}));
test("bad payloads, IDs, filters, paths, and JSON errors", () => withApi(async base => {
  for(const data of [{ title:"" },{title:123},{title:"Valid",extra:true}]) {
    const res=await request(base,"/api/tasks",jsonOptions("POST",data));
    assert.equal(res.response.status,400); assert.equal(res.body.error.code,"VALIDATION_ERROR");
  }
  assert.equal((await request(base,"/api/tasks/bad")).response.status,400);
  assert.equal((await request(base,"/api/tasks?completed=banana")).response.status,400);
  assert.equal((await request(base,"/api/nope")).response.status,404);
  const bad=await request(base,"/api/tasks",{method:"POST",headers:{"Content-Type":"application/json"},body:'{"title":'});
  assert.equal(bad.response.status,400);assert.equal(bad.body.error.code,"INVALID_JSON");
}));
test("when the database is unreachable, health returns safe 503", async () => {
  for (const failure of [
    Object.assign(new Error("private diagnostic"), { code: "ECONNREFUSED" }),
    Object.assign(new Error("private socket diagnostic"), { code: "ECONNRESET" }),
    new Error("Connection terminated unexpectedly"),
  ]) {
    const repository = createFakeRepository();
    repository.ping = async () => { throw failure; };
    await withApi(async base => {
      const result = await request(base, "/api/health");
      assert.equal(result.response.status, 503);
      assert.equal(result.body.error.code, "DB_UNAVAILABLE");
      assert.doesNotMatch(JSON.stringify(result.body), /private|terminated unexpectedly/i);
    }, repository);
  }
});
