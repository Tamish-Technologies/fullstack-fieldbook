import test from "node:test";
import assert from "node:assert/strict";
import { createTaskRepository, toApiTask } from "../src/task-repository.js";
const row = { id:4, title:"Review SQL", completed:false, created_at:new Date("2026-01-02T03:04:05.000Z") };
function fakePool(rows = [row], rowCount = 1) {
  const calls = [];
  return {
    calls,
    async query(text, values = []) {
      calls.push({ text, values });
      return { rows, rowCount };
    }
  };
}
test("maps database created_at timestamp to API createdAt string", () => {
  assert.deepEqual(toApiTask(row),{ id:4,title:"Review SQL",completed:false,createdAt:"2026-01-02T03:04:05.000Z" });
  assert.equal(toApiTask(null),null);
});
test("list queries records in stable order and filters via $1", async () => {
  const pool=fakePool(); const repo=createTaskRepository(pool);
  assert.equal((await repo.list()).length,1);
  assert.match(pool.calls[0].text,/ORDER BY id/);
  const filtered=await repo.list({completed:false});
  assert.equal(filtered[0].id,4);
  assert.match(pool.calls[1].text,/completed\s*=\s*\$1/);
  assert.deepEqual(pool.calls[1].values,[false]);
});
test("get and create parameterize all user data", async () => {
  const pool=fakePool();const repo=createTaskRepository(pool);
  await repo.get(4);
  assert.deepEqual(pool.calls[0].values,[4]);
  const text="Read O'Reilly: SELECT id FROM tasks";
  const created=await repo.create({title:text});
  assert.equal(created.id,4);
  assert.match(pool.calls[1].text,/INSERT INTO tasks/);
  assert.match(pool.calls[1].text,/VALUES\s*\(\$1\)/);
  assert.deepEqual(pool.calls[1].values,[text]);
  assert.doesNotMatch(pool.calls[1].text,/O'Reilly/);
});
test("update supports false and title-only; returns null for missing rows", async () => {
  const pool=fakePool();const repo=createTaskRepository(pool);
  await repo.update(4,{completed:false});
  assert.deepEqual(pool.calls[0].values,[4,null,false]);
  await repo.update(4,{title:"Renamed"});
  assert.deepEqual(pool.calls[1].values,[4,"Renamed",null]);
  const empty=fakePool([]);
  assert.equal(await createTaskRepository(empty).get(999),null);
  assert.equal(await createTaskRepository(empty).update(999,{title:"No"}),null);
});
test("remove uses a bounded WHERE and checks rowCount", async () => {
  const pool=fakePool([],1); const repo=createTaskRepository(pool);
  assert.equal(await repo.remove(4),true);
  assert.match(pool.calls[0].text,/DELETE FROM tasks WHERE id = \$1/);
  assert.deepEqual(pool.calls[0].values,[4]);
  const empty=fakePool([],0);
  assert.equal(await createTaskRepository(empty).remove(999),false);
});
test("ping sends SELECT 1 without a table dependency", async () => {
  const pool=fakePool();assert.equal(await createTaskRepository(pool).ping(),true);
  assert.match(pool.calls[0].text,/SELECT 1/);
});
