import test from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { createDbPool } from "../src/db.js";
import { createTaskRepository } from "../src/task-repository.js";

function databaseName(value, label) {
  try {
    const url = new URL(value);
    if (!["postgres:", "postgresql:"].includes(url.protocol)) throw Error();
    return decodeURIComponent(url.pathname.slice(1));
  } catch {
    throw new Error(`Provide a valid ${label} in backend/.env.`);
  }
}
const testUrl = process.env.TEST_DATABASE_URL;
const expected = databaseName(testUrl, "TEST_DATABASE_URL");
const development = databaseName(process.env.DATABASE_URL, "DATABASE_URL");
if (!expected.endsWith("_test") || expected === development) {
  throw new Error("Use a separate test database whose name ends with _test.");
}

test("real PostgreSQL persists rows across separate connection pools", async () => {
  const migration = await readFile(new URL("../migrations/001_create_tasks.sql", import.meta.url), "utf8");
  // Only the table in this run's unique, test-owned schema is cleaned up.
  const schema = "fieldbook_" + randomUUID().replaceAll("-", "");
  const firstPool = createDbPool(testUrl);
  let createdSchema = false;
  let id;
  async function verify(client) {
    const { rows } = await client.query("SELECT current_database() AS name");
    assert.equal(rows[0].name === expected && rows[0].name !== development, true,
      "Connected database does not match the dedicated test target.");
  }
  async function clean() {
    const pool = createDbPool(testUrl);
    try {
      const client = await pool.connect();
      try {
        await verify(client);
        await client.query(`DROP TABLE IF EXISTS "${schema}".tasks`);
        await client.query(`DROP SCHEMA "${schema}"`);
      } finally { client.release(); }
    } finally { await pool.end(); }
  }
  try {
    try {
      const client = await firstPool.connect();
      try {
        await verify(client);
        await client.query(`CREATE SCHEMA "${schema}"`);
        createdSchema = true;
        await client.query(`SET search_path TO "${schema}"`);
        await client.query(migration);
        const repo = createTaskRepository(client);
        const created = await repo.create({ title: "Stored in PostgreSQL" });
        id = created.id;
        assert.equal(created.completed, false);
        assert.match(created.createdAt, /Z$/);
        assert.equal((await repo.list({ completed: false })).length, 1);
        const updated = await repo.update(id, { completed: true, title: "Persists after reconnect" });
        assert.equal(updated.completed, true);
      } finally { client.release(); }
    } finally { await firstPool.end(); }

    const secondPool = createDbPool(testUrl);
    try {
      const client = await secondPool.connect();
      try {
        await verify(client);
        await client.query(`SET search_path TO "${schema}"`);
        const repo = createTaskRepository(client);
        const saved = await repo.get(id);
        assert.equal(saved.title, "Persists after reconnect");
        assert.equal(saved.completed, true);
        assert.equal((await repo.list({ completed: true })).length, 1);
        assert.equal(await repo.remove(id), true);
        assert.equal(await repo.get(id), null);
      } finally { client.release(); }
    } finally { await secondPool.end(); }
  } finally {
    if (createdSchema) await clean();
  }
});
