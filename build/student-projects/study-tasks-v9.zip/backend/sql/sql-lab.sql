-- psql script. Connect to the local Week 9 development DB as its learning role.
-- Run the migration first. The \gset meta-command saves the returned ID.
\set ON_ERROR_STOP on
SELECT current_database();
BEGIN;
INSERT INTO tasks (title) VALUES ('Week 9 rollback practice')
RETURNING id
\gset
SELECT id, title, completed, created_at FROM tasks WHERE id = :id;
UPDATE tasks SET completed = TRUE WHERE id = :id RETURNING id, completed;
DELETE FROM tasks WHERE id = :id RETURNING id;
ROLLBACK;
SELECT count(*) AS lab_rows_remaining FROM tasks WHERE id = :id;
-- Row changes were rolled back. Identity sequences can still use an ID.
