import { readFile } from "node:fs/promises";
import { createDbPool } from "../src/db.js";

let pool;
try {
  pool = createDbPool();
  const target = await pool.query("SELECT current_database() AS name");
  console.log("Migration database:", target.rows[0].name);
  const sql = await readFile(new URL("../migrations/001_create_tasks.sql", import.meta.url), "utf8");
  await pool.query(sql);
  console.log("Migration 001 applied (or tasks table already exists).");
} catch {
  console.error("Migration failed. Check PostgreSQL, the development database, and backend/.env.");
  process.exitCode = 1;
} finally {
  await pool?.end();
}
