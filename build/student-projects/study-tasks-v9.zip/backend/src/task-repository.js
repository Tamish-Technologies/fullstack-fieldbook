/** Week 9 student exercise: replace these placeholders with real SQL queries. */
export function toApiTask(row) {
  if (!row) return null;
  return {
    id: row.id,
    title: row.title,
    completed: row.completed,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() :
      new Date(row.created_at).toISOString()
  };
}

export function createTaskRepository(pool) {
  return {
    async ping() { await pool.query("SELECT 1"); return true; },
    // TODO 1: SELECT tasks ordered by id; optionally filter completed.
    async list({ completed = null } = {}) {
      throw new Error("TODO: implement list() with a parameterized WHERE filter");
    },
    // TODO 2: SELECT one task by id using $1 and [id].
    async get(id) {
      throw new Error("TODO: implement get(id) with SQL");
    },
    // TODO 3: INSERT title using $1; RETURNING columns and use toApiTask().
    async create({ title }) {
      throw new Error("TODO: implement create() with SQL");
    },
    // TODO 4: PATCH one row; support title and completed separately and together.
    async update(id, patch) {
      throw new Error("TODO: implement update() with SQL");
    },
    // TODO 5: DELETE by ID; return true for a deleted row, false otherwise.
    async remove(id) {
      throw new Error("TODO: implement remove() with SQL");
    }
  };
}
