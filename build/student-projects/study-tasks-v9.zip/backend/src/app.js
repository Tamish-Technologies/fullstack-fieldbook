import express from "express";
import {
  parseCompletedFilter, parseTaskId, validateCreateBody, validatePatchBody
} from "./validation.js";

const errorBody = (code, message) => ({ error: { code, message } });
const connectionCodes = new Set([
  "ECONNREFUSED", "ECONNRESET", "EPIPE", "ENOTFOUND", "EAI_AGAIN",
  "EHOSTUNREACH", "ENETUNREACH", "ETIMEDOUT", "57P01", "57P02", "57P03",
]);
const driverConnectionMessages = new Set([
  "Connection terminated unexpectedly",
  "Connection terminated",
  "Connection terminated due to connection timeout",
  "timeout exceeded when trying to connect",
  "timeout expired",
  "Client was closed and is not queryable",
]);
function isConnectionError(error) {
  const code = error?.code;
  return connectionCodes.has(code) ||
    (typeof code === "string" && code.startsWith("08")) ||
    driverConnectionMessages.has(error?.message);
}

/** Express 5 forwards errors from rejected async route handlers. */
export function createApp({ repository, enableLogging = true } = {}) {
  if (!repository) throw new Error("createApp requires a task repository.");
  const app = express();
  app.disable("x-powered-by");
  if (enableLogging) app.use((req, res, next) => {
    const started = Date.now();
    res.on("finish", () => console.log(`${req.method} ${req.path} -> ${res.statusCode} (${Date.now()-started}ms)`));
    next();
  });
  app.use(express.json({ limit: "16kb" }));

  app.get("/api/health", async (_req, res) => {
    await repository.ping();
    res.status(200).json({ status: "ok", service: "study-tasks-api", storage: "postgres" });
  });

  app.get("/api/tasks", async (req, res) => {
    const filter = parseCompletedFilter(req.query.completed);
    if (!filter.ok) return res.status(400).json(errorBody("INVALID_FILTER", filter.message));
    const data = await repository.list({ completed: filter.value });
    return res.json({ data, count: data.length });
  });

  app.get("/api/tasks/:id", async (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const task = await repository.get(id);
    if (!task) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.json({ data: task });
  });

  app.post("/api/tasks", async (req, res) => {
    const parsed = validateCreateBody(req.body);
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const task = await repository.create(parsed.value);
    return res.status(201).location(`/api/tasks/${task.id}`).json({ data: task });
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const parsed = validatePatchBody(req.body);
    if (!parsed.ok) return res.status(400).json(errorBody("VALIDATION_ERROR", parsed.message));
    const task = await repository.update(id, parsed.value);
    if (!task) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.json({ data: task });
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    const id = parseTaskId(req.params.id);
    if (id === null) return res.status(400).json(errorBody("INVALID_ID", "id must be a positive integer."));
    const removed = await repository.remove(id);
    if (!removed) return res.status(404).json(errorBody("TASK_NOT_FOUND", "Task does not exist."));
    return res.status(204).end();
  });

  app.use((_req, res) => res.status(404).json(errorBody("ROUTE_NOT_FOUND", "Unknown API route.")));
  app.use((error, _req, res, next) => {
    if (res.headersSent) return next(error);
    if (error?.type === "entity.parse.failed") {
      return res.status(400).json(errorBody("INVALID_JSON", "Request body must be valid JSON."));
    }
    if (error?.type === "entity.too.large") {
      return res.status(413).json(errorBody("PAYLOAD_TOO_LARGE", "JSON body exceeds 16kb."));
    }
    // Detailed database failures remain server-side. Do not expose SQL or secrets to clients.
    const unavailable = isConnectionError(error);
    console.error(unavailable ? "Database connection unavailable." : "Server request failed.");
    if (unavailable) {
      return res.status(503).json(errorBody("DB_UNAVAILABLE", "Database temporarily unavailable."));
    }
    return res.status(500).json(errorBody("INTERNAL_ERROR", "Unexpected server error."));
  });
  return app;
}
