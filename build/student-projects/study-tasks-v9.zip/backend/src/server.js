import { once } from "node:events";
import { createApp } from "./app.js";
import { createDbPool } from "./db.js";
import { createTaskRepository } from "./task-repository.js";

const port = Number(process.env.PORT ?? 3001);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error("PORT must be an integer between 1 and 65535.");
  process.exit(1);
}
if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is missing. Copy and edit backend/.env.example.");
  process.exit(1);
}
const pool = createDbPool();
try {
  const repository = createTaskRepository(pool);
  await repository.ping();
  const app = createApp({ repository });
  const server = app.listen(port, "127.0.0.1");
  await once(server, "listening");
  console.log(`Study Tasks API: http://127.0.0.1:${port}/api/health`);
  console.log("Task storage: PostgreSQL.");
  async function shutdown() {
    server.close(async () => { await pool.end(); });
  }
  process.once("SIGINT", shutdown);
  process.once("SIGTERM", shutdown);
} catch (error) {
  console.error(error?.code === "EADDRINUSE"
    ? `API port ${port} is occupied. Stop the old backend or change the port.`
    : "API startup failed. Check local PostgreSQL, .env settings and the target database.");
  await pool.end();
  process.exitCode = 1;
}
