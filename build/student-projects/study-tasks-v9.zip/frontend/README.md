# Week 9 frontend

Follow [Start here](../START_HERE.md) for the database and process setup. Run all npm commands for this program from this folder.
