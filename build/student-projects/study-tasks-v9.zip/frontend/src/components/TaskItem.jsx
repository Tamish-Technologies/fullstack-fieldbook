import { useState } from "react";

export default function TaskItem({ task, onToggle, onDelete, onRename, disabled = false }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(task.title);
  const [error, setError] = useState("");

  async function saveEdit(event) {
    event.preventDefault();
    const result = await onRename(task.id, draft);
    if (result.ok) {
      setEditing(false);
      setError("");
    } else {
      setError(result.error); // Keep the unsaved draft visible.
    }
  }

  if (editing) return (
    <li className="task-item">
      <form className="edit-form" onSubmit={saveEdit}>
        <label className="sr-only" htmlFor={`edit-${task.id}`}>Edit {task.title}</label>
        <input id={`edit-${task.id}`} type="text" disabled={disabled}
          value={draft} onChange={(event) => { setDraft(event.target.value); setError(""); }} />
        <button type="submit" disabled={disabled}>Save</button>
        <button type="button" className="quiet-button" disabled={disabled}
          onClick={() => { setEditing(false); setDraft(task.title); setError(""); }}>Cancel</button>
        {error && <p className="error edit-error" role="alert">{error}</p>}
      </form>
    </li>
  );

  return (
    <li className={`task-item${task.completed ? " completed" : ""}`}>
      <label className="task-label">
        <input type="checkbox" checked={task.completed} disabled={disabled}
          onChange={() => onToggle(task)} />
        <span>{task.title}</span>
      </label>
      <div className="task-actions">
        <button type="button" className="quiet-button" disabled={disabled}
          onClick={() => { setDraft(task.title); setEditing(true); }}
          aria-label={`Edit task: ${task.title}`}>Edit</button>
        <button type="button" className="delete-button" disabled={disabled}
          onClick={() => { if (window.confirm("Delete this saved task?")) onDelete(task.id); }} aria-label={`Delete task: ${task.title}`}>Delete</button>
      </div>
    </li>
  );
}
