import { useEffect, useState } from "react";
import { Link } from "react-router";
import { fetchIdeas } from "../lib/ideas-api.js";
import { SAMPLE_IDEAS } from "../lib/sample-ideas.js";

export default function IdeasPage({ onAddIdea, tasksReady, busy }) {
  const [source, setSource] = useState("remote");
  const [retryKey, setRetryKey] = useState(0);
  const [remote, setRemote] = useState({ status: "loading", ideas: [], error: "" });
  const [notice, setNotice] = useState("");
  const state = source === "offline" ?
    { status: "success", ideas: SAMPLE_IDEAS, error: "" } : remote;

  useEffect(() => {
    if (source !== "remote") return;
    const controller = new AbortController();
    let active = true;
    setRemote({ status: "loading", ideas: [], error: "" });
    fetchIdeas({ signal: controller.signal })
      .then((ideas) => { if (active) setRemote({ status: ideas.length ? "success" : "empty", ideas, error: "" }); })
      .catch((error) => { if (active && error.name !== "AbortError") {
        setRemote({ status: "error", ideas: [], error: error.message });
      }});
    return () => { active = false; controller.abort(); };
  }, [source, retryKey]);

  async function addIdea(idea) {
    setNotice("");
    const result = await onAddIdea(idea);
    setNotice(result.ok ? "Saved to your Express backend." : `Not saved: ${result.error}`);
  }
  return (
    <section className="page-panel" aria-labelledby="ideas-heading">
      <p className="eyebrow">PUBLIC EXAMPLE API</p>
      <h1 id="ideas-heading" className="page-title">Study Idea Inbox</h1>
      <p className="muted">Find examples, then create a task in <Link to="/tasks">your own backend</Link>.</p>
      <div className="idea-controls">
        <button type="button" onClick={() => { setSource("remote"); setRetryKey(v => v + 1); }}>Fetch ideas</button>
        <button type="button" className="quiet-button" onClick={() => setSource("offline")}>Use offline examples</button>
      </div>
      <p className="source-line">Source: {source === "offline" ? "offline examples" : "JSONPlaceholder test API"}</p>
      {!tasksReady && <p className="status-box" role="status">Your backend must be connected before you can save ideas.</p>}
      {notice && <p className="status-box" role="status">{notice}</p>}
      {state.status === "loading" && <p className="status-box" role="status">Loading ideas...</p>}
      {state.status === "error" && <div className="status-box status-error" role="alert"><strong>Could not load ideas.</strong><p>{state.error}</p></div>}
      {state.status === "empty" && <p className="status-box">No usable ideas returned.</p>}
      {state.status === "success" && <ul className="idea-list" aria-label="Study ideas">
        {state.ideas.map((idea) => <li className="idea-item" key={idea.id}>
          <span>{idea.title}</span>
          <button type="button" disabled={!tasksReady || busy} onClick={() => addIdea(idea)}
            aria-label={`Add to tasks: ${idea.title}`}>Add to tasks</button>
        </li>)}
      </ul>}
      <p className="muted small-note">Copied ideas use a fresh server-assigned task ID. Nothing is posted to the public example API.</p>
    </section>
  );
}
