import { Link, NavLink, Route, Routes } from "react-router";
import DashboardPage from "./pages/DashboardPage.jsx";
import TasksPage from "./pages/TasksPage.jsx";
import IdeasPage from "./pages/IdeasPage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";
import ServerPage from "./pages/ServerPage.jsx";
import { useServerTasks } from "./hooks/useServerTasks.js";

export default function App() {
  const data = useServerTasks();
  return (
    <div className="app-shell">
      <header className="site-header">
        <Link to="/" className="brand">
          <span className="brand-symbol" aria-hidden="true">S</span>
          <span><strong>Study Tasks</strong><small>v9 / PostgreSQL tasks</small></span>
        </Link>
        <nav className="site-nav" aria-label="Main navigation">
          <NavLink to="/" end>Dashboard</NavLink>
          <NavLink to="/tasks">My tasks</NavLink>
          <NavLink to="/ideas">Idea inbox</NavLink>
          <NavLink to="/server">API lab</NavLink>
        </nav>
      </header>
      <main className="content">
        <Routes>
          <Route path="/" element={<DashboardPage
            tasks={data.tasks} status={data.status} error={data.loadError} onRetry={data.retry} />} />
          <Route path="/tasks" element={<TasksPage tasks={data.tasks}
            status={data.status} loadError={data.loadError}
            mutationError={data.mutationError} busy={data.busy} onRetry={data.retry}
            onAdd={data.add} onToggle={data.toggle}
            onDelete={data.remove} onRename={data.rename} />} />
          <Route path="/ideas" element={<IdeasPage onAddIdea={(idea) => data.add(idea.title)}
            tasksReady={data.status === "ready"} busy={data.busy} />} />
          <Route path="/server" element={<ServerPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <footer className="site-footer">Phase 1 / Week 9 &middot; Tasks are stored in PostgreSQL</footer>
    </div>
  );
}
