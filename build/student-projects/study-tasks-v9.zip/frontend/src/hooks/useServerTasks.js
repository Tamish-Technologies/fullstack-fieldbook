import { useEffect, useRef, useState } from "react";
import { taskApi } from "../lib/task-api.js";
import { validateTitle } from "../lib/task-logic.js";

/** Server owns the source of truth. This hook owns the React copy of server data. */
export function useServerTasks() {
  const [tasks, setTasks] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [loadError, setLoadError] = useState("");
  const [mutationError, setMutationError] = useState("");
  const [busy, setBusy] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const mutationLock = useRef(false);

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setStatus("loading");
    setLoadError("");
    setMutationError("");
    setTasks([]);

    taskApi.list({ signal: controller.signal })
      .then((serverTasks) => {
        if (!active) return;
        setTasks(serverTasks);
        setStatus("ready");
      })
      .catch((error) => {
        if (!active || error.name === "AbortError") return;
        setLoadError(error.message);
        setStatus("error");
      });
    return () => { active = false; controller.abort(); };
  }, [reloadKey]);

  function retry() {
    if (!mutationLock.current) setReloadKey((value) => value + 1);
  }

  async function mutate(action, applyResult) {
    if (mutationLock.current || status !== "ready") {
      return { ok: false, error: "Finish the current request before trying again." };
    }
    mutationLock.current = true; // guards two clicks before React re-renders
    setBusy(true);
    setMutationError("");
    try {
      const result = await action();
      setTasks((previous) => applyResult(previous, result));
      return { ok: true, data: result };
    } catch (error) {
      setMutationError(error.message);
      return { ok: false, error: error.message };
    } finally {
      mutationLock.current = false;
      setBusy(false);
    }
  }

  function add(title) {
    const check = validateTitle(title);
    if (!check.ok) return Promise.resolve(check);
    return mutate(() => taskApi.create(check.title), (old, created) => [...old, created]);
  }

  function rename(id, title) {
    const check = validateTitle(title);
    if (!check.ok) return Promise.resolve(check);
    return mutate(() => taskApi.update(id, { title: check.title }),
      (old, updated) => old.map((task) => task.id === id ? updated : task));
  }

  function toggle(task) {
    return mutate(() => taskApi.update(task.id, { completed: !task.completed }),
      (old, updated) => old.map((row) => row.id === updated.id ? updated : row));
  }

  function remove(id) {
    return mutate(() => taskApi.remove(id), (old) => old.filter((task) => task.id !== id));
  }

  return { tasks, status, loadError, mutationError, busy, retry, add, rename, toggle, remove };
}
